import { isPlainObject as isObject } from '../formats/plain-object.js';
import { hashSortedJson as hashStable } from '../formats/sorted-json.js';
import { assertOrderedResidentRecord } from '../config/ordered-resident-qualification.js';
import path from 'node:path';
import { assertSequenceReferenceTranscript } from '../config/sequence-reference.js';
import { assertRerankReferenceTranscript, assertRerankSourceIdentity } from '../config/rerank-reference.js';
import { assertEmbeddingReferenceTranscript, assertEmbeddingSourceIdentity } from '../config/embedding-reference.js';
import { resolveCapsuleEmbeddingContract } from '../config/embedding-contract.js';
import { assertChoiceScoringReferenceTranscript } from '../config/choice-scoring-reference.js';

export function promoteQualifiedModelIRV2(modelIR, programBundle) {
  const transcript = programBundle.referenceTranscript;
  const operation = transcript?.operation ?? 'generate';
  if (operation === 'rerank' || operation === 'embed') {
    if (operation === 'rerank') assertRerankReferenceTranscript(transcript);
    else assertEmbeddingReferenceTranscript(transcript);
    const source = transcript.reference.source;
    if (source.revision !== modelIR.sourceIdentity.revision
      || source.checkpointId !== modelIR.sourceIdentity.checkpointId
      || source.repository !== modelIR.sourceIdentity.repository) {
      throw new Error(`Rig ${operation} source identity does not match ModelIR source identity.`);
    }
  } else if (operation === 'generate') {
    const parity = transcript?.sourceParity;
    if (parity?.schema !== 'doppler.source-token-parity/v1' || parity.status !== 'passed'
      || parity.prompt?.passed !== true || parity.generation?.passed !== true) {
      throw new Error('Rig ModelIR v2 promotion requires exact passed source-token parity.');
    }
    if (parity.sourceRevision !== modelIR.sourceIdentity.revision
      || ![modelIR.sourceIdentity.checkpointId, modelIR.sourceIdentity.repository].includes(parity.sourceModel)) {
      throw new Error('Rig source-token parity identity does not match ModelIR source identity.');
    }
  } else {
    throw new Error(`Rig ModelIR v2 promotion does not support operation "${operation}".`);
  }
  const surface = transcript.surface;
  if (typeof surface !== 'string' || !surface.endsWith('-webgpu') || surface.startsWith('unknown')) {
    throw new Error('Rig ModelIR v2 promotion requires an explicit physical WebGPU surface.');
  }
  const entryPoints = modelIR.entryPoints.filter((entryPoint) => (
    entryPoint.kind === operation && entryPoint.status === 'lowered'
      && modelIR.supportScope.loweredEntryPoints.includes(entryPoint.id)
  ));
  if (entryPoints.length !== 1) {
    throw new Error(`Rig ModelIR v2 promotion requires exactly one lowered ${operation} entry point.`);
  }
  return {
    ...structuredClone(modelIR),
    supportScope: {
      ...structuredClone(modelIR.supportScope),
      qualifiedEntryPoints: [...new Set([
        ...modelIR.supportScope.qualifiedEntryPoints, entryPoints[0].id,
      ])].sort(),
    },
  };
}

export function buildQualificationRecords(lowered) {
  const normalized = lowered.normalized;
  const referenceArtifact = normalized.artifacts.find((artifact) => artifact.role === 'reference-report');
  if (!referenceArtifact) throw new Error('Rig requires a packaged reference-report artifact.');
  const transcript = normalized.programBundle.referenceTranscript;
  if (transcript?.operation === 'scoreChoices') {
    assertChoiceScoringReferenceTranscript(transcript);
    if (lowered.modelIR.outputTopology?.headType !== 'causal-lm'
      || transcript.manifestHash !== normalized.manifestHash || transcript.modelId !== lowered.modelIR.modelId
      || transcript.executionGraphHash !== normalized.programBundle.execution.graphHash) {
      throw new Error('Rig choice scoring qualification must bind a causal LM and its exact model and program.');
    }
    const surfaces = normalized.programBundle.captureProfile?.surfaces;
    if (!Array.isArray(surfaces) || surfaces.length !== 1 || surfaces[0] !== transcript.surface) {
      throw new Error('Rig choice scoring capture surface must match the actual qualification report.');
    }
    return [{ surface: transcript.surface, status: 'passed', operation: 'scoreChoices',
      scoredChoices: transcript.reference.cases.reduce((count, row) => count + row.input.choices.length, 0),
      evidenceArtifactId: referenceArtifact.artifactId, evidenceHash: referenceArtifact.hash,
      transcriptHash: hashStable(transcript),
    }, ...normalized.qualificationEvidence.map(({ artifact, ...record }) => record)];
  }
  if (transcript?.operation === 'embed') {
    assertEmbeddingReferenceTranscript(transcript);
    assertEmbeddingSourceIdentity(normalized.manifest?.artifactIdentity, transcript.reference);
    if (hashStable(resolveCapsuleEmbeddingContract(normalized.manifest)) !== hashStable(transcript.reference.embeddingContract)
      || transcript.manifestHash !== normalized.manifestHash || transcript.modelId !== lowered.modelIR.modelId
      || transcript.executionGraphHash !== normalized.programBundle.execution.graphHash) {
      throw new Error('Rig embedding qualification does not match its declared embedding contract and exact program.');
    }
    const surfaces = normalized.programBundle.captureProfile?.surfaces;
    if (!Array.isArray(surfaces) || surfaces.length !== 1 || surfaces[0] !== transcript.surface) {
      throw new Error('Rig embedding capture surface must match the actual qualification report.');
    }
    return [{ surface: transcript.surface, status: 'passed', operation: 'embed',
      embeddedTexts: transcript.reference.input.texts.length,
      evidenceArtifactId: referenceArtifact.artifactId, evidenceHash: referenceArtifact.hash,
      transcriptHash: hashStable(transcript),
    }, ...normalized.qualificationEvidence.map(({ artifact, ...record }) => record)];
  }
  if (normalized.manifest?.modelType === 'embedding'
    && normalized.manifest?.inference?.supportsSequence !== true) {
    throw new Error('Rig requires text embedding qualification for an embedding model; other operation evidence is insufficient.');
  }
  if (transcript?.operation === 'rerank') {
    assertRerankReferenceTranscript(transcript);
    assertRerankSourceIdentity(normalized.manifest?.artifactIdentity, transcript.reference);
    if (normalized.manifest?.inference?.supportsRerank !== true
      || hashStable(normalized.manifest.inference.rerank) !== hashStable(transcript.reference.scoringConfig)
      || normalized.manifest.artifactIdentity?.sourceCheckpointId !== transcript.reference.source.checkpointId
      || transcript.manifestHash !== normalized.manifestHash || transcript.modelId !== lowered.modelIR.modelId
      || transcript.executionGraphHash !== normalized.programBundle.execution.graphHash) {
      throw new Error('Rig rerank qualification does not match its declared scoring contract and exact program.');
    }
    const surfaces = normalized.programBundle.captureProfile?.surfaces;
    if (!Array.isArray(surfaces) || surfaces.length !== 1 || surfaces[0] !== transcript.surface) {
      throw new Error('Rig rerank capture surface must match the actual qualification report.');
    }
    return [{ surface: transcript.surface, status: 'passed', operation: 'rerank',
      rerankedDocuments: transcript.reference.input.documents.length,
      evidenceArtifactId: referenceArtifact.artifactId, evidenceHash: referenceArtifact.hash,
      transcriptHash: hashStable(transcript),
    }, ...normalized.qualificationEvidence.map(({ artifact, ...record }) => record)];
  }
  if (normalized.manifest?.inference?.supportsRerank === true) {
    throw new Error('Rig requires rerank qualification for a reranker; generation evidence is insufficient.');
  }
  if (transcript?.operation === 'encodeSequence') {
    assertSequenceReferenceTranscript(transcript);
    if (lowered.modelIR.outputTopology?.headType !== 'sequence-encoder'
      || transcript.manifestHash !== normalized.manifestHash
      || transcript.modelId !== lowered.modelIR.modelId
      || transcript.executionGraphHash !== normalized.programBundle.execution.graphHash) {
      throw new Error('Rig sequence qualification does not match its encoder ModelIR and exact program.');
    }
    const surfaces = normalized.programBundle.captureProfile?.surfaces;
    if (!Array.isArray(surfaces) || surfaces.length !== 1 || surfaces[0] !== transcript.surface) {
      throw new Error('Rig sequence capture surface must match the actual qualification report.');
    }
    return [{
      surface: transcript.surface,
      status: 'passed',
      operation: 'encodeSequence',
      encodedSequences: 1,
      evidenceArtifactId: referenceArtifact.artifactId,
      evidenceHash: referenceArtifact.hash,
      transcriptHash: hashStable(transcript),
    }, ...normalized.qualificationEvidence.map(({ artifact, ...record }) => record)];
  }
  if (lowered.modelIR.outputTopology?.headType === 'sequence-encoder') {
    throw new Error('Rig requires sequence qualification for an encoder; generation evidence is insufficient.');
  }
  const tokens = transcript?.tokens?.ids;
  if (!Array.isArray(tokens) || tokens.length === 0) throw new Error('Rig requires reference transcript token IDs.');
  const generationConfig = transcript?.generationConfig;
  if (!isObject(generationConfig) || !Number.isFinite(generationConfig.temperature)) {
    throw new Error('Rig requires reference transcript generationConfig.');
  }
  if (generationConfig.temperature > 0 && !Number.isFinite(generationConfig.seed)) {
    throw new Error('Rig rejects nondeterministic qualification evidence without a seed.');
  }
  const surfaces = normalized.programBundle.captureProfile?.surfaces;
  if (!Array.isArray(surfaces) || surfaces.length === 0) throw new Error('Rig requires captureProfile.surfaces qualification evidence.');
  const records = surfaces.map((surface) => ({
    surface,
    status: 'passed',
    evidenceArtifactId: referenceArtifact.artifactId,
    evidenceHash: referenceArtifact.hash,
    transcriptHash: hashStable({ surface, captureProfile: normalized.programBundle.captureProfile, transcript }),
    generatedTokens: tokens.length,
  }));
  for (const evidence of normalized.qualificationEvidence) {
    const { artifact: ignoredArtifact, ...record } = evidence;
    void ignoredArtifact;
    records.push(record);
  }
  return records;
}

export function normalizeQualificationEvidence(evidence) {
  if (!isObject(evidence)) throw new Error('Rig requires qualification evidence as an object.');
  const requireString = (value, label) => {
    if (typeof value !== 'string' || !value.trim()) throw new Error(`Rig requires ${label}.`);
    return value.trim();
  };
  const requirePositiveInteger = (value, label) => {
    if (!Number.isInteger(value) || value < 1) throw new Error(`Rig requires ${label} as a positive integer.`);
    return value;
  };
  if (![undefined, 'generate', 'rerank', 'encodeSequence', 'embed', 'scoreChoices', 'residentPartition'].includes(evidence.operation)) {
    throw new Error(`Rig does not support qualification operation "${evidence.operation}".`);
  }
  const surface = requireString(evidence.surface, 'qualificationEvidence.surface');
  const evidenceHash = requireString(evidence.evidenceHash, 'qualificationEvidence.evidenceHash');
  const sourcePath = path.resolve(requireString(evidence.sourcePath, 'qualificationEvidence.sourcePath'));
  const sizeBytes = requirePositiveInteger(evidence.sizeBytes, 'qualificationEvidence.sizeBytes');
  if (evidence.operation === 'residentPartition' && (!/^sha256:[a-f0-9]{64}$/.test(evidence.partitionPlanHash)
    || (evidence.orderedContract === undefined && ![0, 1].includes(evidence.partitionIndex)))) throw new Error('Rig resident qualification requires a partition plan and index.');
  if (evidence.orderedContract !== undefined) assertOrderedResidentRecord(evidence);
  const counts = evidence.operation === 'residentPartition'
    ? { operation: 'residentPartition', partitionPlanHash: evidence.partitionPlanHash, partitionIndex: evidence.partitionIndex,
      comparedSteps: requirePositiveInteger(evidence.comparedSteps, 'qualificationEvidence.comparedSteps') }
    : evidence.operation === 'rerank'
    ? { operation: 'rerank', rerankedDocuments: requirePositiveInteger(evidence.rerankedDocuments, 'qualificationEvidence.rerankedDocuments') }
    : evidence.operation === 'encodeSequence'
    ? { operation: 'encodeSequence', encodedSequences: requirePositiveInteger(evidence.encodedSequences, 'qualificationEvidence.encodedSequences') }
    : evidence.operation === 'embed'
    ? { operation: 'embed', embeddedTexts: requirePositiveInteger(evidence.embeddedTexts, 'qualificationEvidence.embeddedTexts') }
    : evidence.operation === 'scoreChoices'
    ? { operation: 'scoreChoices', scoredChoices: requirePositiveInteger(evidence.scoredChoices, 'qualificationEvidence.scoredChoices') }
    : { generatedTokens: requirePositiveInteger(evidence.generatedTokens, 'qualificationEvidence.generatedTokens') };
  const transcriptHash = requireString(evidence.transcriptHash, 'qualificationEvidence.transcriptHash');
  if (evidence.status !== 'passed') throw new Error('Rig only packages passed qualification evidence.');
  const capsulePath = path.join(
    'artifacts',
    'evidence',
    `qualification-${surface.replace(/[^a-zA-Z0-9._-]+/g, '-')}-${evidenceHash.slice('sha256:'.length, 'sha256:'.length + 12)}.json`
  ).split(path.sep).join('/');
  const artifact = {
    artifactId: `qualification-evidence:${path.basename(capsulePath)}:${evidenceHash.slice(7, 19)}`,
    role: 'qualification-evidence',
    path: capsulePath,
    hash: evidenceHash,
    sizeBytes,
    sourcePath,
  };
  return {
    surface,
    status: 'passed',
    evidenceArtifactId: artifact.artifactId,
    evidenceHash,
    transcriptHash,
    ...counts,
    ...(evidence.orderedContract === undefined ? {} : { orderedContract: evidence.orderedContract, providerIdentityHash: evidence.providerIdentityHash }),
    artifact,
  };
}
