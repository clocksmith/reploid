

import { log } from '../../../debug/index.js';
import { getDevice } from '../../../gpu/device.js';
import { acquireBuffer, releaseBuffer } from '../../../memory/buffer-pool.js';
import { preprocessImage } from './image-preprocess.js';
import { patchEmbed } from './patch-embed.js';
import { runVisionEncoder } from './encoder.js';
import { encodeGemma4Image } from './gemma4.js';
import { encodeGlmOcrImage } from './glmocr.js';
import { resolveVisionArchitectureSupport, executableVisionArchitectures } from './support.js';

export { resolveVisionArchitectureSupport } from './support.js';

export async function encodeImage(params) {
  const { pixels, width, height, visionConfig, weights, softTokenBudget } = params;

  const arch = typeof visionConfig?.visionArchitecture === 'string'
    ? visionConfig.visionArchitecture.trim()
    : '';
  if (!arch) {
    throw new Error(
      'Vision encode requires visionConfig.visionArchitecture. ' +
      'Re-convert the model with explicit vision_config.vision_architecture.'
    );
  }
  log.debug('Vision', `encodeImage: ${width}x${height} input, arch=${arch}`);

  // Architecture-specific preprocessing dispatch
  let preprocessed;
  switch (arch) {
    case 'gemma4':
      return encodeGemma4Image(params);
    case 'glmocr':
      return encodeGlmOcrImage(params);
    case 'qwen3vl': {
      // The generic ViT path below is the partial Qwen3-VL implementation. It
      // runs only once the support table marks the architecture executable.
      const support = resolveVisionArchitectureSupport(arch);
      if (!support.executable) {
        throw new Error(`Vision architecture "${arch}" cannot run: ${support.reason}.`);
      }
      preprocessed = preprocessImage(pixels, width, height, visionConfig);
      break;
    }
    default:
      throw new Error(
        `Unsupported vision architecture "${arch}". ` +
        `Executable: ${executableVisionArchitectures().join(', ')}. Check vision_config.vision_architecture.`
      );
  }

  // Step 2: Patch embedding — conv2d patches -> [numPatches, hiddenSize].
  const { patchBuffer, numPatches } = await patchEmbed({
    imageData: preprocessed.data,
    height: preprocessed.height,
    width: preprocessed.width,
    channels: preprocessed.channels,
    gridHeight: preprocessed.gridThw[1],
    gridWidth: preprocessed.gridThw[2],
    visionConfig,
    weights,
  });

  // Step 3: Vision encoder — ViT blocks + spatial merge.
  const { features, numTokens, featureSize } = await runVisionEncoder({
    patchBuffer,
    numPatches,
    gridHeight: preprocessed.gridThw[1],
    gridWidth: preprocessed.gridThw[2],
    visionConfig,
    weights,
  });

  return {
    features,
    numTokens,
    featureSize,
    gridThw: preprocessed.gridThw,
    imageWidth: preprocessed.width,
    imageHeight: preprocessed.height,
  };
}
