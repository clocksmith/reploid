import { isGpuBufferInstance, isWeightBuffer, getWeightDtype } from '../../../../../gpu/weight-buffer.js';
import { getKernelCapabilities } from '../../../../../gpu/device.js';
import { acquireBuffer } from '../../../../../memory/buffer-pool.js';
import { recordMatmul } from '../../../../../gpu/kernels/matmul.js';
import { recordRMSNorm } from '../../../../../gpu/kernels/rmsnorm.js';
import { recordLayerNorm } from '../../../../../gpu/kernels/layernorm.js';
import { recordBiasAdd } from '../../../../../gpu/kernels/residual.js';
import { recordRoPE } from '../../../../../gpu/kernels/rope.js';
import { canUseRoPEQK, recordRoPEQK } from '../../../../../gpu/kernels/rope-qk.js';
import { recordAttention, recordAttentionTiered, recordAttentionTieredQuant, recordAttentionContiguousQuant, recordAttentionBDPA } from '../../../../../gpu/kernels/attention.js';
import { recordSiLU } from '../../../../../gpu/kernels/silu.js';
import { recordCastF16ToF32, recordCastF32ToF16 } from '../../../../../gpu/kernels/cast.js';
import { recordMatmulResidualFused } from '../../../../../gpu/kernels/fused_matmul_residual.js';
import { createTensor } from '../../../../../gpu/tensor.js';
import { applyLoRA } from '../../lora-apply.js';
import { getLoRAModule } from '../../lora.js';
import { log, trace } from '../../../../../debug/index.js';
import { selectRuleValue } from '../../../../../rules/rule-registry.js';
import {
  recordAttentionInputs,
  shouldForceF32AttentionProjectionForRoPE,
  resolveAttentionProjectionOutputDtype,
  projectAttentionQKV,
  applyAttentionQKNorm,
  applyAttentionValueNorm,
  hasAttentionProjectionDiagnostics,
  hasAttentionStageDiagnostics,
  resolveAttentionQKNormState,
} from '../projections.js';
import { prepareAttentionProjectionInput } from '../output-projection.js';
import { runProbes } from "../../observation/probes.js";
import { shouldDebugLayer } from '../types.js';
import {
  getKernelPathMatmulPrecision,
  getKernelPathMatmulVariant,
} from '../../../../../config/kernel-path-loader.js';
import {
  resolveKVCacheState,
  createDiffusionGemmaDecoderKVState,
  buildAttentionDispatchParams,
  buildAttentionInputsData,
} from '../dispatch-params.js';
import {
  buildTieredQuantAttentionOptions,
  buildContiguousQuantAttentionOptions,
} from '../quant-options.js';
import { assertImplicitDtypeTransitionAllowed } from "../../policy/dtype-contract.js";
import {
  resolveAttentionPrecisionContract,
  isAttentionKvDtypeExplicit,
} from '../precision-contract.js';
import { canUseRmsNormWideTileProjectionFusion } from '../rmsnorm-fusion-gate.js';
import { getVectorTensor } from "../../loading/weights.js";
import { resolveAttentionRuntimeSession } from "../../configuration/resolved-runtime-session.js";
import {
  bindAttentionPlan,
  createAttentionExecutor,
  executeBoundAttentionPlan,
  resolveAttentionPlanForDispatch,
} from '../plan.js';
import { createRecordedResourceScope } from '../../../../resource-scope.js';
import { captureAttentionRefactorReceipt } from '../receipt.js';
import { applyAttentionQueryScale } from '../query-transform.js';
import { resolveQueryScale } from '../../../../../config/heterogeneous-attention-contract.js';
import { enqueueRecordedTensorHealth, shouldTraceRecordedHealth } from '../recorded-health.js';
import { resolveDirectF16KVCacheWrite, runRecordedAttentionCore } from './recorded.js';

export function assertAttentionDtypeTransitionAllowed(state, fromDtype, toDtype, detail, transitionDeclaredBy = null) {
  assertImplicitDtypeTransitionAllowed({
    executionPolicies: state?.executionPolicies ?? null,
    fromDtype,
    toDtype,
    op: 'attention',
    detail,
    transitionDeclaredBy,
  });
}

export function resolveRecordedAttentionDispatch(options) {
  const {
    attentionActivationDtype,
    attentionPrecisionContract,
    canFuseInputNormProjRec,
    config,
    diffusionGemmaDecoder,
    headDim,
    hiddenSize,
    input,
    isPrefill,
    kTensor,
    kvCacheDtype,
    kvState,
    layerIdx,
    layerType,
    layerWeights,
    lora,
    matmulOutputDtype,
    normed,
    numHeads,
    numKVHeads,
    numTokens,
    oProjInputDtype,
    oProjOutputDtype,
    qGateTensor,
    qTensor,
    qkNormApplied,
    queryPreAttnScalar,
    reusesSharedKV,
    ropeApplied,
    runtimeSession,
    kernelPath,
    skipKVCacheWrites,
    slidingWindow,
    state,
    storeSharedKV,
    usedFusedQKV,
    useF16Activations,
    vTensor,
  } = options;
  // A prepared selection is an operation fact, shared by kernel dispatch and
  // the semantic plan. Dropping it silently turns indexed attention dense.
  const indexedSelection = state.qsa != null;
  const dispatchConfig = {
    layerIdx, numTokens, isPrefill, numHeads, numKVHeads, headDim, hiddenSize,
    slidingWindow: diffusionGemmaDecoder ? null : slidingWindow,
    layerType, layerTypes: config.layerTypes,
    queryPreAttnScalar,
    causalAttention: diffusionGemmaDecoder ? false : config.causalAttention,
    activationDtype: attentionActivationDtype,
    kvCacheDtype: attentionPrecisionContract.resolvedKvCacheDtype ?? state.kvCache?.kvDtype ?? null,
    indexedSelection,
  };
  const dispatchParams = buildAttentionDispatchParams(dispatchConfig, state, kTensor, vTensor, kvState);
  const {
    effectiveSlidingWindow, attentionKernelVariant, attnScale,
    cachedKDtype, cachedVDtype, cachedKTensor, cachedVTensor,
    prefillFallbackNeedsCast, causalForAttention,
  } = dispatchParams;
  const attentionKernelPath = skipKVCacheWrites ? null : kernelPath;

  // 5. Attention

  recordAttentionInputs(state, buildAttentionInputsData(
    dispatchConfig, input, normed, kvState, dispatchParams,
    { useF16Activations, matmulOutputDtype },
    usedFusedQKV, qTensor, kTensor, vTensor,
  ));
  const mergedSessionRec = runtimeSession;
  const plannedOProjLoRA = getLoRAModule(lora, layerIdx, 'o_proj');
  const attentionPlan = resolveAttentionPlanForDispatch({
    config: {
      ...config,
      indexedSelection,
      kernelPath: attentionKernelPath,
    },
    inputDtype: input.dtype,
    activationDtype: attentionActivationDtype,
    projectionDtype: matmulOutputDtype,
    kvDtype: kvCacheDtype,
    outputProjectionInputDtype: oProjInputDtype,
    outputDtype: oProjOutputDtype,
    outputProjectionWeightDtype: layerWeights.oProj
      ? getWeightDtype(layerWeights.oProj)
      : null,
    outputProjectionHasLoRA: plannedOProjLoRA != null,
    session: mergedSessionRec,
    capabilities: getKernelCapabilities(),
    fusion: {
      inputNormProjection: canFuseInputNormProjRec,
      qkvProjection: usedFusedQKV,
      qkNorm: qkNormApplied,
      qkNormRoPE: qkNormApplied && ropeApplied,
    },
    qGateTensor,
    diagnosticsEligible: hasAttentionProjectionDiagnostics(state)
      || hasAttentionStageDiagnostics(state, ['q_proj', 'k_proj', 'v_proj', 'q_norm', 'k_norm']),
    sharedKV: {
      reuses: reusesSharedKV,
      stores: storeSharedKV,
    },
    kvState,
    dispatchParams,
  });
  if (attentionPlan.attention.implementation !== attentionKernelVariant) {
    throw new Error(
      `Attention plan/dispatch mismatch at layer ${layerIdx}: ` +
      `plan=${attentionPlan.attention.implementation}, dispatch=${attentionKernelVariant}.`
    );
  }
  if (state.observationContext?.receiptPolicy !== 'off') {
    state.stats.attentionPlans ??= [];
    state.stats.attentionPlans.push(attentionPlan);
  }

  return {
    attentionKernelVariant,
    attentionKernelPath,
    attentionPlan,
    attnScale,
    cachedKTensor,
    cachedKDtype,
    cachedVTensor,
    cachedVDtype,
    causalForAttention,
    effectiveSlidingWindow,
    prefillFallbackNeedsCast,
  };
}
