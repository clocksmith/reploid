import { decodeFloat16Array, float16ToFloat32 as f16ToF32 } from '../../formats/float16.js';

export { f16ToF32 };

// Caller should pass eps from model config; inline default for safety
export function rmsNormCPU(
  x,
  weight,
  eps = 1e-5,
  rmsNormWeightOffset = false
) {
  const n = x.length;
  let sumSq = 0;
  for (let i = 0; i < n; i++) {
    sumSq += x[i] * x[i];
  }
  const rms = Math.sqrt(sumSq / n + eps);

  const result = new Float32Array(n);
  for (let i = 0; i < n; i++) {
    const w = weight[i % weight.length];
    const scale = rmsNormWeightOffset ? 1 + w : w;
    result[i] = (x[i] / rms) * scale;
  }
  return result;
}

export function layerNormCPU(x, weight, bias, eps = 1e-5) {
  if (weight.length !== x.length || bias.length !== x.length) {
    throw new Error(
      `LayerNorm parameter length mismatch: input=${x.length}, weight=${weight.length}, bias=${bias.length}.`
    );
  }
  let sum = 0;
  for (let i = 0; i < x.length; i++) sum += x[i];
  const mean = sum / x.length;
  let squaredDeviation = 0;
  for (let i = 0; i < x.length; i++) {
    const centered = x[i] - mean;
    squaredDeviation += centered * centered;
  }
  const invStd = 1 / Math.sqrt(squaredDeviation / x.length + eps);
  const result = new Float32Array(x.length);
  for (let i = 0; i < x.length; i++) {
    result[i] = (x[i] - mean) * invStd * weight[i] + bias[i];
  }
  return result;
}


export function f16BufferToF32(data) {
  return decodeFloat16Array(new Uint16Array(data));
}


export function matmulCPU(
  input,
  weight,
  M,
  N,
  K,
  layout = 'row',
  weightStride
) {
  const result = new Float32Array(M * N);
  const stride = weightStride ?? (layout === 'row' ? K : N);

  for (let m = 0; m < M; m++) {
    for (let n = 0; n < N; n++) {
      let sum = 0;
      for (let k = 0; k < K; k++) {
        // Row layout: weight is [N, K] (vocab x hidden).
        // Column layout: weight is [K, N] (hidden x vocab).
        const weightIndex = layout === 'row'
          ? n * stride + k
          : k * stride + n;
        sum += input[m * K + k] * weight[weightIndex];
      }
      result[m * N + n] = sum;
    }
  }
  return result;
}


export function applySoftcapping(logits, cap) {
  for (let i = 0; i < logits.length; i++) {
    logits[i] = Math.tanh(logits[i] / cap) * cap;
  }
}
