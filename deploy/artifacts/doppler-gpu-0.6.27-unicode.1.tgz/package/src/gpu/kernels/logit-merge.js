

import { getDevice } from '../device.js';
import { getShaderScopeCacheKey } from './shader-source-scope.js';
import { log } from '../../debug/index.js';
import { WORKGROUP_SIZES } from './constants.js';
import { getShaderModule } from './shader-cache.js';







export class LogitMergeKernel {
  
  #device;

  
  #pipelines = new Map();

  
  #bindGroupLayout;

  
  #initialized = false;

  
  #deviceEpoch = -1;

  constructor() {
    this.#device = getDevice();
  }

  
  async init() {
    const deviceEpoch = getShaderScopeCacheKey();
    if (this.#initialized && this.#deviceEpoch === deviceEpoch) return;

    this.#initialized = false;
    this.#device = getDevice();
    this.#pipelines.clear();
    this.#bindGroupLayout = null;

    // Create bind group layout
    this.#bindGroupLayout = this.#device.createBindGroupLayout({
      label: 'logit-merge-layout',
      entries: [
        { binding: 0, visibility: GPUShaderStage.COMPUTE, buffer: { type: 'read-only-storage' } },
        { binding: 1, visibility: GPUShaderStage.COMPUTE, buffer: { type: 'read-only-storage' } },
        { binding: 2, visibility: GPUShaderStage.COMPUTE, buffer: { type: 'storage' } },
        { binding: 3, visibility: GPUShaderStage.COMPUTE, buffer: { type: 'uniform' } },
      ],
    });

    const pipelineLayout = this.#device.createPipelineLayout({
      label: 'logit-merge-pipeline-layout',
      bindGroupLayouts: [this.#bindGroupLayout],
    });

    // Create pipelines for each strategy
    const strategies = ['weighted', 'max', 'geometric'];

    for (const name of strategies) {
      const module = await getShaderModule(
        this.#device,
        `logit_merge_${name}.wgsl`,
        `logit-merge-${name}`
      );

      const pipeline = await this.#device.createComputePipelineAsync({
        label: `logit-merge-${name}-pipeline`,
        layout: pipelineLayout,
        compute: {
          module,
          entryPoint: 'main',
          constants: { WORKGROUP_SIZE: WORKGROUP_SIZES.DEFAULT },
        },
      });

      this.#pipelines.set( (name), pipeline);
    }

    this.#initialized = true;
    this.#deviceEpoch = deviceEpoch;
    log.info('LogitMerge', 'Kernel initialized');
  }

  
  async merge(logitsA, logitsB, vocabSize, config = {}) {
    await this.init();

    if (!config?.strategy) {
      throw new Error('LogitMerge strategy is required.');
    }
    if (!config?.weights) {
      throw new Error('LogitMerge weights are required.');
    }
    if (config?.temperature == null) {
      throw new Error('LogitMerge temperature is required.');
    }
    const strategy = config.strategy;
    const weights = normalizeWeights(config.weights, 2);
    const temperature = config.temperature;

    const pipeline = this.#pipelines.get(strategy);
    if (!pipeline) {
      throw new Error(`Unknown merge strategy: ${strategy}`);
    }

    // Create output buffer
    const mergedBuffer = this.#device.createBuffer({
      label: 'logit-merge-output',
      size: vocabSize * 4,
      usage: GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_SRC,
    });

    // Create params uniform buffer
    const paramsData = new Float32Array([
      vocabSize, // vocab_size (will be reinterpreted as u32)
      weights[0],
      weights[1],
      temperature,
    ]);
    // Fix: vocab_size needs to be u32
    const paramsView = new DataView(paramsData.buffer);
    paramsView.setUint32(0, vocabSize, true);

    const paramsBuffer = this.#device.createBuffer({
      label: 'logit-merge-params',
      size: 16,
      usage: GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST,
    });
    this.#device.queue.writeBuffer(paramsBuffer, 0, paramsData);

    // Create bind group
    const bindGroup = this.#device.createBindGroup({
      label: 'logit-merge-bindgroup',
      layout: this.#bindGroupLayout,
      entries: [
        { binding: 0, resource: { buffer: logitsA } },
        { binding: 1, resource: { buffer: logitsB } },
        { binding: 2, resource: { buffer: mergedBuffer } },
        { binding: 3, resource: { buffer: paramsBuffer } },
      ],
    });

    // Dispatch
    const encoder = this.#device.createCommandEncoder({ label: 'logit-merge' });
    const pass = encoder.beginComputePass({ label: 'logit-merge-pass' });
    pass.setPipeline(pipeline);
    pass.setBindGroup(0, bindGroup);
    pass.dispatchWorkgroups(Math.ceil(vocabSize / WORKGROUP_SIZES.DEFAULT));
    pass.end();

    this.#device.queue.submit([encoder.finish()]);
    this.#device.queue.onSubmittedWorkDone()
      .catch(() => {})
      .finally(() => {
        paramsBuffer.destroy();
      });

    return mergedBuffer;
  }

  
  async mergeMultiple(logitBuffers, vocabSize, config = {}) {
    if (logitBuffers.length === 0) {
      throw new Error('No logit buffers to merge');
    }

    if (logitBuffers.length === 1) {
      return logitBuffers[0];
    }

    if (logitBuffers.length === 2) {
      return this.merge(logitBuffers[0], logitBuffers[1], vocabSize, config);
    }

    // For more than 2 buffers, do pairwise reduction
    if (!config?.weights) {
      throw new Error('LogitMerge weights are required.');
    }
    if (config?.temperature == null) {
      throw new Error('LogitMerge temperature is required.');
    }
    const weights = normalizeWeights(config.weights, logitBuffers.length);

    // Normalize weights for pairwise reduction
    let totalWeight = 0;
    let current = logitBuffers[0];
    let currentWeight = weights[0];

    for (let i = 1; i < logitBuffers.length; i++) {
      totalWeight = currentWeight + weights[i];
      const normalizedWeightA = currentWeight / totalWeight;
      const normalizedWeightB = weights[i] / totalWeight;

      const merged = await this.merge(current, logitBuffers[i], vocabSize, {
        ...config,
        weights: [normalizedWeightA, normalizedWeightB],
        temperature: i === logitBuffers.length - 1 ? config.temperature : 1.0,
      });

      // Destroy intermediate buffer if not the original
      if (i > 1) {
        current.destroy();
      }

      current = merged;
      currentWeight = totalWeight;
    }

    return current;
  }
}

function normalizeWeights(weights, expectedCount) {
  if (!Array.isArray(weights) || weights.length !== expectedCount) {
    throw new Error(`LogitMerge weights must have length ${expectedCount}`);
  }

  let sum = 0;
  for (const weight of weights) {
    if (!Number.isFinite(weight)) {
      throw new Error('LogitMerge weights must be finite numbers');
    }
    if (weight < 0) {
      throw new Error('LogitMerge weights must be non-negative');
    }
    sum += weight;
  }

  if (sum <= 0) {
    throw new Error('LogitMerge weights must sum to a positive value');
  }

  return weights.map((weight) => weight / sum);
}

// Singleton instance
let _instance = null;


function getLogitMergeKernel() {
  if (!_instance) {
    _instance = new LogitMergeKernel();
  }
  return _instance;
}


export async function mergeMultipleLogits(logitBuffers, vocabSize, weights, temperature) {
  if (!weights) {
    throw new Error('LogitMerge weights are required.');
  }
  if (temperature == null) {
    throw new Error('LogitMerge temperature is required.');
  }
  const kernel = getLogitMergeKernel();
  return kernel.mergeMultiple(logitBuffers, vocabSize, {
    strategy: 'weighted',
    weights,
    temperature,
  });
}
