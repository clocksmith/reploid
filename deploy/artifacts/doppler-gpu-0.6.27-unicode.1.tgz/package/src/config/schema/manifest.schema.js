import { MB } from './units.schema.js';
import {
  assertSupportedManifestInference,
  validateRequiredInferenceFields,
} from '../manifest-inference-validation.js';

// =============================================================================
// Hash & Versioning
// =============================================================================

export const RDRR_VERSION = 1;

export const SHARD_SIZE = 64 * MB;

export const TENSORS_FILENAME = 'tensors.json';

// =============================================================================
// Parser Constants
// =============================================================================

// Maximum header size for model format parsing.
// GGUF/SafeTensors headers typically fit in first 100MB even for huge models.
export const MAX_HEADER_SIZE = 100 * MB;

// Smaller header read for streaming/browser imports. Originally 10 MB covered
// typical headers, but Gemma 4 E2B GGUF metadata (262144-token vocab stored as
// inline strings) overflows 10 MB. Bumped to 50 MB to cover large-vocab models
// while keeping Node-side reads bounded.
export const HEADER_READ_SIZE = 50 * MB;

// =============================================================================
// Epsilon Constants
// =============================================================================

// Default RMS normalization epsilon - used across all model types
export const DEFAULT_RMS_NORM_EPS = 1e-5;

// Higher precision epsilon for numerical stability in some operations
export const DEFAULT_HIGH_PRECISION_EPS = 1e-6;

// =============================================================================
// Inference Schema (Model-Specific Inference Parameters)
// =============================================================================

export const DEFAULT_MANIFEST_INFERENCE = {
  schema: null,
  // When true, allows workload="embedding" to dispatch via pipeline.embed()
  // (prefillWithEmbedding extraction) on text-generation models. Independent
  // of modelType: dedicated embedding models (modelType="embedding") always
  // support embedding workloads; text-generation models opt in explicitly.
  supportsEmbedding: false,
  // When true, exposes residue/base-level encoder outputs through
  // pipeline.encodeSequence(). The exact alphabet and output surfaces are
  // declared by inference.sequence; the runtime never infers them from a
  // model family name.
  supportsSequence: false,
  // When true, allows workload="rerank" to dispatch through prefillWithLogits()
  // using manifest-owned scoring metadata in inference.rerank.
  supportsRerank: false,
  // When true, the pipeline exposes pipeline.transcribeAudio({audio,...}) and
  // pipeline.embedAudio({audio}). Requires audio_token_id and audio encoder
  // weights to be present in the manifest. Defaults to false; set to true on
  // multimodal manifests that have completed audio-encoder conversion.
  supportsTranscription: false,
  // When true, the pipeline exposes pipeline.transcribeImage({...}),
  // pipeline.transcribeVideo({...}), and pipeline.embedImage({...}). Requires
  // image_token_id and vision encoder weights. Defaults to false; set to true
  // on multimodal manifests that have completed vision-encoder conversion.
  supportsVision: false,
  attention: {
    queryPreAttnScalar: 64, // headDim for standard 64-dim heads; attnScale = 1/sqrt(scalar)
    // Explicit multiplier applied to Q after optional Q/K normalization and before RoPE.
    queryScale: 1,
    attnLogitSoftcapping: null,  // No softcapping (null = disabled)
    slidingWindow: null,  // Full attention (null = no sliding window)
    queryKeyNorm: false,
    // Q/K normalization is normally per attention head RMSNorm (Qwen/Gemma).
    // Encoder families such as ESMC normalize the complete Q/K projection with
    // LayerNorm before reshaping into heads, so both semantics are explicit.
    queryKeyNormType: 'rmsnorm',
    queryKeyNormAxis: 'head',
    queryKeyNormLayers: null,
    queryKeyNormWeightLayers: null,
    valueNorm: false,
    causal: true,  // Causal mask enabled by default (decoder-style attention)
    attentionBias: false,
    attentionOutputGate: false,
    // null = sigmoid (historical default); 'swish'/'silu' = SiLU.
    // Read from HF `output_gate_type` at conversion time.
    outputGateType: null,
  },
  normalization: {
    // Transformer normalization family. Existing decoder manifests resolve to
    // rmsnorm; encoder checkpoints such as ESM-2 must declare layernorm.
    type: 'rmsnorm',
    rmsNormEps: DEFAULT_RMS_NORM_EPS,
    rmsNormWeightOffset: false,
    postNormEps: null,
    postNormWeightOffset: null,
    postAttentionNorm: false,
    preFeedforwardNorm: false,
    postFeedforwardNorm: false,
    // Exact optional tensor for the final LayerNorm bias. Per-layer norm bias
    // tensors use canonical *.bias names and are loaded with their layer.
    finalNormBiasTensor: null,
  },
  ffn: {
    activation: 'silu',
    gatedActivation: true,
    branchMode: 'auto',
    useDoubleWideMlp: false,
    swigluLimit: null,
  },
  rope: {
    ropeTheta: 10000,
    ropeLocalTheta: null,  // Same as ropeTheta (null = use ropeTheta)
    // Exact layer indices that bypass rotary position embeddings.
    disabledLayers: [],
    ropeInterleaved: false,
    mropeInterleaved: false,
    mropeSection: null,
    partialRotaryFactor: null,
    ropeLocalPartialRotaryFactor: null,
    ropeInverseFrequencies: null,
    ropeFrequencyBaseDim: null,
    ropeLocalFrequencyBaseDim: null,
    ropeScalingType: null,  // No scaling (null = disabled)
    ropeScalingFactor: 1.0,
    ropeLocalScalingType: null,  // Local scaling policy (null = no scaling)
    ropeLocalScalingFactor: 1.0,
    // YARN parameters - only relevant when ropeScalingType='yarn'
    yarnBetaFast: null,
    yarnBetaSlow: null,
    yarnOriginalMaxPos: null,
    // LongRoPE parameters - only relevant when ropeScalingType='longrope'
    longropeShortFactor: null,
    longropeLongFactor: null,
    longropeOriginalMaxPos: null,
    // Local YARN parameters - only relevant when ropeLocalScalingType='yarn'
    ropeLocalYarnBetaFast: null,
    ropeLocalYarnBetaSlow: null,
    ropeLocalYarnOriginalMaxPos: null,
  },
  output: {
    finalLogitSoftcapping: null,  // No softcapping (null = disabled)
    tieWordEmbeddings: false,
    scaleEmbeddings: false,
    embeddingScale: null,
    embeddingNormalization: null,
    logitInputScale: 1,
    logitOutputScale: 1,
    embeddingTranspose: false,
    embeddingVocabSize: null,
    embeddingPostprocessor: null,
    // Optional exact tensor name for an additive decoder/LM-head bias.
    lmHeadBiasTensor: null,
  },
  layerPattern: {
    type: 'uniform',  // All layers same type
    globalPattern: null,  // No alternating pattern (null = not applicable)
    period: null,  // No periodic pattern (null = not applicable)
    offset: null,  // For every_n: first global layer index modulo period
    layerTypes: null,  // For custom: explicit per-layer tags
    residualBranchScale: 1,
  },
  chatTemplate: {
    type: null,  // No chat template (null = disabled)
    enabled: false,
    thinking: null,  // Leave template thinking control unspecified
  },
  diffusionGemma: null,
  rerank: null,
  sequence: null,
  pipeline: null,
  session: null,
  execution: null,
};

// =============================================================================
// Validation Helpers
// =============================================================================

export function isV1Manifest(manifest) {
  return manifest.version === 1 && !!manifest.groups;
}

export function hasMoEConfig(manifest) {
  return manifest.moeConfig != null && manifest.moeConfig.numExperts > 1;
}

export function validateManifestInference(
  manifest
) {
  if (!manifest.inference) {
    throw new Error(
      `Manifest for "${manifest.modelId}" is missing required 'inference' field. ` +
      `This model was converted with an older version of DOPPLER. ` +
      `Please re-convert the model using the latest converter.`
    );
  }

  assertSupportedManifestInference(manifest);

  if (manifest.modelType === 'diffusion' || manifest.modelType === 'energy') {
    return;
  }

  const inference = typeof structuredClone === 'function'
    ? structuredClone(manifest.inference)
    : JSON.parse(JSON.stringify(manifest.inference));
  validateRequiredInferenceFields(
    inference,
    manifest.modelId ?? 'unknown'
  );
}

export function hasInferenceConfig(
  manifest
) {
  return manifest.inference != null;
}

// Returns true when the model supports embedding workloads. Dedicated
// embedding models (modelType="embedding") always do; text-generation
// models opt in via inference.supportsEmbedding=true so the harness will
// dispatch workload="embedding" through pipeline.embed() instead of
// rejecting it as a model-type mismatch.
export function modelSupportsEmbedding(manifest) {
  if (manifest?.modelType === 'embedding') return true;
  return manifest?.inference?.supportsEmbedding === true;
}

export function modelSupportsSequence(manifest) {
  return manifest?.inference?.supportsSequence === true
    && manifest?.inference?.sequence != null
    && typeof manifest.inference.sequence === 'object'
    && !Array.isArray(manifest.inference.sequence);
}

export function modelSupportsRerank(manifest) {
  return manifest?.inference?.supportsRerank === true
    && manifest?.inference?.rerank != null
    && typeof manifest.inference.rerank === 'object'
    && !Array.isArray(manifest.inference.rerank);
}

// Returns true when the manifest declares audio-input capability. Pipelines
// expose transcribeAudio + embedAudio when this is set. The de-facto runtime
// gate (audio_token_id + audio encoder weights) still applies; this field is
// the manifest-first declaration consumers can check before calling the
// transcribe/embedAudio methods.
export function modelSupportsTranscription(manifest) {
  return manifest?.inference?.supportsTranscription === true;
}

// Returns true when the manifest declares vision-input capability. Pipelines
// expose transcribeImage + transcribeVideo + embedImage when this is set.
export function modelSupportsVision(manifest) {
  return manifest?.inference?.supportsVision === true;
}
