import { getKernelConfig } from '../config/kernel-registry-contract.js';
import { selectRuleValue } from './rule-registry.js';
import { isPlainObject } from '../formats/plain-object.js';
import { EXECUTION_V1_SCHEMA_ID, expandExecutionV1 } from '../config/schema/index.js';
import { SUPPORTED_EXECUTION_V1_OPS } from '../config/supported-operations.js';

const KV_LAYOUTS = new Set(['contiguous', 'paged', 'tiered', 'bdpa']);
const PHASES = new Set(['prefill', 'decode', 'both']);
const TIERED_QUANT_MODES = new Set([
  'none',
  'int8',
  'int4',
  'turboquant',
  'turboquant_prod',
]);
const CONTIGUOUS_QUANT_MODES = new Set([
  'none',
  'turboquant',
  'turboquant_prod',
]);
const ATTENTION_OPS = new Set(['attention']);
const EMBED_OPS = new Set(['embed', 'gather']);
const SAMPLE_OPS = new Set(['sample']);
const BDPA_MAX_HEAD_DIM = 256;
const BDPA_MAX_KV_LEN = 2048;
const QUANTIZED_KV_MAX_HEAD_DIM = 256;
const UNSUPPORTED_TURBOQUANT_OUTLIER_MODE = 'turboquant_outlier';

function assertManifestObject(manifest) {
  if (!isPlainObject(manifest)) {
    throw new Error('execution contract: manifest must be an object.');
  }
  return manifest;
}

function assertPositiveInteger(value, label) {
  if (!Number.isInteger(value) || value < 0) {
    throw new Error(`execution contract: ${label} must be a non-negative integer.`);
  }
  return value;
}

function assertRequiredValue(value, label) {
  if (value == null) {
    throw new Error(`execution contract: ${label} is required.`);
  }
  return value;
}

function assertSupportedTurboQuantMode(mode, label) {
  if (mode !== UNSUPPORTED_TURBOQUANT_OUTLIER_MODE) {
    return mode;
  }
  throw new Error(
    `execution contract: ${label}="${mode}" is not supported. ` +
    'TurboQuant outlier high-precision buffers and decode kernels are not wired end to end; ' +
    'use "turboquant" or "turboquant_prod".'
  );
}

function assertBoolean(value, label) {
  if (value !== true && value !== false) {
    throw new Error(`execution contract: ${label} must be boolean.`);
  }
  return value;
}

function normalizeKVLayout(value) {
  const normalized = String(assertRequiredValue(value, 'session.kvcache.layout')).trim().toLowerCase();
  if (!KV_LAYOUTS.has(normalized)) {
    throw new Error(
      `execution contract: unsupported KV layout "${value}". ` +
      `Expected one of ${[...KV_LAYOUTS].join(', ')}.`
    );
  }
  return normalized;
}

function normalizePhase(value, label) {
  const normalized = String(value ?? '').trim().toLowerCase();
  if (!PHASES.has(normalized)) {
    throw new Error(
      `execution contract: ${label} must be one of ${[...PHASES].join(', ')}.`
    );
  }
  return normalized;
}

function getRequiredVariantMaxKVLen(operation, variant, errorLabel) {
  const config = getKernelConfig(operation, variant);
  const maxKVLen = config.variantMetadata?.maxKVLen;
  if (!Number.isFinite(maxKVLen) || maxKVLen <= 0) {
    throw new Error(`execution contract: kernel ${errorLabel} "${variant}" is missing variantMetadata.maxKVLen.`);
  }
  return maxKVLen;
}

function getTieredQuantMaxKVLen(mode) {
  const variant = selectRuleValue('kernels', 'attention', 'tieredQuantVariant', { mode });
  return getRequiredVariantMaxKVLen(
    'attention_tiered_quant',
    variant,
    'attention_tiered_quant'
  );
}

function getContiguousQuantMaxKVLen(mode) {
  const variant = selectRuleValue('kernels', 'attention', 'contiguousQuantVariant', { mode });
  return getRequiredVariantMaxKVLen(
    'attention_contiguous_quant',
    variant,
    'attention_contiguous_quant'
  );
}

function normalizeTieredQuantMode(kvcache) {
  const tiering = assertRequiredValue(kvcache?.tiering, 'session.kvcache.tiering');
  const tieringMode = String(
    assertRequiredValue(tiering.mode, 'session.kvcache.tiering.mode')
  ).trim().toLowerCase();
  assertSupportedTurboQuantMode(tieringMode, 'session.kvcache.tiering.mode');
  const gatingMode = String(
    assertRequiredValue(kvcache?.tiering?.gating?.mode, 'session.kvcache.tiering.gating.mode')
  ).trim().toLowerCase();
  if (gatingMode === 'force_off' || tieringMode === 'off' || tieringMode === 'fp16') {
    return 'none';
  }
  const compressionMode = String(
    assertRequiredValue(
      kvcache?.tiering?.compression?.mode,
      'session.kvcache.tiering.compression.mode'
    )
  ).trim().toLowerCase();
  assertSupportedTurboQuantMode(compressionMode, 'session.kvcache.tiering.compression.mode');
  if (!TIERED_QUANT_MODES.has(compressionMode)) {
    throw new Error(
      `execution contract: unsupported tiered cold quant mode "${compressionMode}".`
    );
  }
  return compressionMode;
}

function normalizeContiguousQuantMode(kvcache) {
  const quantMode = String(
    assertRequiredValue(kvcache?.quantization?.mode, 'session.kvcache.quantization.mode')
  ).trim().toLowerCase();
  assertSupportedTurboQuantMode(quantMode, 'session.kvcache.quantization.mode');
  if (!CONTIGUOUS_QUANT_MODES.has(quantMode)) {
    throw new Error(
      `execution contract: unsupported contiguous quant mode "${quantMode}".`
    );
  }
  return quantMode;
}

function resolveSessionKVLen(architectureMaxSeqLen, sessionMaxSeqLen) {
  const architectureKVLen = assertPositiveInteger(
    assertRequiredValue(
      architectureMaxSeqLen ?? sessionMaxSeqLen,
      'architecture.maxSeqLen'
    ),
    'architecture.maxSeqLen'
  );
  if (sessionMaxSeqLen == null) {
    return architectureKVLen;
  }
  const sessionKVLen = assertPositiveInteger(sessionMaxSeqLen, 'session.kvcache.maxSeqLen');
  if (sessionKVLen <= 0) {
    throw new Error('execution contract: session.kvcache.maxSeqLen must be greater than zero.');
  }
  return Math.min(architectureKVLen, sessionKVLen);
}

function classifyOp(op) {
  const normalized = String(op ?? '').trim().toLowerCase();
  if (!normalized) {
    throw new Error('execution contract: execution step op is required.');
  }
  if (ATTENTION_OPS.has(normalized)) return 'attention';
  if (EMBED_OPS.has(normalized)) return 'embed';
  if (SAMPLE_OPS.has(normalized)) return 'sample';
  if (normalized.includes('norm')) return 'norm';
  if (normalized.includes('residual')) return 'residual';
  if (normalized.endsWith('_proj') || normalized.startsWith('rope_') || normalized === 'activation') {
    return 'projection';
  }
  return 'other';
}

export function sanitizeLeanModuleName(value) {
  const raw = String(value ?? 'GeneratedExecutionContractCheck').trim();
  const alnum = raw.replace(/[^A-Za-z0-9_]/g, '_');
  if (!alnum) {
    return 'GeneratedExecutionContractCheck';
  }
  if (/^[A-Za-z_]/.test(alnum)) {
    return alnum;
  }
  return `Generated_${alnum}`;
}

export function extractExecutionContractFacts(manifest) {
  const normalizedManifest = assertManifestObject(manifest);
  const modelId = String(normalizedManifest.modelId ?? 'model').trim() || 'model';
  const architecture = isPlainObject(normalizedManifest.architecture)
    ? normalizedManifest.architecture
    : {};
  const inference = isPlainObject(normalizedManifest.inference)
    ? normalizedManifest.inference
    : {};
  const session = isPlainObject(inference.session) ? inference.session : {};
  const execution = isPlainObject(inference.execution)
    ? inference.execution
    : {};
  const kvcache = isPlainObject(session.kvcache)
    ? session.kvcache
    : {};
  const decodeLoop = isPlainObject(session.decodeLoop)
    ? session.decodeLoop
    : {};

  let steps = [];
  if (Array.isArray(execution.steps)) {
    steps = execution.steps.map((step, index) => {
      if (!isPlainObject(step)) {
        throw new Error(`execution contract: execution.steps[${index}] must be an object.`);
      }
      const id = String(step.id ?? '').trim();
      if (!id) {
        throw new Error(`execution contract: execution.steps[${index}].id is required.`);
      }
      return {
        id,
        phase: normalizePhase(step.phase, `execution.steps[${index}].phase`),
        opClass: classifyOp(step.op),
      };
    });
  } else if (
    inference.schema === EXECUTION_V1_SCHEMA_ID
    && isPlainObject(execution.kernels)
  ) {
    const expanded = expandExecutionV1(execution, {
      knownOps: SUPPORTED_EXECUTION_V1_OPS,
      strict: true,
    });
    steps = expanded.map((step, index) => ({
      id: `${step.section}_${step.phase}_${index}_${step.op}`,
      phase: normalizePhase(step.phase, `execution graph step ${index} phase`),
      opClass: classifyOp(step.op),
    }));
  }

  return {
    modelId,
    session: {
      layout: normalizeKVLayout(kvcache.layout),
      disableCommandBatching: assertBoolean(
        decodeLoop.disableCommandBatching,
        'session.decodeLoop.disableCommandBatching'
      ),
      decodeBatchSize: assertPositiveInteger(
        assertRequiredValue(decodeLoop.batchSize, 'session.decodeLoop.batchSize'),
        'session.decodeLoop.batchSize'
      ),
      headDim: assertPositiveInteger(architecture.headDim, 'architecture.headDim'),
      kvLen: resolveSessionKVLen(architecture.maxSeqLen, kvcache.maxSeqLen),
      coldQuantMode: normalizeTieredQuantMode(kvcache),
      contiguousQuantMode: normalizeContiguousQuantMode(kvcache),
    },
    steps,
  };
}

export function validateExecutionContractFacts(facts) {
  const errors = [];
  const checks = [];
  const modelId = String(facts?.modelId ?? 'model');
  const session = facts?.session ?? {};
  const steps = Array.isArray(facts?.steps) ? facts.steps : [];

  const incompatibleStep = session.layout === 'bdpa'
    ? steps.find((step) => step.opClass === 'attention' && (step.phase === 'prefill' || step.phase === 'both'))
    : null;
  if (incompatibleStep) {
    errors.push(
      `[ExecutionContract] session.kvcache.layout="bdpa" is decode-only, ` +
      `but step "${incompatibleStep.id}" declares ${incompatibleStep.phase} attention.`
    );
  }
  checks.push({
    id: `${modelId}.steps`,
    ok: incompatibleStep == null,
  });

  const sessionErrorCount = errors.length;
  if (session.layout === 'bdpa') {
    if (session.disableCommandBatching !== true) {
      errors.push(
        '[ExecutionContract] session.kvcache.layout="bdpa" requires ' +
        'session.decodeLoop.disableCommandBatching=true.'
      );
    }
    if (session.decodeBatchSize > 1) {
      errors.push(
        `[ExecutionContract] session.kvcache.layout="bdpa" requires ` +
        `session.decodeLoop.batchSize <= 1; got ${session.decodeBatchSize}.`
      );
    }
    if (session.headDim > BDPA_MAX_HEAD_DIM) {
      errors.push(
        `[ExecutionContract] session.kvcache.layout="bdpa" requires architecture.headDim <= ${BDPA_MAX_HEAD_DIM}; ` +
        `got ${session.headDim}.`
      );
    }
    if (session.kvLen > BDPA_MAX_KV_LEN) {
      errors.push(
        `[ExecutionContract] session.kvcache.layout="bdpa" requires architecture.maxSeqLen <= ${BDPA_MAX_KV_LEN}; ` +
        `got ${session.kvLen}.`
      );
    }
  }

  if (
    session.layout === 'tiered'
    && session.coldQuantMode !== 'none'
  ) {
    if (session.headDim > QUANTIZED_KV_MAX_HEAD_DIM) {
      errors.push(
        `[ExecutionContract] session.kvcache.layout="tiered" with cold quantization requires ` +
        `architecture.headDim <= ${QUANTIZED_KV_MAX_HEAD_DIM}; got ${session.headDim}.`
      );
    }
    const maxKVLen = getTieredQuantMaxKVLen(session.coldQuantMode);
    if (session.kvLen > maxKVLen) {
      errors.push(
        `[ExecutionContract] session.kvcache.layout="tiered" with cold quantization requires ` +
        `effective maxSeqLen <= ${maxKVLen}; got ${session.kvLen}.`
      );
    }
  }

  if (
    session.layout === 'contiguous'
    && session.contiguousQuantMode !== 'none'
  ) {
    if (session.headDim > QUANTIZED_KV_MAX_HEAD_DIM) {
      errors.push(
        `[ExecutionContract] session.kvcache.layout="contiguous" with quantization.mode="${session.contiguousQuantMode}" ` +
        `requires architecture.headDim <= ${QUANTIZED_KV_MAX_HEAD_DIM}; got ${session.headDim}.`
      );
    }
    const maxKVLen = getContiguousQuantMaxKVLen(session.contiguousQuantMode);
    if (session.kvLen > maxKVLen) {
      errors.push(
        `[ExecutionContract] session.kvcache.layout="contiguous" with quantization.mode="${session.contiguousQuantMode}" ` +
        `requires effective maxSeqLen <= ${maxKVLen}; got ${session.kvLen}.`
      );
    }
  }

  checks.push({
    id: `${modelId}.session`,
    ok: errors.length === sessionErrorCount,
  });

  return {
    ok: errors.length === 0,
    errors,
    checks,
  };
}

export function validateManifestExecutionContract(manifest) {
  const facts = extractExecutionContractFacts(manifest);
  const evaluation = validateExecutionContractFacts(facts);
  return {
    ...evaluation,
    facts,
  };
}

export function buildExecutionContractArtifact(manifest) {
  if (!manifest || typeof manifest !== 'object') {
    return null;
  }
  if (
    manifest.modelType === 'diffusion'
    || manifest.modelType === 'energy'
    || manifest.modelType === 'embedding'
  ) {
    return null;
  }
  if (!manifest.architecture || !manifest.inference || typeof manifest.inference !== 'object') {
    return null;
  }
  try {
    const evaluation = validateManifestExecutionContract(manifest);
    const attentionPhaseCounts = { prefill: 0, decode: 0, both: 0 };
    for (const step of evaluation.facts.steps) {
      if (step.opClass !== 'attention') continue;
      if (Object.prototype.hasOwnProperty.call(attentionPhaseCounts, step.phase)) {
        attentionPhaseCounts[step.phase] += 1;
      }
    }
    return {
      schemaVersion: 1,
      source: 'doppler',
      ok: evaluation.ok,
      checks: [...evaluation.checks],
      errors: [...evaluation.errors],
      session: evaluation.facts.session,
      steps: {
        total: evaluation.facts.steps.length,
        attention: attentionPhaseCounts.prefill + attentionPhaseCounts.decode + attentionPhaseCounts.both,
        attentionPhases: attentionPhaseCounts,
      },
    };
  } catch (error) {
    return {
      schemaVersion: 1,
      source: 'doppler',
      ok: false,
      checks: [],
      errors: [error instanceof Error ? error.message : String(error)],
      session: null,
      steps: null,
    };
  }
}
