import { assertCanonicalModelId, assertModelIdDescribesFormat } from './model-naming.js';
import {
  EXECUTION_V1_SCHEMA_ID,
  expandExecutionV1,
} from '../config/schema/index.js';
import { validateRequiredInferenceFields } from '../inference/pipelines/text/config.js';
import {
  buildModelNameSuffix,
  buildQuantizationInfo,
  normalizeQuantTag,
  resolveManifestQuantization,
  resolveModelId,
} from './quantization-info.js';
import { cloneJsonValue } from '../formats/clone-json.js';
import { resolveManifestMoEConfig, sanitizeModelId } from './core.js';
import { assertConvertedLinearNormGateActivation } from './linear-norm-gate.js';
import { assertConvertedQwen4ExpContracts } from './qwen4-exp-source.js';
import { resolveTensorRole } from '../formats/rdrr/index.js';
import { selectRuleValue } from '../rules/rule-registry.js';
import { log } from '../debug/index.js';

function normalizeWeightDtype(dtype) {
  if (!dtype) return null;
  const lower = String(dtype).trim().toLowerCase();
  const upper = String(dtype).trim().toUpperCase();
  const normalized = selectRuleValue('inference', 'dtype', 'f16OrF32FromDtypeAlias', {
    dtype: lower,
    fallback: upper,
  });
  return normalized ? normalized.toUpperCase() : null;
}

function findTensorDtypeByRole(tensors, targetRole) {
  for (const tensor of (tensors || [])) {
    const name = typeof tensor?.name === 'string' ? tensor.name : '';
    if (!name) continue;
    if (resolveTensorRole(tensor) === targetRole) {
      return tensor?.dtype ?? null;
    }
  }
  return null;
}

function hasAnyTensorPattern(tensors, patterns) {
  const names = (tensors || []).map((t) => String(t?.name || '').toLowerCase());
  return names.some((name) => patterns.some((pattern) => name.includes(pattern)));
}

export function inferSourceWeightQuantization(tensors) {
  if (!Array.isArray(tensors) || tensors.length === 0) {
    throw new Error(
      'Cannot infer source weight quantization: no tensors provided. ' +
      'Set converterConfig.quantization.weights explicitly.'
    );
  }
  const weightTensors = [];
  for (const tensor of tensors) {
    const name = typeof tensor?.name === 'string' ? tensor.name : '';
    if (!name.includes('.weight')) continue;
    const dtype = normalizeWeightDtype(tensor?.dtype);
    if (!dtype) continue;
    weightTensors.push({ name, dtype });
  }
  const dtypes = new Set(weightTensors.map((tensor) => tensor.dtype));
  if (dtypes.size === 0) {
    throw new Error(
      'Cannot infer source weight quantization: no recognizable weight dtypes found. ' +
      'Set converterConfig.quantization.weights explicitly.'
    );
  }
  if (dtypes.size > 1) {
    const detail = Array.from(dtypes)
      .sort()
      .map((dtype) => {
        const names = weightTensors
          .filter((tensor) => tensor.dtype === dtype)
          .slice(0, 2)
          .map((tensor) => tensor.name);
        return names.length > 0 ? `${dtype} (${names.join(', ')})` : dtype;
      })
      .join('; ');
    throw new Error(
      `Ambiguous source weight dtypes: ${Array.from(dtypes).sort().join(', ')}. ` +
      `Samples: ${detail}. Set converterConfig.quantization.weights to override.`
    );
  }
  if (dtypes.size === 1) {
    return normalizeQuantTag([...dtypes][0]);
  }
  if (dtypes.has('F32')) return 'f32';
  return 'f16';
}

function isV1Config(converterConfig) {
  const exec = converterConfig?.execution;
  return exec && typeof exec === 'object' && exec.kernels && typeof exec.kernels === 'object';
}

function validateV1InferenceFields(inference, modelId) {
  const required = ['attention', 'normalization', 'ffn', 'rope', 'output', 'chatTemplate'];
  for (const field of required) {
    if (!inference?.[field] || typeof inference[field] !== 'object') {
      throw new Error(
        `Config for "${modelId}" is missing required inference.${field}. ` +
        'V1 configs must provide all inference fields explicitly (no implicit fallback).'
      );
    }
  }
  validateRequiredInferenceFields(
    cloneJsonValue(inference),
    modelId
  );
}


function resolveConversionPlanV1(options) {
  const rawConfig = options?.rawConfig || {};
  const tensors = Array.isArray(options?.tensors) ? options.tensors : [];
  const converterConfig = options.converterConfig;
  const rawInference = converterConfig.inference;
  const inference = rawInference && typeof rawInference === 'object'
    ? {
      ...rawInference,
      attention: rawInference.attention && typeof rawInference.attention === 'object'
        ? {
          queryKeyNormType: 'rmsnorm',
          queryKeyNormAxis: 'head',
          ...rawInference.attention,
        }
        : rawInference.attention,
    }
    : rawInference;
  const execution = converterConfig.execution;
  const session = converterConfig.session;
  const modelType = converterConfig.modelType;
  if (typeof modelType !== 'string' || modelType.length === 0 || modelType !== modelType.trim()) {
    throw new Error(
      'V1 conversion config requires an explicit modelType naming the runtime pipeline ' +
      '(for example "transformer"). Source model_type identifies an architecture, not a runtime pipeline.'
    );
  }
  const requiresSessionPolicy = modelType !== 'embedding';

  if (!inference || typeof inference !== 'object') {
    throw new Error(
      'V1 config requires an explicit inference section with all model inference fields.'
    );
  }
  if (!execution?.kernels || !execution?.decode || !execution?.prefill) {
    throw new Error(
      'V1 config requires execution with kernels, decode, and prefill arrays.'
    );
  }
  if (requiresSessionPolicy && (!session || typeof session !== 'object')) {
    throw new Error(
      'V1 config requires session with compute defaults and kvcache policy.'
    );
  }
  if (!execution.policies || typeof execution.policies !== 'object') {
    throw new Error(
      'V1 config requires execution.policies.'
    );
  }

  // Validate the execution graph expands correctly (fail fast on bad tuples/kernels)
  expandExecutionV1(execution);

  const modelId = converterConfig?.output?.modelBaseId ?? rawConfig?.model_id ?? 'unknown';
  validateV1InferenceFields(inference, modelId);
  assertConvertedLinearNormGateActivation(inference, rawConfig, modelId, options?.establishedLinearNormGateActivation ?? null);
  assertConvertedQwen4ExpContracts(inference, rawConfig, modelId);

  const sourceQuantization = (
    options?.sourceQuantization
    ?? converterConfig?.quantization?.weights
    ?? inferSourceWeightQuantization(tensors)
  );
  const weightOverride = converterConfig?.quantization?.weights ?? null;
  const embedDtypeRaw = normalizeWeightDtype(findTensorDtypeByRole(tensors, 'embedding'));
  const lmHeadDtypeRaw = normalizeWeightDtype(findTensorDtypeByRole(tensors, 'lm_head'));
  const hasVision = hasAnyTensorPattern(tensors, ['vision_', 'vision_tower', 'vision_model', 'image_encoder', 'visual.', 'embed_vision']);
  const hasAudio = hasAnyTensorPattern(tensors, ['audio_', 'audio_encoder', 'whisper', 'wav2vec']);
  const hasProjector = hasAnyTensorPattern(tensors, ['multi_modal_projector', 'mm_projector', 'projector', 'embed_vision']);
  const quantizationInfo = buildQuantizationInfo(
    converterConfig,
    sourceQuantization,
    embedDtypeRaw,
    lmHeadDtypeRaw,
    hasVision,
    hasAudio,
    hasProjector,
    rawConfig
  );
  const manifestQuantization = resolveManifestQuantization(weightOverride, sourceQuantization);
  const moeConfig = resolveManifestMoEConfig(
    { tensors, config: rawConfig },
    {
      modelId,
      moeConfig: converterConfig?.moeConfig ?? null,
      quantizationInfo,
    },
    rawConfig,
    modelType
  );

  // Warn if tensor count seems low for the declared architecture.
  // A typical transformer layer has at least 4 weight tensors (QKV + O projections),
  // plus embeddings and output head, so numLayers * 4 is a rough lower bound.
  const archLayers = converterConfig?.architecture?.numLayers
    ?? rawConfig?.num_hidden_layers
    ?? null;
  if (archLayers != null && tensors.length > 0) {
    const minExpected = archLayers * 4;
    if (tensors.length < minExpected) {
      log.warn(
        'Convert',
        `Tensor count (${tensors.length}) seems low for ${archLayers}-layer architecture ` +
        `(expected at least ~${minExpected}). Verify source checkpoint is complete.`
      );
    }
  }

  // Build manifest inference directly from config (no external family resolution)
  const manifestInference = {
    schema: EXECUTION_V1_SCHEMA_ID,
    attention: inference.attention,
    normalization: inference.normalization,
    ffn: inference.ffn,
    rope: inference.rope,
    output: inference.output,
    layerPattern: inference.layerPattern ?? { type: 'uniform', globalPattern: null, period: null, offset: null, layerTypes: null },
    chatTemplate: inference.chatTemplate,
    supportsEmbedding: inference.supportsEmbedding ?? false,
    supportsSequence: inference.supportsSequence ?? false,
    supportsRerank: inference.supportsRerank ?? false,
    supportsTranscription: inference.supportsTranscription ?? false,
    supportsVision: inference.supportsVision ?? false,
    rerank: inference.rerank ?? null,
    sequence: inference.sequence ?? null,
    diffusionGemma: inference.diffusionGemma ?? null,
    hyperConnections: inference.hyperConnections ?? null,
    indexedAttention: inference.indexedAttention ?? null,
    ngramEmbedding: inference.ngramEmbedding ?? null,
    pipeline: inference.pipeline ?? null,
    session,
    execution,
  };

  return {
    modelType,
    sourceQuantization,
    quantizationInfo,
    moeConfig,
    manifestQuantization,
    manifestInference,
    headDim: options?.headDim ?? options?.architectureConfig?.headDim ?? null,
    executionVersion: 'v1',
  };
}


export function resolveConversionPlan(options) {
  const converterConfig = options?.converterConfig;
  if (converterConfig == null) {
    throw new Error(
      'resolveConversionPlan requires an explicit converterConfig. ' +
      'Provide a conversion config JSON (see src/config/conversion/ for examples).'
    );
  }

  // V1 config: explicit execution graph — the only supported converter path
  if (isV1Config(converterConfig)) {
    return resolveConversionPlanV1(options);
  }

  throw new Error(
    'converterConfig must have an execution.kernels object (v1 format). ' +
    'Legacy conversion (v0) is no longer supported. ' +
    'Use a v1 conversion config — see src/config/conversion/ for examples.'
  );
}

export function resolveConvertedModelId(options) {
  const explicitModelId = options?.explicitModelId ?? null;
  const converterConfig = options?.converterConfig ?? null;
  const explicitModelBaseId = converterConfig?.output?.modelBaseId ?? null;
  const detectedModelId = options?.detectedModelId ?? null;
  const quantizationInfo = options?.quantizationInfo ?? null;
  const fallbackModelId = options?.fallbackModelId ?? null;
  const sanitizeOnly = options?.sanitizeOnly === true;
  // Names are lowercase letters, digits and hyphens. A new ID that breaks the rule is refused here, on every
  // path, before it is written into a manifest and becomes part of an identity. Where the model's format is
  // known the name must also end with the suffix that format generates; only a direct-source runtime label,
  // which names no published identity, is excused from that.
  const nameSuffix = sanitizeOnly || options?.runtimeLabel === true ? '' : buildModelNameSuffix(quantizationInfo);
  const accept = (modelId) => {
    if (modelId === null) return null;
    assertCanonicalModelId(modelId, 'Converted model ID');
    if (nameSuffix) {
      assertModelIdDescribesFormat(modelId, nameSuffix, 'Converted model ID');
    }
    return modelId;
  };

  if (explicitModelId) {
    return accept(sanitizeModelId(explicitModelId));
  }

  const baseModelId = (
    explicitModelBaseId
    ?? detectedModelId
    ?? fallbackModelId
  );
  if (!baseModelId) return null;

  const hasExplicitBaseModelId = Boolean(
    explicitModelBaseId && String(explicitModelBaseId).trim() !== ''
  );

  const resolved = sanitizeOnly
    ? baseModelId
    : (
      hasExplicitBaseModelId
        ? baseModelId
        : resolveModelId(baseModelId, detectedModelId ?? baseModelId, quantizationInfo?.variantTag, nameSuffix || undefined)
    );
  return accept(sanitizeModelId(resolved));
}
