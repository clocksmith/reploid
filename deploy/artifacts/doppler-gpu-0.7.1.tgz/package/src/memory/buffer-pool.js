import { log, trace, isTraceEnabled } from '../debug/index.js';
import { getRuntimeConfig } from '../config/runtime.js';
import { getBufferDevice, isDeviceLost, observeDeviceLoss, registerBufferDevice } from './device-residency.js';
import { allowReadback, trackAllocation } from '../debug/perf-guards.js';

// Pools take devices as arguments. Only the ambient convenience API needs the
// current device; gpu/device.js installs that resolver when loaded (before it
// no Doppler device exists). Device module instances share one state holder.
let resolveCurrentDevice = () => null;
export function installBufferPoolDeviceRuntime(getCurrentDevice) {
  if (typeof getCurrentDevice !== 'function') throw new Error('Buffer pool device runtime requires a current-device resolver.');
  resolveCurrentDevice = getCurrentDevice;
}
const currentDevice = () => resolveCurrentDevice() ?? null;

const bufferPools = new WeakMap();

const RESOLVED_GPU_BUFFER_USAGE = (
  typeof GPUBufferUsage === 'object'
  && GPUBufferUsage
)
  ? GPUBufferUsage
  : {
    MAP_READ: 0x0001,
    MAP_WRITE: 0x0002,
    COPY_SRC: 0x0004,
    COPY_DST: 0x0008,
    INDEX: 0x0010,
    VERTEX: 0x0020,
    UNIFORM: 0x0040,
    STORAGE: 0x0080,
    INDIRECT: 0x0100,
    QUERY_RESOLVE: 0x0200,
  };

const RESOLVED_GPU_MAP_MODE = (
  typeof GPUMapMode === 'object'
  && GPUMapMode
)
  ? GPUMapMode
  : {
    READ: 1 << 0,
    WRITE: 1 << 1,
  };

export const BufferUsage =  ({
  STORAGE: RESOLVED_GPU_BUFFER_USAGE.STORAGE
    | RESOLVED_GPU_BUFFER_USAGE.COPY_DST
    | RESOLVED_GPU_BUFFER_USAGE.COPY_SRC,
  STORAGE_READ: RESOLVED_GPU_BUFFER_USAGE.STORAGE
    | RESOLVED_GPU_BUFFER_USAGE.COPY_DST,
  UNIFORM: RESOLVED_GPU_BUFFER_USAGE.UNIFORM
    | RESOLVED_GPU_BUFFER_USAGE.COPY_DST,
  STAGING_READ: RESOLVED_GPU_BUFFER_USAGE.MAP_READ
    | RESOLVED_GPU_BUFFER_USAGE.COPY_DST,
  STAGING_WRITE: RESOLVED_GPU_BUFFER_USAGE.MAP_WRITE
    | RESOLVED_GPU_BUFFER_USAGE.COPY_SRC,
});

function alignTo(size, alignment) {
  return Math.ceil(size / alignment) * alignment;
}

function getSizeBucket(
  size,
  maxAllowedSize = Infinity,
  bucketConfig
) {
  if (
    !bucketConfig
    || typeof bucketConfig.minBucketSizeBytes !== 'number'
    || typeof bucketConfig.largeBufferThresholdBytes !== 'number'
    || typeof bucketConfig.largeBufferStepBytes !== 'number'
  ) {
    throw new Error(
      'getSizeBucket requires bucketConfig with minBucketSizeBytes, largeBufferThresholdBytes, and largeBufferStepBytes.'
    );
  }
  // Bucket selection uses three size thresholds:
  // 1. minBucketSizeBytes: sizes at or below this get the minimum bucket (avoids tiny buffers).
  // 2. largeBufferThresholdBytes: sizes at or above this use coarse-grained linear stepping
  //    instead of power-of-two rounding, to avoid doubling large allocations (e.g. 600MB -> 1GB).
  // 3. Sizes between minBucket and largeThreshold use power-of-two rounding for pooling efficiency.
  // If a computed bucket exceeds maxAllowedSize (device limit), the size is aligned to minBucket instead.
  const minBucket = bucketConfig.minBucketSizeBytes;
  if (size <= minBucket) return minBucket;

  const largeThreshold = bucketConfig.largeBufferThresholdBytes;
  if (size >= largeThreshold) {
    const largeStep = bucketConfig.largeBufferStepBytes;
    const bucket = Math.ceil(size / largeStep) * largeStep;
    if (bucket > maxAllowedSize) {
      return alignTo(size, minBucket);
    }
    return bucket;
  }

  // Round up to next power of 2
  // Use Math.pow instead of bit shift to avoid 32-bit signed integer overflow
  // (1 << 31 = -2147483648 in JavaScript due to signed 32-bit arithmetic)
  const bits = 32 - Math.clz32(size - 1);
  const bucket = Math.pow(2, bits);

  // If bucket exceeds device limit, fall back to aligned size
  if (bucket > maxAllowedSize) {
    return alignTo(size, minBucket);
  }
  return bucket;
}

export class BufferPool {
  // Pools organized by usage and size bucket
  #pools;
  #totalPooledBuffers;
  // Active buffers (currently in use)
  #activeBuffers;
  // Buffer metadata for leak detection (debug mode)
  #bufferMetadata;
  // Requested sizes per buffer (unbucketed intent)
  #requestedSizes;
  // Buffer ID tracking (for trace)
  #bufferIds;
  #bufferLabels;
  #nextBufferId;
  // Deferred destruction queue (buffers destroyed after GPU work completes)
  #pendingDestruction;
  #destructionScheduled;
  // Statistics
  #stats;
  // Configuration
  #config;
  // Schema-based configuration
  #schemaConfig;
  // Debug mode flag
  #debugMode;
  // Device-scoped ownership for pooled buffers
  #device;
  #destroyed = false;

  constructor(debugMode = false, schemaConfig, device = currentDevice()) {
    if (!schemaConfig) {
      throw new Error('BufferPool requires schemaConfig from runtime.shared.bufferPool.');
    }
    if (!schemaConfig.limits || typeof schemaConfig.limits.maxBuffersPerBucket !== 'number' || typeof schemaConfig.limits.maxTotalPooledBuffers !== 'number') {
      throw new Error('BufferPool schemaConfig.limits must include maxBuffersPerBucket and maxTotalPooledBuffers.');
    }
    if (!schemaConfig.alignment || typeof schemaConfig.alignment.alignmentBytes !== 'number') {
      throw new Error('BufferPool schemaConfig.alignment must include alignmentBytes.');
    }
    if (!schemaConfig.bucket || typeof schemaConfig.bucket.minBucketSizeBytes !== 'number') {
      throw new Error('BufferPool schemaConfig.bucket must include minBucketSizeBytes.');
    }
    this.#pools = new Map();
    this.#totalPooledBuffers = 0;
    this.#activeBuffers = new Set();
    this.#bufferMetadata = new Map();
    this.#requestedSizes = new Map();
    this.#bufferIds = new WeakMap();
    this.#bufferLabels = new WeakMap();
    this.#nextBufferId = 1;
    this.#debugMode = debugMode;
    this.#schemaConfig = structuredClone(schemaConfig);
    this.#pendingDestruction = new Set();
    this.#destructionScheduled = false;
    this.#device = device;
    observeDeviceLoss(device);
    device?.lost?.then(() => this.destroy(), () => this.destroy());

    this.#stats = {
      allocations: 0,
      reuses: 0,
      totalBytesAllocated: 0,
      peakBytesAllocated: 0,
      currentBytesAllocated: 0,
      totalBytesRequested: 0,
      peakBytesRequested: 0,
      currentBytesRequested: 0,
    };

    // Initialize from schema config
    this.#config = {
      maxPoolSizePerBucket: this.#schemaConfig.limits.maxBuffersPerBucket,
      maxTotalPooledBuffers: this.#schemaConfig.limits.maxTotalPooledBuffers,
      enablePooling: true,
      alignmentBytes: this.#schemaConfig.alignment.alignmentBytes,
    };
  }
  #isEmpty() {
    return this.#activeBuffers.size === 0
      && this.#getTotalPooledCount() === 0
      && this.#pendingDestruction.size === 0;
  }
  #getBoundDevice() {
    if (this.#destroyed || isDeviceLost(this.#device)) throw new Error('BufferPool owner is closed or its GPU device is lost.');
    return this.#device;
  }

  acquire(size, usage = BufferUsage.STORAGE, label = 'pooled_buffer') {
    const device = this.#getBoundDevice();
    if (!device) {
      throw new Error('Device not initialized');
    }

    // Check device limits before allocation
    const limits = device.limits;
    const maxSize = limits?.maxBufferSize || Infinity;
    const maxStorageSize = limits?.maxStorageBufferBindingSize || Infinity;
    const isStorageBuffer = (usage & RESOLVED_GPU_BUFFER_USAGE.STORAGE) !== 0;

    // Align size and compute bucket, respecting device limits
    const alignedSize = alignTo(size, this.#config.alignmentBytes);
    const maxAllowedBucket = isStorageBuffer ? Math.min(maxSize, maxStorageSize) : maxSize;
    const bucket = getSizeBucket(alignedSize, maxAllowedBucket, this.#schemaConfig.bucket);

    if (bucket > maxSize) {
      throw new Error(
        `Buffer size ${bucket} exceeds device maxBufferSize (${maxSize}). ` +
        `Requested: ${size} bytes, bucketed to: ${bucket} bytes.`
      );
    }

    if (isStorageBuffer && bucket > maxStorageSize) {
      throw new Error(
        `Storage buffer size ${bucket} exceeds device maxStorageBufferBindingSize (${maxStorageSize}). ` +
        `Consider splitting into smaller buffers or using a different strategy.`
      );
    }

    // Reuse adds no allocation: preserve compatible buffers before trimming.
    // Try to get from pool
    if (this.#config.enablePooling) {
      const pooled = this.#getFromPool(bucket, usage);
      if (pooled) {
        this.#activeBuffers.add(pooled);
        this.#stats.reuses++;
        this.#requestedSizes.set(pooled, alignedSize);
        this.#bufferLabels.set(pooled, label);
        this.#stats.currentBytesRequested += alignedSize;
        this.#stats.peakBytesRequested = Math.max(
          this.#stats.peakBytesRequested,
          this.#stats.currentBytesRequested
        );

        // Track metadata in debug mode
        if (this.#debugMode) {
          this.#trackBuffer(pooled, bucket, usage, label);
        }

        this.#traceAcquire(pooled, bucket, alignedSize, usage, label, true);

        return pooled;
      }
    }

    this.#enforceBudgetBeforeAllocate(bucket, label);

    // Allocate new buffer
    const buffer = device.createBuffer({
      label: `${label}_${bucket}`,
      size: bucket,
      usage,
    });
    bufferPools.set(buffer, this);
    registerBufferDevice(buffer, device);

    this.#activeBuffers.add(buffer);
    this.#stats.allocations++;
    this.#stats.totalBytesAllocated += bucket;
    this.#stats.currentBytesAllocated += bucket;
    this.#stats.peakBytesAllocated = Math.max(
      this.#stats.peakBytesAllocated,
      this.#stats.currentBytesAllocated
    );
    this.#stats.totalBytesRequested += alignedSize;
    this.#stats.currentBytesRequested += alignedSize;
    this.#stats.peakBytesRequested = Math.max(
      this.#stats.peakBytesRequested,
      this.#stats.currentBytesRequested
    );
    trackAllocation(bucket, label);
    this.#requestedSizes.set(buffer, alignedSize);
    this.#bufferLabels.set(buffer, label);

    // Track metadata in debug mode
    if (this.#debugMode) {
      this.#trackBuffer(buffer, bucket, usage, label);
    }

    this.#traceAcquire(buffer, bucket, alignedSize, usage, label, false);

    return buffer;
  }

  release(buffer) {
    if (!this.#activeBuffers.has(buffer)) {
      log.warn('BufferPool', 'Releasing buffer not tracked as active');
      return;
    }
    this.#releaseTrackedBuffer(buffer, true);
  }

  discard(buffer) {
    if (!this.#activeBuffers.has(buffer)) {
      log.warn('BufferPool', 'Discarding buffer not tracked as active');
      return;
    }
    this.#releaseTrackedBuffer(buffer, false);
  }

  isActiveBuffer(buffer) {
    return this.#activeBuffers.has(buffer);
  }

  getRequestedSize(buffer) {
    return this.#requestedSizes.get(buffer) ?? buffer.size;
  }
  #destroyPendingBuffers(buffers = Array.from(this.#pendingDestruction)) {
    for (const buffer of buffers) {
      if (!this.#pendingDestruction.has(buffer)) continue;
      try {
        buffer.destroy();
        this.#pendingDestruction.delete(buffer);
      } catch (error) {
        log.warn('BufferPool', `Pending buffer destroy failed: ${error?.message ?? error}`);
      }
    }
  }
  #releaseTrackedBuffer(buffer, allowPooling) {
    this.#activeBuffers.delete(buffer);
    const requestedSize = this.#requestedSizes.get(buffer) ?? 0;
    this.#stats.currentBytesRequested -= requestedSize;
    this.#requestedSizes.delete(buffer);

    if (this.#debugMode) {
      this.#bufferMetadata.delete(buffer);
    }

    if (!allowPooling || !this.#config.enablePooling) {
      this.#deferDestroy(buffer);
      this.#stats.currentBytesAllocated -= buffer.size;
      this.#traceRelease(buffer, requestedSize, false);
      return;
    }

    const bucket = buffer.size;
    const usage = buffer.usage;

    if (!this.#pools.has(usage)) {
      this.#pools.set(usage, new Map());
    }
    const usagePool = this.#pools.get(usage);

    if (!usagePool.has(bucket)) {
      usagePool.set(bucket, []);
    }
    const bucketPool = usagePool.get(bucket);

    let pooled = false;
    if (bucketPool.length < this.#config.maxPoolSizePerBucket &&
        this.#getTotalPooledCount() < this.#config.maxTotalPooledBuffers) {
      bucketPool.push(buffer);
      this.#totalPooledBuffers++;
      pooled = true;
    } else {
      this.#deferDestroy(buffer);
      this.#stats.currentBytesAllocated -= buffer.size;
    }

    this.#traceRelease(buffer, requestedSize, pooled);
  }
  #deferDestroy(buffer) {
    this.#pendingDestruction.add(buffer);
    this.#scheduleDestruction();
  }
  async settleDeferredDestruction() {
    // Freeze this retirement boundary; later work in another session is not ours.
    const pending = Array.from(this.#pendingDestruction);
    if (pending.length === 0) return;
    const device = this.#device;
    if (device && !isDeviceLost(device)) {
      try { await device.queue.onSubmittedWorkDone(); }
      catch (error) { if (!isDeviceLost(device)) throw error; }
    }
    this.#destroyPendingBuffers(pending);
    const retained = pending.filter(buffer => this.#pendingDestruction.has(buffer));
    if (retained.length) throw new Error(`BufferPool could not retire ${retained.length} buffers; ownership retained for retry.`);
  }
  #scheduleDestruction() {
    const device = this.#device;
    if (!device || isDeviceLost(device)) {
      this.#destroyPendingBuffers();
      return;
    }
    if (this.#destructionScheduled) {
      return;
    }
    if (this.#pendingDestruction.size === 0) return;

    // This completion covers only buffers retired before it was requested.
    const pending = Array.from(this.#pendingDestruction);
    this.#destructionScheduled = true;
    let completion;
    try {
      completion = device.queue.onSubmittedWorkDone();
    } catch (error) {
      completion = Promise.reject(error);
    }
    Promise.resolve(completion)
      .then(() => {
        this.#destructionScheduled = false;
        this.#destroyPendingBuffers(pending);
        // A failed destroy stays owned for explicit retry, without a retry loop.
        if (pending.every(buffer => !this.#pendingDestruction.has(buffer))) {
          this.#scheduleDestruction();
        }
      })
      .catch((err) => {
        this.#destructionScheduled = false;
        if (isDeviceLost(device)) {
          this.#destroyPendingBuffers();
        } else {
          log.warn('BufferPool', `Deferred destruction failed; retaining buffers: ${err.message}`);
        }
      });
  }
  #getFromPool(bucket, usage) {
    const usagePool = this.#pools.get(usage);
    if (!usagePool) return null;

    const bucketPool = usagePool.get(bucket);
    if (!bucketPool || bucketPool.length === 0) return null;

    const buffer = bucketPool.pop();
    if (buffer) {
      this.#totalPooledBuffers--;
    }
    return buffer;
  }
  #getTotalPooledCount() {
    return this.#totalPooledBuffers;
  }
  #getBudgetConfig() {
    return this.#schemaConfig?.budget ?? {
      maxTotalBytes: 0,
      highWatermarkRatio: 0.9,
      emergencyTrimTargetRatio: 0.75,
      hardFailOnBudgetExceeded: true,
    };
  }
  #enforceBudgetBeforeAllocate(bucketBytes, label) {
    const budget = this.#getBudgetConfig();
    if (!Number.isFinite(budget.maxTotalBytes) || budget.maxTotalBytes <= 0) {
      return;
    }

    const projected = this.#stats.currentBytesAllocated + bucketBytes;
    const highWatermark = Math.floor(budget.maxTotalBytes * budget.highWatermarkRatio);
    if (projected > highWatermark) {
      const target = Math.floor(budget.maxTotalBytes * budget.emergencyTrimTargetRatio);
      this.#trimPooledBuffersTo(target);
    }

    const nextProjected = this.#stats.currentBytesAllocated + bucketBytes;
    if (nextProjected > budget.maxTotalBytes && budget.hardFailOnBudgetExceeded) {
      throw new Error(
        `BufferPool budget exceeded for ${label}: projected=${nextProjected}, max=${budget.maxTotalBytes}. ` +
        'Enable larger runtime.shared.bufferPool.budget.maxTotalBytes or lower model working set.'
      );
    }
  }
  #trimPooledBuffersTo(targetBytes) {
    while (this.#stats.currentBytesAllocated > targetBytes) {
      const evicted = this.#evictOnePooledBuffer();
      if (!evicted) {
        break;
      }
    }
  }
  #evictOnePooledBuffer() {
    for (const usagePool of this.#pools.values()) {
      for (const bucketPool of usagePool.values()) {
        if (bucketPool.length === 0) {
          continue;
        }
        const buffer = bucketPool.pop();
        if (buffer) {
          this.#totalPooledBuffers--;
          this.#deferDestroy(buffer);
          this.#stats.currentBytesAllocated -= buffer.size;
          return true;
        }
      }
    }
    return false;
  }
  #trackBuffer(buffer, size, usage, label) {

    const metadata = {
      size,
      usage,
      label,
      acquiredAt: Date.now(),
    };

    // Capture stack trace for leak detection
    if (Error.captureStackTrace) {
      const obj = {};
      Error.captureStackTrace(obj);
      metadata.stackTrace =  (obj).stack;
    }

    this.#bufferMetadata.set(buffer, metadata);
  }
  #getBufferId(buffer) {
    let id = this.#bufferIds.get(buffer);
    if (!id) {
      id = this.#nextBufferId++;
      this.#bufferIds.set(buffer, id);
    }
    return id;
  }
  #traceAcquire(buffer, bucket, requestedSize, usage, label, reused) {
    if (!isTraceEnabled('buffers')) {
      return;
    }
    const id = this.#getBufferId(buffer);
    const mode = reused ? 'reuse' : 'new';
    trace.buffers(
      `Acquire ${mode} id=${id} size=${bucket} req=${requestedSize} usage=${usage} label=${label}`
    );
  }
  #traceRelease(buffer, requestedSize, pooled) {
    if (!isTraceEnabled('buffers')) {
      return;
    }
    const id = this.#getBufferId(buffer);
    const label = this.#bufferLabels.get(buffer) ?? 'unknown';
    const action = pooled ? 'pool' : 'destroy';
    trace.buffers(
      `Release id=${id} size=${buffer.size} req=${requestedSize} usage=${buffer.usage} label=${label} action=${action}`
    );
  }

  detectLeaks(thresholdMs = 60000) {
    if (!this.#debugMode) {
      log.warn('BufferPool', 'Leak detection requires debug mode');
      return [];
    }

    const now = Date.now();

    const leaks = [];

    for (const [buffer, metadata] of this.#bufferMetadata.entries()) {
      if (this.#activeBuffers.has(buffer)) {
        const age = now - metadata.acquiredAt;
        if (age > thresholdMs) {
          leaks.push(metadata);
        }
      }
    }

    return leaks;
  }

  createStagingBuffer(size) {
    return this.acquire(size, BufferUsage.STAGING_READ, 'staging_read');
  }

  createUploadBuffer(size) {
    return this.acquire(size, BufferUsage.STAGING_WRITE, 'staging_write');
  }

  createUniformBuffer(size) {
    // Uniform buffers have stricter alignment (256 bytes typically)
    const alignedSize = alignTo(size, 256);
    return this.acquire(alignedSize, BufferUsage.UNIFORM, 'uniform');
  }

  uploadData(buffer, data, offset = 0) {
    const device = this.#getBoundDevice();
    if (!device) {
      throw new Error('Device not initialized');
    }
    device.queue.writeBuffer(buffer, offset,  (data));
  }

  async readBuffer(buffer, size = buffer.size) {
    return this.readBufferSlice(buffer, 0, size);
  }

  async readBufferSlice(buffer, offset = 0, size = buffer.size - offset) {
    if (!allowReadback('BufferPool.readBuffer')) {
      return new ArrayBuffer(0);
    }

    const device = this.#getBoundDevice();
    if (!device) {
      throw new Error('Device not initialized');
    }

    if (!Number.isInteger(offset) || offset < 0) {
      throw new Error(`Invalid read offset: ${offset}`);
    }
    if (!Number.isInteger(size) || size < 0) {
      throw new Error(`Invalid read size: ${size}`);
    }
    if (offset > buffer.size) {
      throw new Error(`Read offset ${offset} exceeds buffer size ${buffer.size}`);
    }
    if (offset + size > buffer.size) {
      throw new Error(
        `Read range [${offset}, ${offset + size}) exceeds buffer size ${buffer.size}`
      );
    }
    if (offset % 4 !== 0) {
      throw new Error(`Read offset must be 4-byte aligned, got ${offset}`);
    }
    if (size === 0) {
      return new ArrayBuffer(0);
    }

    const alignedSize = Math.ceil(size / 4) * 4;
    const staging = this.createStagingBuffer(alignedSize);
    let mapped = false;

    try {
      const encoder = device.createCommandEncoder({ label: 'readback_encoder' });
      encoder.copyBufferToBuffer(buffer, offset, staging, 0, alignedSize);
      device.queue.submit([encoder.finish()]);

      // Map and read
      await staging.mapAsync(RESOLVED_GPU_MAP_MODE.READ);
      mapped = true;
      return staging.getMappedRange(0, alignedSize).slice(0, size);
    } catch (error) {
      if (this.#activeBuffers.has(staging)) {
        this.#releaseTrackedBuffer(staging, false);
      }
      throw error;
    } finally {
      if (mapped && this.#activeBuffers.has(staging)) {
        try {
          staging.unmap();
        } catch (error) {
          this.#releaseTrackedBuffer(staging, false);
          throw error;
        }
        this.#releaseTrackedBuffer(staging, true);
      }
    }
  }

  clearPool() {
    for (const usagePool of this.#pools.values()) {
      for (const bucketPool of usagePool.values()) {
        for (const buffer of bucketPool) {
          this.#deferDestroy(buffer);
          this.#stats.currentBytesAllocated -= buffer.size;
        }
        bucketPool.length = 0;
      }
    }
    this.#pools.clear();
    this.#totalPooledBuffers = 0;
    // Keep existing deferred-destruction contract: anything already queued
    // should still be destroyed after submitted work completes.
  }

  destroy() {
    if (this.#destroyed) {
      this.#scheduleDestruction();
      return;
    }
    this.#destroyed = true;
    // Destroy active buffers
    for (const buffer of this.#activeBuffers) {
      this.#deferDestroy(buffer);
    }
    this.#activeBuffers.clear();
    this.#bufferMetadata.clear();

    // Clear pools
    this.clearPool();

    this.#stats.currentBytesAllocated = 0;
    this.#stats.currentBytesRequested = 0;
    this.#requestedSizes.clear();
    this.#scheduleDestruction();
  }

  getStats() {
    const budget = this.#getBudgetConfig();
    const resources = {
      retainedModel: { bytes: 0, count: 0 },
      active: { bytes: 0, count: 0 },
      reusable: { bytes: 0, count: 0 },
      deferredCleanup: { bytes: 0, count: 0 },
    };
    const account = (group, buffer) => { group.bytes += buffer.size; group.count += 1; };
    for (const buffer of this.#activeBuffers) {
      account(isPersistentBuffer(buffer) ? resources.retainedModel : resources.active, buffer);
    }
    for (const usagePool of this.#pools.values()) {
      for (const bucket of usagePool.values()) {
        for (const buffer of bucket) account(resources.reusable, buffer);
      }
    }
    for (const buffer of this.#pendingDestruction) account(resources.deferredCleanup, buffer);
    return {
      ...this.#stats,
      resources,
      activeBuffers: this.#activeBuffers.size,
      pooledBuffers: this.#getTotalPooledCount(),
      budgetMaxBytes: budget.maxTotalBytes,
      budgetUtilization: budget.maxTotalBytes > 0
        ? this.#stats.currentBytesAllocated / budget.maxTotalBytes
        : 0,
      hitRate: this.#stats.allocations > 0
        ? (this.#stats.reuses / (this.#stats.allocations + this.#stats.reuses) * 100).toFixed(1) + '%'
        : '0%',
    };
  }

  getLabelStats() {
    const totals = new Map();
    for (const buffer of this.#activeBuffers) {
      const label = this.#bufferLabels.get(buffer) || 'unlabeled';
      const bytes = this.#requestedSizes.get(buffer) || 0;
      const entry = totals.get(label) || { label, bytes: 0, count: 0 };
      entry.bytes += bytes;
      entry.count += 1;
      totals.set(label, entry);
    }
    return Array.from(totals.values());
  }

  configure(config) {
    Object.assign(this.#config, config);
  }

  forceReclaim(targetRatio = null) {
    const budget = this.#getBudgetConfig();
    if (!Number.isFinite(budget.maxTotalBytes) || budget.maxTotalBytes <= 0) {
      this.clearPool();
      return;
    }
    const ratio = targetRatio ?? budget.emergencyTrimTargetRatio;
    const target = Math.floor(budget.maxTotalBytes * ratio);
    this.#trimPooledBuffersTo(target);
  }
}

// Global buffer pool instance

const devicePools = new WeakMap();
const persistentBuffers = new WeakSet();

export function getBufferPool(device = currentDevice()) {
  observeDeviceLoss(device);
  if (!device || isDeviceLost(device)) throw new Error('BufferPool requires a live GPU device.');
  let pool = devicePools.get(device);
  if (!pool) {
    pool = new BufferPool(false, getRuntimeConfig().shared.bufferPool, device);
    devicePools.set(device, pool);
  }
  return pool;
}

export function destroyBufferPool(device = currentDevice()) {
  if (!device) return;
  devicePools.get(device)?.destroy();
  devicePools.delete(device);
}

function poolForBuffer(buffer) {
  const pool = bufferPools.get(buffer);
  if (pool) return pool;
  const device = getBufferDevice(buffer);
  if (!device) throw new Error('Buffer has no known GPU resource owner.');
  return getBufferPool(device);
}

// Convenience exports for common operations

export const createStagingBuffer = (size) => getBufferPool().createStagingBuffer(size);

export const createUniformBuffer = (size) => getBufferPool().createUniformBuffer(size);

export const acquireBuffer = (size, usage, label) =>
  getBufferPool().acquire(size, usage, label);

export const releaseBuffer = (buffer) => poolForBuffer(buffer).release(buffer);

export const discardBuffer = (buffer) => poolForBuffer(buffer).discard(buffer);

export const isBufferActive = (buffer) =>
  bufferPools.get(buffer)?.isActiveBuffer(buffer) === true;

export function markPersistentBuffer(buffer) {
  if (buffer && typeof buffer === 'object') {
    persistentBuffers.add(buffer);
  }
}

function unmarkPersistentBuffer(buffer) {
  if (buffer && typeof buffer === 'object') {
    persistentBuffers.delete(buffer);
  }
}

export function isPersistentBuffer(buffer) {
  return !!buffer && typeof buffer === 'object' && persistentBuffers.has(buffer);
}

export class PersistentBufferSet extends Set {
  add(buffer) {
    markPersistentBuffer(buffer);
    return super.add(buffer);
  }

  delete(buffer) {
    unmarkPersistentBuffer(buffer);
    return super.delete(buffer);
  }

  clear() {
    for (const buffer of this) {
      unmarkPersistentBuffer(buffer);
    }
    return super.clear();
  }
}

export const getBufferRequestedSize = (buffer) =>
  bufferPools.get(buffer)?.getRequestedSize(buffer) ?? buffer.size;

export const uploadData = (buffer, data, offset) =>
  poolForBuffer(buffer).uploadData(buffer, data, offset);

export const readBuffer = (buffer, size) =>
  poolForBuffer(buffer).readBuffer(buffer, size);

export const readBufferSlice = (buffer, offset, size) =>
  poolForBuffer(buffer).readBufferSlice(buffer, offset, size);

export const forceBufferPoolReclaim = (targetRatio) =>
  devicePools.get(currentDevice())?.forceReclaim(targetRatio);
