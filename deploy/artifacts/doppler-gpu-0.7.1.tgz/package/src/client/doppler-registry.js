import { getCdnBasePath } from '../storage/download-types.js';
import { buildHfResolveBaseUrl } from '../storage/hf-resolve-url.js';
import { loadJson } from '../formats/load-json.js';
import { assertBundledResolutionNotRevoked } from '../config/revocation-policy.js';

let registryPromise = null;

function cloneOptionalObject(value) {
  return value && typeof value === 'object' && !Array.isArray(value)
    ? JSON.parse(JSON.stringify(value))
    : null;
}

function normalizeEntry(entry) {
  if (!entry || typeof entry !== 'object') {
    return null;
  }
  const modelId = typeof entry.modelId === 'string' ? entry.modelId.trim() : '';
  if (!modelId) {
    return null;
  }
  const sourceCheckpointId = typeof entry.sourceCheckpointId === 'string' ? entry.sourceCheckpointId.trim() : '';
  const weightCapsuleId = typeof entry.weightCapsuleId === 'string' ? entry.weightCapsuleId.trim() : '';
  const manifestVariantId = typeof entry.manifestVariantId === 'string' ? entry.manifestVariantId.trim() : '';
  const artifactCompleteness = typeof entry.artifactCompleteness === 'string' ? entry.artifactCompleteness.trim() : '';
  const runtimePromotionState = typeof entry.runtimePromotionState === 'string' ? entry.runtimePromotionState.trim() : '';
  const vendorBenchmark = cloneOptionalObject(entry.vendorBenchmark);
  const benchmarkEvidence = cloneOptionalObject(entry.benchmarkEvidence);
  const classification = cloneOptionalObject(entry.classification);
  const typeCluster = cloneOptionalObject(entry.typeCluster);
  if (
    !sourceCheckpointId
    || !weightCapsuleId
    || !manifestVariantId
    || artifactCompleteness !== 'complete'
    || runtimePromotionState !== 'manifest-owned'
    || entry.weightsRefAllowed !== false
  ) {
    return null;
  }
  return {
    modelId,
    ...(typeof entry.label === 'string' && entry.label.trim() ? { label: entry.label.trim() } : {}),
    ...(Number.isSafeInteger(entry.sizeBytes) && entry.sizeBytes >= 0 ? { sizeBytes: entry.sizeBytes } : {}),
    ...(cloneOptionalObject(entry.quickstartRequirements) ? { quickstartRequirements: cloneOptionalObject(entry.quickstartRequirements) } : {}),
    sourceCheckpointId,
    weightCapsuleId,
    manifestVariantId,
    artifactCompleteness,
    runtimePromotionState,
    weightsRefAllowed: false,
    aliases: Array.isArray(entry.aliases)
      ? entry.aliases.filter((alias) => typeof alias === 'string' && alias.trim().length > 0)
      : [],
    modes: Array.isArray(entry.modes)
      ? entry.modes.filter((mode) => typeof mode === 'string' && mode.trim().length > 0)
      : [],
    ...(classification ? { classification } : {}),
    ...(typeCluster ? { typeCluster } : {}),
    hf: entry.hf && typeof entry.hf === 'object'
      ? {
        repoId: typeof entry.hf.repoId === 'string' ? entry.hf.repoId.trim() : '',
        revision: typeof entry.hf.revision === 'string' && entry.hf.revision.trim().length > 0
          ? entry.hf.revision.trim()
          : null,
        path: typeof entry.hf.path === 'string' ? entry.hf.path.trim() : '',
      }
      : null,
    ...(vendorBenchmark ? { vendorBenchmark } : {}),
    ...(benchmarkEvidence ? { benchmarkEvidence } : {}),
  };
}

async function loadRegistry() {
  if (!registryPromise) {
    registryPromise = loadJson(
      '../config/quickstart-registry.json',
      import.meta.url,
      'Failed to load Doppler quickstart registry'
    ).then((raw) => {
      const entries = Array.isArray(raw?.models)
        ? raw.models.map(normalizeEntry).filter(Boolean)
        : [];
      return { models: entries };
    });
  }
  return registryPromise;
}

export async function listQuickstartModels() {
  const registry = await loadRegistry();
  return registry.models.map((entry) => ({
    modelId: entry.modelId,
    ...(entry.label ? { label: entry.label } : {}),
    ...(entry.sizeBytes !== undefined ? { sizeBytes: entry.sizeBytes } : {}),
    ...(entry.quickstartRequirements ? { quickstartRequirements: cloneOptionalObject(entry.quickstartRequirements) } : {}),
    sourceCheckpointId: entry.sourceCheckpointId,
    weightCapsuleId: entry.weightCapsuleId,
    manifestVariantId: entry.manifestVariantId,
    artifactCompleteness: entry.artifactCompleteness,
    runtimePromotionState: entry.runtimePromotionState,
    weightsRefAllowed: entry.weightsRefAllowed,
    aliases: [...entry.aliases],
    modes: [...entry.modes],
    ...(entry.classification ? { classification: cloneOptionalObject(entry.classification) } : {}),
    ...(entry.typeCluster ? { typeCluster: cloneOptionalObject(entry.typeCluster) } : {}),
    ...(entry.vendorBenchmark ? { vendorBenchmark: cloneOptionalObject(entry.vendorBenchmark) } : {}),
    ...(entry.benchmarkEvidence ? { benchmarkEvidence: cloneOptionalObject(entry.benchmarkEvidence) } : {}),
  }));
}

export async function resolveQuickstartModel(model) {
  const requested = typeof model === 'string' ? model.trim() : '';
  if (!requested) {
    throw new Error('Quickstart model id is required.');
  }

  const registry = await loadRegistry();
  const resolved = registry.models.find((entry) => (
    entry.modelId === requested || entry.aliases.includes(requested)
  ));
  if (resolved) {
    await assertBundledResolutionNotRevoked({
      logicalModelId: requested,
      modelId: resolved.modelId,
      sourceCheckpointId: resolved.sourceCheckpointId,
      weightCapsuleId: resolved.weightCapsuleId,
      manifestVariantId: resolved.manifestVariantId,
    });
    return resolved;
  }

  const available = registry.models.map((entry) => entry.modelId).join(', ');
  throw new Error(`Unknown quickstart model "${requested}". Available: ${available}`);
}

export function buildQuickstartModelBaseUrl(entry, options = {}) {
  if (!entry?.hf?.repoId || !entry?.hf?.path) {
    throw new Error(`Quickstart model "${entry?.modelId ?? 'unknown'}" does not have a hosted Hugging Face source.`);
  }
  const cdnBasePath = typeof options.cdnBasePath === 'string' && options.cdnBasePath.length > 0
    ? options.cdnBasePath
    : getCdnBasePath();
  return buildHfResolveBaseUrl(entry.hf, { cdnBasePath });
}
