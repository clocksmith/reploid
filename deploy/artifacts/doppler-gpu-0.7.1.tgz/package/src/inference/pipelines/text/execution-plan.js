import { selectRuleValue } from '../../../rules/rule-registry.js';
import { READBACK_MODES } from '../../../config/schema/execution-v1.schema.js';
import {
  resolveDeferredRoundingWindowTokens,
  resolveRangeAwareSelectiveWideningConfig,
} from './finiteness-policy.js';
import { log } from '../../../debug/index.js';
import { validatePairedExecution } from './paired-execution.js';
import { kernelPathDeclaresQKNorm } from '../../../config/kernel-path-loader.js';
import { assertLinearNormGateClosure } from '../../../config/execution-registry-contract.js';
import { resolveLinearNormGateActivation } from '../../../config/schema/manifest.schema.js';
import { resolveMoeExecutionProfile } from './moe-shape-validator.js';

const PRIMARY_EXECUTION_PLAN_ID = 'primary';
const FINITENESS_FALLBACK_EXECUTION_PLAN_ID = 'finiteness_fallback';

export function assertPreparedDecodeWorkspaceCompatible(context) {
  const preparedMoE = context.config.useMoE
    && context.runtimeMoERoutingConfig?.activeExpertSelection === 'topk-route'
    && resolveMoeExecutionProfile(context.config, { modelType: context.config.modelType }).supportsPreparedDecode === true;
  if (!context.decodeBuffers || context.activationDtype !== 'f32' || context.activationPrecision === 'two-f32'
      || (context.config.useMoE && !preparedMoE) || context.lora
      || context.operatorDiagnostics || context.trainingCapture || context.debugProbes?.length) {
    throw new Error('Prepared decode workspace requires dense or supported GPU-route MoE F32 buffers without training, LoRA or diagnostics.');
  }
}

// Session-owned decode scratch is attached to the step recorder on every decode
// path that requests it; an unrecorded path cannot honor the request.
export function attachPreparedDecodeWorkspace(enabled, recorder, context, device) {
  if (typeof enabled !== 'boolean') {
    throw new Error('Decode session requires boolean usePreparedDecodeWorkspace.');
  }
  if (!enabled) return null;
  if (!recorder) {
    throw new Error('Prepared decode workspace requires a recorded decode step; the unrecorded decode path cannot use it.');
  }
  assertPreparedDecodeWorkspaceCompatible(context);
  recorder.decodeWorkspace = context.decodeBuffers.getWorkspace(device);
  return recorder.decodeWorkspace;
}

function assertOptionalBoolean(value, label) {
  if (value === undefined) {
    return undefined;
  }
  if (typeof value !== 'boolean') {
    throw new Error(`[ExecutionPlan] ${label} must be boolean when provided; got ${JSON.stringify(value)}.`);
  }
  return value;
}

function assertOptionalPositiveInt(value, label) {
  if (value === undefined) {
    return undefined;
  }
  if (!Number.isInteger(value) || value < 1) {
    throw new Error(`[ExecutionPlan] ${label} must be a positive integer when provided; got ${JSON.stringify(value)}.`);
  }
  return value;
}

function assertOptionalNullablePositiveInt(value, label) {
  if (value === undefined || value === null) {
    return value;
  }
  return assertOptionalPositiveInt(value, label);
}

function assertRequiredPositiveInt(value, label) {
  if (!Number.isInteger(value) || value < 1) {
    throw new Error(`[ExecutionPlan] ${label} must be a positive integer; got ${JSON.stringify(value)}.`);
  }
  return value;
}

function assertOptionalStopCheckMode(value) {
  if (value === undefined) {
    return undefined;
  }
  if (value !== 'batch' && value !== 'per-token') {
    throw new Error(
      `[ExecutionPlan] stopCheckMode must be "batch" or "per-token" when provided; got ${JSON.stringify(value)}.`
    );
  }
  return value;
}

function assertReadbackMode(value) {
  if (!value || !READBACK_MODES.includes(value)) {
    throw new Error(
      `[ExecutionPlan] readbackMode must be one of ${READBACK_MODES.join(', ')}; got ${JSON.stringify(value)}.`
    );
  }
  return value;
}

function resolveFallbackActivationDtype(primaryActivationDtype) {
  const fallbackActivationDtype = selectRuleValue(
    'inference',
    'execution',
    'finitenessFallbackActivationDtype',
    { activationDtype: primaryActivationDtype }
  );
  if (fallbackActivationDtype !== 'f16' && fallbackActivationDtype !== 'f32') {
    throw new Error(
      `[ExecutionPlan] finiteness fallback activation dtype must be "f16" or "f32"; got "${fallbackActivationDtype}".`
    );
  }
  return fallbackActivationDtype;
}

function kernelUsesF16ActivationExecution(kernel) {
  const kernelName = String(kernel ?? '');
  if (!kernelName) {
    return false;
  }
  return /_f16(?!w|kv)/.test(kernelName);
}

function stepUsesF16ActivationExecution(step) {
  if (!step || typeof step !== 'object') {
    return false;
  }
  const precision = step.precision ?? null;
  if (
    precision?.activationDtype === 'f16'
    || precision?.inputDtype === 'f16'
    || precision?.outputDtype === 'f16'
  ) {
    return true;
  }
  return kernelUsesF16ActivationExecution(step.kernel);
}

function kernelPathUsesF16ActivationExecution(kernelPath) {
  const stepLists = [
    kernelPath?.decode?.steps,
    kernelPath?.prefill?.steps,
    kernelPath?.preLayer,
    kernelPath?.postLayer,
    kernelPath?.sampling,
  ];
  for (const override of kernelPath?.layerOverrides ?? []) {
    stepLists.push(override?.steps, override?.decode?.steps, override?.prefill?.steps);
  }
  return stepLists.some((steps) => Array.isArray(steps) && steps.some((step) => stepUsesF16ActivationExecution(step)));
}

function createStaticExecutionPlan({
  id,
  source,
  kernelPath,
  kernelPathSource,
  activationDtype,
  finitenessPolicy,
  deferredRoundingWindowTokens,
  generationConfig,
  batchingConfig,
}) {
  return {
    id,
    source,
    kernelPath,
    kernelPathId: kernelPath?.id ?? null,
    kernelPathSource,
    activationDtype,
    finitenessGuardEnabled: activationDtype === 'f16' && finitenessPolicy.enabled,
    finitenessOnTrigger: finitenessPolicy.onTrigger,
    finitenessAbsThreshold: finitenessPolicy.absThreshold,
    finitenessIncludeNonFinite: finitenessPolicy.includeNonFinite,
    deferredRoundingWindowTokens,
    defaultDisableCommandBatching: batchingConfig.disableCommandBatching,
    defaultDisableMultiTokenDecode: generationConfig.disableMultiTokenDecode,
    defaultBatchSize: batchingConfig.batchSize,
    defaultStopCheckMode: batchingConfig.stopCheckMode,
    defaultMaxTokens: batchingConfig.maxTokens,
    readbackInterval: batchingConfig.readbackInterval,
    readbackMode: batchingConfig.readbackMode,
    maxBatchDecodeTokens: batchingConfig.maxBatchDecodeTokens,
    ringTokens: batchingConfig.ringTokens,
    ringStop: batchingConfig.ringStop,
    ringStaging: batchingConfig.ringStaging,
  };
}

function getPlanState(container) {
  if (container?.executionPlanState) {
    return container.executionPlanState;
  }
  return container;
}

function getPlanById(planState, planId) {
  if (!planState) {
    throw new Error('[ExecutionPlan] plan state is not initialized.');
  }
  if (planId === PRIMARY_EXECUTION_PLAN_ID) {
    return planState.primaryPlan;
  }
  if (planId === FINITENESS_FALLBACK_EXECUTION_PLAN_ID) {
    return planState.fallbackPlan;
  }
  throw new Error(`[ExecutionPlan] unknown plan id "${planId}".`);
}

function validatePlanAgainstManifest(plan, manifest) {
  if (!manifest || !plan) return;
  const manifestInf = manifest.inference ?? manifest;
  const warnings = [];

  const manifestActivationDtype = manifestInf.session?.compute?.defaults?.activationDtype
    ?? manifestInf.compute?.activationDtype
    ?? manifestInf.quantizationInfo?.compute
    ?? null;
  if (manifestActivationDtype && plan.activationDtype
    && plan.activationDtype !== manifestActivationDtype) {
    warnings.push(
      `activationDtype: plan="${plan.activationDtype}" vs manifest="${manifestActivationDtype}"`
    );
  }

  if (warnings.length > 0) {
    log.warn(
      'ExecutionPlan',
      `Plan "${plan.id}" diverges from manifest: ${warnings.join('; ')}. ` +
      'Verify runtime config and manifest are in sync.'
    );
  }
}

export function compileExecutionPlanState(options) {
  const runtimeConfig = options?.runtimeConfig;
  const resolvedKernelPath = options?.resolvedKernelPath ?? null;
  const kernelPathSource = options?.kernelPathSource ?? 'none';
  const transformFallbackKernelPath = options?.fallbackKernelPath ?? null;
  const manifest = options?.manifest ?? null;

  if (!runtimeConfig?.inference) {
    throw new Error('[ExecutionPlan] runtimeConfig.inference is required.');
  }
  // Every lane: a declared gated-delta kernel must apply the manifest's norm gate.
  if (manifest?.inference?.execution) {
    assertLinearNormGateClosure(manifest.inference.execution, resolveLinearNormGateActivation(
      manifest.inference.normalization, 'manifest.inference.normalization'));
  }

  const inferenceConfig = runtimeConfig.inference;
  const computeConfig = inferenceConfig.compute;
  const generationConfig = inferenceConfig.generation ?? {};
  if (generationConfig.disableCommandBatching !== undefined) {
    throw new Error(
      '[ExecutionPlan] runtime.inference.generation.disableCommandBatching is removed. ' +
      'Use runtime.inference.session.decodeLoop.disableCommandBatching.'
    );
  }
  const sessionConfig = inferenceConfig.session ?? {};
  const representation = sessionConfig.intermediatePrecision === 'two-f32'
    ? validatePairedExecution(resolvedKernelPath, sessionConfig, manifest) : {};
  if (sessionConfig.intermediatePrecision !== 'two-f32' && kernelPathDeclaresQKNorm(resolvedKernelPath)) {
    throw new Error('[ExecutionPlan] q_norm and k_norm steps declare paired (two-F32) head normalization; '
      + 'scalar Q/K normalization would not run their programs.');
  }
  const decodeLoopConfig = sessionConfig.decodeLoop;
  if (!decodeLoopConfig || typeof decodeLoopConfig !== 'object') {
    throw new Error('[ExecutionPlan] runtimeConfig.inference.session.decodeLoop is required.');
  }

  const finitenessPolicy = resolveRangeAwareSelectiveWideningConfig(computeConfig);
  const deferredRoundingWindowTokens = resolveDeferredRoundingWindowTokens(computeConfig);
  const batchingConfig = {
    batchSize: decodeLoopConfig.batchSize,
    stopCheckMode: decodeLoopConfig.stopCheckMode,
    maxTokens: assertRequiredPositiveInt(generationConfig.maxTokens, 'runtime.inference.generation.maxTokens'),
    readbackInterval: decodeLoopConfig.readbackInterval,
    readbackMode: assertReadbackMode(decodeLoopConfig.readbackMode),
    maxBatchDecodeTokens: assertOptionalNullablePositiveInt(
      decodeLoopConfig.maxBatchDecodeTokens,
      'runtimeConfig.inference.session.decodeLoop.maxBatchDecodeTokens'
    ),
    ringTokens: decodeLoopConfig.ringTokens,
    ringStop: decodeLoopConfig.ringStop,
    ringStaging: decodeLoopConfig.ringStaging,
    disableCommandBatching: assertOptionalBoolean(
      decodeLoopConfig.disableCommandBatching,
      'runtimeConfig.inference.session.decodeLoop.disableCommandBatching'
    ),
  };

  const primaryPlan = { ...createStaticExecutionPlan({
    id: PRIMARY_EXECUTION_PLAN_ID,
    source: 'configured',
    kernelPath: resolvedKernelPath,
    kernelPathSource,
    activationDtype: computeConfig.activationDtype,
    finitenessPolicy,
    deferredRoundingWindowTokens,
    generationConfig,
    batchingConfig,
  }), ...representation };
  const primaryUsesF16ActivationExecution = primaryPlan.activationDtype === 'f16'
    || kernelPathUsesF16ActivationExecution(resolvedKernelPath);

  let fallbackPlan = null;
  if (primaryUsesF16ActivationExecution && primaryPlan.finitenessOnTrigger === 'fallback-plan') {
    const fallbackActivationDtype = resolveFallbackActivationDtype(primaryPlan.activationDtype);
    if (fallbackActivationDtype !== 'f32') {
      throw new Error(
        `[ExecutionPlan] finiteness fallback activation dtype must widen to "f32"; got "${fallbackActivationDtype}".`
      );
    }

    // Prefer transform-based fallback kernel path from execution-v1 compilation
    let fallbackKernelPathState;
    if (transformFallbackKernelPath) {
      fallbackKernelPathState = {
        kernelPath: transformFallbackKernelPath,
        kernelPathId: transformFallbackKernelPath.id ?? null,
        kernelPathSource: 'execution-v1-transform',
      };
      log.info(
        'ExecutionPlan',
        `Using transform-based finiteness fallback kernel path: ${transformFallbackKernelPath.id ?? 'inline'}`
      );
    } else {
      // Registry-based fallback was removed in Phase 3.
      // The finiteness fallback kernel path must come from execution-v1 transforms
      // or from an explicit finitenessFallbackKernelPathId on the kernel path object.
      throw new Error(
        `[ExecutionPlan] finiteness fallback kernel path required for "${primaryPlan.kernelPath?.id ?? 'unknown'}" ` +
        'but no transform-based fallback was provided. Use execution-v1 transforms or set ' +
        'finitenessFallbackKernelPathId explicitly on the kernel path object.'
      );
    }

    fallbackPlan = createStaticExecutionPlan({
      id: FINITENESS_FALLBACK_EXECUTION_PLAN_ID,
      source: 'finiteness-fallback',
      kernelPath: fallbackKernelPathState.kernelPath,
      kernelPathSource: fallbackKernelPathState.kernelPathSource,
      activationDtype: fallbackActivationDtype,
      finitenessPolicy,
      deferredRoundingWindowTokens,
      generationConfig,
      batchingConfig,
    });

    if (fallbackPlan.finitenessGuardEnabled) {
      throw new Error('[ExecutionPlan] finiteness fallback plan cannot enable finiteness guard.');
    }
  }

  // Consistency check: validate the primary plan's kernel path source is recognized.
  const knownKernelPathSources = new Set([
    'none', 'config', 'model', 'manifest', 'execution-v1', 'execution-v1-transform',
  ]);
  if (primaryPlan.kernelPathSource && !knownKernelPathSources.has(primaryPlan.kernelPathSource)) {
    log.warn(
      'ExecutionPlan',
      `Primary plan kernelPathSource "${primaryPlan.kernelPathSource}" is not a recognized source. ` +
      `Known sources: ${[...knownKernelPathSources].join(', ')}.`
    );
  }
  // Validate that the plan's activation dtype is a recognized value.
  if (primaryPlan.activationDtype !== 'f16' && primaryPlan.activationDtype !== 'f32') {
    log.warn(
      'ExecutionPlan',
      `Primary plan activationDtype "${primaryPlan.activationDtype}" is not "f16" or "f32". ` +
      'Verify the manifest and runtime config produce a valid dtype.'
    );
  }

  // Validate plan against manifest when available (diagnostic only).
  if (manifest) {
    validatePlanAgainstManifest(primaryPlan, manifest);
  }

  return {
    primaryPlan,
    fallbackPlan,
    activePlanId: PRIMARY_EXECUTION_PLAN_ID,
  };
}

export function hasFallbackExecutionPlan(container) {
  const planState = getPlanState(container);
  return planState?.fallbackPlan != null;
}

export function resolveActiveExecutionPlan(container) {
  const planState = getPlanState(container);
  const activePlan = getPlanById(planState, planState?.activePlanId ?? PRIMARY_EXECUTION_PLAN_ID);
  if (!activePlan) {
    throw new Error('[ExecutionPlan] active plan is missing.');
  }
  return activePlan;
}

export function setActiveExecutionPlan(container, planId) {
  const planState = getPlanState(container);
  const plan = getPlanById(planState, planId);
  if (!plan) {
    throw new Error(`[ExecutionPlan] plan "${planId}" is not available.`);
  }
  planState.activePlanId = planId;
  return plan;
}

export function resetActiveExecutionPlan(container) {
  return setActiveExecutionPlan(container, PRIMARY_EXECUTION_PLAN_ID);
}

export function activateFallbackExecutionPlan(container) {
  const planState = getPlanState(container);
  if (!planState?.fallbackPlan) {
    return null;
  }
  return setActiveExecutionPlan(container, FINITENESS_FALLBACK_EXECUTION_PLAN_ID);
}

function resolveExecutionOverrides(options = {}) {
  return {
    disableCommandBatching: assertOptionalBoolean(
      options.disableCommandBatching,
      'disableCommandBatching'
    ),
    disableMultiTokenDecode: assertOptionalBoolean(
      options.disableMultiTokenDecode,
      'disableMultiTokenDecode'
    ),
    batchSize: assertOptionalPositiveInt(options.batchSize, 'batchSize'),
    stopCheckMode: assertOptionalStopCheckMode(options.stopCheckMode),
    maxTokens: assertOptionalPositiveInt(options.maxTokens, 'maxTokens'),
    readbackInterval: assertOptionalPositiveInt(options.readbackInterval, 'readbackInterval'),
    ringTokens: assertOptionalPositiveInt(options.ringTokens, 'ringTokens'),
    ringStop: assertOptionalPositiveInt(options.ringStop, 'ringStop'),
    ringStaging: assertOptionalPositiveInt(options.ringStaging, 'ringStaging'),
  };
}

export function resolveExecutionSessionPlan(container, options = {}) {
  const activePlan = resolveActiveExecutionPlan(container);
  const overrides = resolveExecutionOverrides(options);

  return {
    planId: activePlan.id,
    source: activePlan.source,
    kernelPath: activePlan.kernelPath,
    kernelPathId: activePlan.kernelPathId,
    activationDtype: activePlan.activationDtype,
    ...(activePlan.activationPrecision === 'two-f32' ? {
      activationPrecision: activePlan.activationPrecision,
      activationComponents: activePlan.activationComponents,
      activationElementStrideBytes: activePlan.activationElementStrideBytes,
    } : {}),
    finitenessGuardEnabled: activePlan.finitenessGuardEnabled,
    finitenessOnTrigger: activePlan.finitenessOnTrigger,
    finitenessAbsThreshold: activePlan.finitenessAbsThreshold,
    finitenessIncludeNonFinite: activePlan.finitenessIncludeNonFinite,
    deferredRoundingWindowTokens: activePlan.deferredRoundingWindowTokens,
    disableCommandBatching: overrides.disableCommandBatching ?? activePlan.defaultDisableCommandBatching,
    disableMultiTokenDecode: overrides.disableMultiTokenDecode ?? activePlan.defaultDisableMultiTokenDecode,
    batchSize: overrides.batchSize ?? activePlan.defaultBatchSize,
    stopCheckMode: overrides.stopCheckMode ?? activePlan.defaultStopCheckMode,
    maxTokens: overrides.maxTokens ?? activePlan.defaultMaxTokens,
    readbackInterval: overrides.readbackInterval ?? activePlan.readbackInterval,
    readbackMode: activePlan.readbackMode,
    maxBatchDecodeTokens: activePlan.maxBatchDecodeTokens,
    ringTokens: overrides.ringTokens ?? activePlan.ringTokens,
    ringStop: overrides.ringStop ?? activePlan.ringStop,
    ringStaging: overrides.ringStaging ?? activePlan.ringStaging,
    overrides,
  };
}

export function rebaseExecutionSessionPlan(container, sessionPlan) {
  const overrides = sessionPlan?.overrides ?? {};
  return resolveExecutionSessionPlan(container, overrides);
}

export function isBatchDecodeEnabled(config) {
  return selectRuleValue('inference', 'execution', 'batchDecodeEnabled', {
    batchSize: config.batchSize,
    useGPU: config.useGPU,
    gpuSamplingAvailable: config.gpuSamplingAvailable,
    disableMultiTokenDecode: config.disableMultiTokenDecode,
    disableCommandBatching: config.disableCommandBatching,
    isBdpaPagedLayout: config.isBdpaPagedLayout === true,
    finitenessFallbackWindowOpen: config.finitenessFallbackWindowOpen === true,
    hasLinearAttentionLayers: config.hasLinearAttentionLayers === true,
    selfSpeculationEnabled: config.selfSpeculationEnabled === true,
    hasRangeBackedPerLayerInputs: config.hasRangeBackedPerLayerInputs === true,
  });
}

export function resolveMaxBatchDecodeTokens(config) {
  if (config.configuredMaxBatchDecodeTokens !== undefined) {
    const value = config.configuredMaxBatchDecodeTokens;
    if (value === null) {
      return null;
    }
    if (!Number.isInteger(value) || value < 1) {
      throw new Error(
        `[ExecutionPlan] configured maxBatchDecodeTokens must be null or a positive integer; got ${JSON.stringify(value)}.`
      );
    }
    return value;
  }
  const value = selectRuleValue('inference', 'execution', 'maxBatchDecodeTokens', {
    hasHotVocabularyBatchDecode: config.hasHotVocabularyBatchDecode === true,
    hasGpuSplitPerLayerInputs: config.hasGpuSplitPerLayerInputs === true,
    hasLinearAttentionLayers: config.hasLinearAttentionLayers === true,
    modelId: typeof config.modelId === 'string' ? config.modelId : '',
    activationDtype: typeof config.activationDtype === 'string' ? config.activationDtype : '',
    currentSeqLen: Number.isFinite(config.currentSeqLen) ? config.currentSeqLen : 0,
    maxDecodeTokens: Number.isFinite(config.maxDecodeTokens) ? config.maxDecodeTokens : 0,
    numLayers: Number.isFinite(config.numLayers) ? config.numLayers : 0,
    hiddenSize: Number.isFinite(config.hiddenSize) ? config.hiddenSize : 0,
  });
  if (value == null) {
    return null;
  }
  if (!Number.isInteger(value) || value < 1) {
    throw new Error(
      `[ExecutionPlan] maxBatchDecodeTokens must be null or a positive integer; got ${JSON.stringify(value)}.`
    );
  }
  return value;
}

export function resolvePrefillRecorderChunkLayers(config) {
  if (config.configuredPrefillChunkLayers !== undefined) {
    const configured = config.configuredPrefillChunkLayers;
    if (configured === null) {
      throw new Error('[ExecutionPlan] configured prefillChunkLayers cannot be null.');
    }
    if (!Number.isInteger(configured) || configured < 1) {
      throw new Error(
        `[ExecutionPlan] configured prefillChunkLayers must be a positive integer; got ${JSON.stringify(configured)}.`
      );
    }
    return configured;
  }
  const value = selectRuleValue('inference', 'execution', 'prefillRecorderChunkLayers', {
    hasGpuSplitPerLayerInputs: config.hasGpuSplitPerLayerInputs === true,
    numTokens: config.numTokens,
  });
  if (!Number.isInteger(value) || value < 1) {
    throw new Error(
      `[ExecutionPlan] prefillRecorderChunkLayers must be a positive integer; got ${JSON.stringify(value)}.`
    );
  }
  return value;
}

export function isDecodeRecorderEnabled(config) {
  return selectRuleValue('inference', 'execution', 'decodeRecorderEnabled', {
    hasDevice: config.hasDevice === true,
    debug: config.debug === true,
    disableCommandBatching: config.disableCommandBatching === true,
    kvLayout: config.kvLayout ?? null,
  });
}

export function isProfileDecodeRecorderEnabled(config) {
  return selectRuleValue('inference', 'execution', 'profileDecodeRecorderEnabled', {
    hasDevice: config.hasDevice === true,
    debug: config.debug === true,
    disableCommandBatching: config.disableCommandBatching === true,
    kvLayout: config.kvLayout ?? null,
  });
}
