import { observeLinearActivity } from './linear-attention/activity.js';
import { recordMatmul, runMatmul } from '../../../gpu/kernels/matmul.js';
import { recordRMSNorm, runRMSNorm } from '../../../gpu/kernels/rmsnorm.js';
import { castF32ToF16, castF16ToF32, recordCastF32ToF16, recordCastF16ToF32 } from '../../../gpu/kernels/cast.js';
import { readBuffer, releaseBuffer } from '../../../memory/buffer-pool.js';
import { log } from '../../../debug/index.js';
import { decodeReadback } from './debug-utils/readback-decoding.js';
import { runLinearAttentionCoreGPU } from '../../../gpu/kernels/linear-attention-core.js';
import {
  resolveLinearAttentionABProjection,
  resolveLinearAttentionQKVZProjection,
} from './linear-attention-ab-fusion.js';
import { runProbes } from './probes.js';
import { selectRuleValue } from '../../../rules/rule-registry.js';
import { assertImplicitDtypeTransitionAllowed } from './dtype-contract.js';
import { getLoRAModule } from './lora.js';
import { applyProjectionLoRA, createLayerRuntimeState, ensureLayerRuntimeGpuBuffers, inferLinearNormModeFromWeight, isGpuBuffer, normalizeLinearNormMode, projectLinearTensor, releaseOrTrackBuffer, releaseResolvedWeightBuffer, resolveMatmulStepDtype, toPositiveInt } from './linear-attention/plan.js';
export { applyLinearNormWeightOffset } from './linear-attention/plan.js';
import { assertRecurrentStateLayout, assertConvolutionStateLayout, resolveRecurrentStateLayout } from './linear-attention/state-layout.js';
import { LINEAR_RUNTIME_SCHEMA_VERSION, clearLayerRuntimeStates, cloneLayerRuntimeState } from './linear-attention/state-clone.js';
import { recordDeclaredLinearNormAB } from './linear-attention/norm-ab.js';
const QK_L2NORM_EPS = 1e-6;
// Prepared parameters belong to the loaded pipeline, never to a conversation.
// Snapshots intentionally do not carry these source-identity associations.
const preparedLayerSources = new WeakMap();
const freshSequenceLayers = new WeakSet();
function preparationSources(layerWeights, config) {
  return [layerWeights.linearConv1D, layerWeights.linearDtBias, layerWeights.linearALog,
    layerWeights.linearNorm, config.linearConvKernelDim, config.linearNormMode,
    config.linearAttentionSourceLayout, config.rmsNormEps, config.rmsNormWeightOffset, config.sessionSettings?.intermediatePrecision,
    resolveRecurrentStateLayout(config.sessionSettings).precision];
}
function cloneLayerMap(layers) {
  const cloned = new Map();
  for (const [layerIdx, layerState] of layers.entries()) {
    cloned.set(layerIdx, cloneLayerRuntimeState(layerState));
  }
  return cloned;
}
function ensureRuntime(runtime) {
  if (runtime && typeof runtime === 'object' && runtime.layers instanceof Map) {
    if (runtime.schemaVersion !== LINEAR_RUNTIME_SCHEMA_VERSION) {
      throw new Error('Linear runtime schema version mismatch; reset before reuse.');
    }
    return runtime;
  }
  return createLinearAttentionRuntime();
}
function resolveProjectionLayout(config, layerWeights) {
  const numKHeads = toPositiveInt(config.linearNumKeyHeads);
  const numVHeads = toPositiveInt(config.linearNumValueHeads);
  const headKDim = toPositiveInt(config.linearKeyHeadDim);
  const headVDim = toPositiveInt(config.linearValueHeadDim);
  if (!numKHeads || !numVHeads || !headKDim || !headVDim) {
    throw new Error(
      'linear_attention requires linear_num_key_heads, linear_num_value_heads, ' +
      'linear_key_head_dim, and linear_value_head_dim.'
    );
  }
  if (numVHeads % numKHeads !== 0) {
    throw new Error(
      `linear_attention requires num_value_heads divisible by num_key_heads; got ` +
      `${numVHeads} and ${numKHeads}.`
    );
  }
  const keyDim = numKHeads * headKDim;
  const valueDim = numVHeads * headVDim;
  const qSize = toPositiveInt(layerWeights?.qkvSizes?.[0]) ?? keyDim;
  const kSize = toPositiveInt(layerWeights?.qkvSizes?.[1]) ?? keyDim;
  const vSize = toPositiveInt(layerWeights?.qkvSizes?.[2]) ?? valueDim;
  if (qSize !== keyDim || kSize !== keyDim || vSize !== valueDim) {
    throw new Error(
      `linear_attention projection mismatch: expected [${keyDim}, ${keyDim}, ${valueDim}] ` +
      `but got [${qSize}, ${kSize}, ${vSize}].`
    );
  }
  return {
    numKHeads,
    numVHeads,
    headKDim,
    headVDim,
    keyDim,
    valueDim,
    qSize,
    kSize,
    vSize,
    qRep: numVHeads / numKHeads,
    sourceLayout: config.linearAttentionSourceLayout,
    convDim: qSize + kSize + vSize,
  };
}
export function inferLinearNormMode(weight, projectionLayout) {
  return inferLinearNormModeFromWeight(weight, projectionLayout);
}
async function observeLinearAttentionState(layerState, options) {
  for (const [name, field] of [
    ['conv_weight', 'convWeight'],
    ['dt_bias', 'dtBias'],
    ['a_log', 'aLog'],
    ['norm_weight', 'normWeight'],
    ['conv_input', 'convState'],
    ['recurrent_input', 'recurrentState'],
  ]) {
    const precision = field === 'recurrentState' ? layerState.recurrentStatePrecision : field === 'convState' ? layerState.convStatePrecision : 'f32';
    const paired = precision === 'two-f32';
    await runProbes(`linear_state_${name}`, layerState[`${field}GPU`], {
      layerIdx: options.layerIdx,
      numTokens: 1,
      hiddenSize: layerState[field].length / (paired ? 2 : 1),
      probes: options.debugProbes,
      recorder: options.recorder,
      operatorDiagnostics: options.operatorDiagnostics,
      dtype: 'f32',
      precision: paired ? 'two-f32' : undefined, components: paired ? 2 : undefined,
      elementStrideBytes: paired ? 8 : undefined,
      storageLayout: paired ? { precision, components: 2, ordering: 'interleaved-high-low' } : null,
    });
  }
}
async function syncLayerRuntimeStateFromGPU(layerState) {
  if (isGpuBuffer(layerState.convStateGPU)) {
    const rawConvState = await readBuffer(
      layerState.convStateGPU,
      layerState.convState.length * Float32Array.BYTES_PER_ELEMENT
    );
    layerState.convState = decodeReadback(rawConvState, 'f32');
  }
  if (isGpuBuffer(layerState.recurrentStateGPU)) {
    const rawRecurrentState = await readBuffer(
      layerState.recurrentStateGPU,
      layerState.recurrentState.length * Float32Array.BYTES_PER_ELEMENT
    );
    layerState.recurrentState = decodeReadback(rawRecurrentState, 'f32');
  }
}
function releaseLayerRuntimeGpuBuffers(layerState) {
  if (!layerState || typeof layerState !== 'object') return;
  if (isGpuBuffer(layerState.convWeightGPU)) {
    releaseBuffer(layerState.convWeightGPU);
    layerState.convWeightGPU = null;
  }
  if (isGpuBuffer(layerState.dtBiasGPU)) {
    releaseBuffer(layerState.dtBiasGPU);
    layerState.dtBiasGPU = null;
  }
  if (isGpuBuffer(layerState.aLogGPU)) {
    releaseBuffer(layerState.aLogGPU);
    layerState.aLogGPU = null;
  }
  if (isGpuBuffer(layerState.normWeightGPU)) {
    releaseBuffer(layerState.normWeightGPU);
    layerState.normWeightGPU = null;
  }
  if (isGpuBuffer(layerState.convStateGPU)) {
    releaseBuffer(layerState.convStateGPU);
    layerState.convStateGPU = null;
  }
  if (isGpuBuffer(layerState.recurrentStateGPU)) {
    releaseBuffer(layerState.recurrentStateGPU);
    layerState.recurrentStateGPU = null;
  }
}
function releaseRuntimeLayerBuffers(runtime) {
  if (!runtime || typeof runtime !== 'object' || !(runtime.layers instanceof Map)) {
    return;
  }
  for (const layerState of runtime.layers.values()) {
    releaseLayerRuntimeGpuBuffers(layerState);
  }
}
function isLayerRuntimeCompatible(layerState, projectionLayout, requestedNormMode = null) {
  return layerState
    && layerState.convDim === projectionLayout.convDim
    && Number.isFinite(layerState.convKernelSize)
    && layerState.convKernelSize > 0
    && layerState.keyDim === projectionLayout.keyDim
    && layerState.valueDim === projectionLayout.valueDim
    && layerState.numKHeads === projectionLayout.numKHeads
    && layerState.numVHeads === projectionLayout.numVHeads
    && layerState.headKDim === projectionLayout.headKDim
    && layerState.headVDim === projectionLayout.headVDim
    && layerState.sourceLayout === projectionLayout.sourceLayout
    && layerState.qRep === projectionLayout.qRep
    && layerState.qSize === projectionLayout.qSize
    && layerState.kSize === projectionLayout.kSize
    && layerState.vSize === projectionLayout.vSize
    && (layerState.normMode === 'shared' || layerState.normMode === 'per_head')
    && (requestedNormMode == null || layerState.normMode === requestedNormMode);
}
async function getLayerRuntimeState(runtime, layerIdx, layerWeights, config, currentSeqLen, projectionLayout) {
  const requestedNormMode = normalizeLinearNormMode(config.linearNormMode);
  let layerState = runtime.layers.get(layerIdx) ?? null;
  if (currentSeqLen === 0 && layerState && freshSequenceLayers.delete(layerState)) {
    const previousSources = preparedLayerSources.get(layerState);
    const sources = preparationSources(layerWeights, config);
    if (!previousSources || sources.some((value, index) => value !== previousSources[index])) {
      releaseLayerRuntimeGpuBuffers(layerState);
      runtime.layers.delete(layerIdx);
      layerState = null;
    }
  }
  if (layerState) {
    assertRecurrentStateLayout(layerState);
    assertConvolutionStateLayout(layerState);
    if (layerState.convStatePrecision !== config.sessionSettings?.intermediatePrecision) throw new Error('Cannot change convolution state precision during an active attempt.');
    if (layerState.recurrentStatePrecision !== resolveRecurrentStateLayout(config.sessionSettings).precision) {
      throw new Error('Cannot change recurrent state precision during an active attempt.');
    }
  }
  if (!isLayerRuntimeCompatible(layerState, projectionLayout, requestedNormMode)) {
    if (layerState) {
      releaseLayerRuntimeGpuBuffers(layerState);
    }
    layerState = await createLayerRuntimeState(
      layerIdx,
      layerWeights,
      config,
      currentSeqLen,
      projectionLayout
    );
    preparedLayerSources.set(layerState, preparationSources(layerWeights, config));
    runtime.layers.set(layerIdx, layerState);
    ensureLayerRuntimeGpuBuffers(layerState);
    return layerState;
  }
  if (layerState.seqLen !== currentSeqLen) {
    if (!layerState.warnedSeqMismatch) {
      layerState.warnedSeqMismatch = true;
      log.warn(
        'Layer',
        `linear_attention state mismatch at layer ${layerIdx}: state seqLen=${layerState.seqLen}, ` +
        `runtime seqLen=${currentSeqLen}. Resetting recurrent state.`
      );
    }
    clearDynamicLayerState(layerState);
    layerState.seqLen = currentSeqLen;
  }
  ensureLayerRuntimeGpuBuffers(layerState);
  return layerState;
}
async function settleLinearAttentionCoreInputDtype(tensor, targetDtype, options) {
  if (tensor.dtype === targetDtype) {
    return tensor;
  }
  const {
    recorder,
    executionPolicies,
    role,
  } = options;
  assertImplicitDtypeTransitionAllowed({
    executionPolicies,
    fromDtype: tensor.dtype,
    toDtype: targetDtype,
    op: role,
    detail: 'Linear attention core requires qkv/z/a/b tensors to share one input dtype.',
  });
  if (targetDtype === 'f16') {
    return recorder ? await recordCastF32ToF16(recorder, tensor) : await castF32ToF16(tensor);
  }
  if (targetDtype === 'f32') {
    return recorder ? await recordCastF16ToF32(recorder, tensor) : await castF16ToF32(tensor);
  }
  throw new Error(`Unsupported linear_attention core input dtype "${String(targetDtype)}".`);
}
export function hasLinearAttentionLayers(layerTypes) {
  if (!Array.isArray(layerTypes)) return false;
  for (let i = 0; i < layerTypes.length; i++) {
    const type = String(layerTypes[i] ?? '').trim().toLowerCase();
    if (
      type === 'linear_attention'
      || type === 'linear'
      || type === 'gated_delta'
      || type === 'gated_delta_net'
    ) {
      return true;
    }
  }
  return false;
}
export function createLinearAttentionRuntime() {
  log.debug(
    'Pipeline',
    'Linear attention runtime created (empty). Linear attention layers will be initialized on first use if model config declares them.'
  );
  return {
    schemaVersion: LINEAR_RUNTIME_SCHEMA_VERSION,
    layers: new Map(),
  };
}
export function resetLinearAttentionRuntime(runtime) {
  if (!runtime || typeof runtime !== 'object') {
    return createLinearAttentionRuntime();
  }
  releaseRuntimeLayerBuffers(runtime);
  runtime.schemaVersion = LINEAR_RUNTIME_SCHEMA_VERSION;
  runtime.layers = new Map();
  return runtime;
}
// Clear conversation state while retaining this pipeline's prepared parameters.
export function resetLinearAttentionSequence(runtime) {
  if (runtime?.schemaVersion !== LINEAR_RUNTIME_SCHEMA_VERSION) return resetLinearAttentionRuntime(runtime);
  const target = ensureRuntime(runtime);
  try {
    for (const layerState of target.layers.values()) {
      assertRecurrentStateLayout(layerState);
      assertConvolutionStateLayout(layerState);
    }
    clearLayerRuntimeStates(target.layers.values());
    for (const layerState of target.layers.values()) {
      layerState.seqLen = 0;
      layerState.warnedSeqMismatch = false;
      freshSequenceLayers.add(layerState);
    }
    return target;
  } catch (error) {
    resetLinearAttentionRuntime(target);
    throw error;
  }
}
export async function cloneLinearAttentionRuntime(runtime) {
  if (!runtime || typeof runtime !== 'object' || !(runtime.layers instanceof Map)) {
    return createLinearAttentionRuntime();
  }
  const clonedLayers = new Map();
  for (const [layerIdx, layerState] of runtime.layers.entries()) {
    await syncLayerRuntimeStateFromGPU(layerState);
    clonedLayers.set(layerIdx, cloneLayerRuntimeState(layerState));
  }
  return {
    schemaVersion: LINEAR_RUNTIME_SCHEMA_VERSION,
    layers: clonedLayers,
  };
}
export function restoreLinearAttentionRuntime(runtime, snapshot) {
  const target = ensureRuntime(runtime);
  if (snapshot) {
    if (snapshot.schemaVersion !== LINEAR_RUNTIME_SCHEMA_VERSION) {
      throw new Error('Linear snapshot schema version mismatch.');
    }
    const states = snapshot.layers instanceof Map ? snapshot.layers.values() : snapshot.layers;
    if (!states || typeof states[Symbol.iterator] !== 'function') {
      throw new Error('Linear snapshot requires a layer collection.');
    }
    for (const state of states) { assertRecurrentStateLayout(state); assertConvolutionStateLayout(state); }
  }
  releaseRuntimeLayerBuffers(target);
  target.schemaVersion = LINEAR_RUNTIME_SCHEMA_VERSION;
  target.layers = new Map();
  if (!snapshot || typeof snapshot !== 'object') {
    return target;
  }
  if (snapshot.layers instanceof Map) {
    target.layers = cloneLayerMap(snapshot.layers);
  } else if (Array.isArray(snapshot.layers)) {
    for (const item of snapshot.layers) {
      if (!item || typeof item !== 'object' || !Number.isFinite(item.layerIdx)) {
        continue;
      }
      target.layers.set(Math.trunc(item.layerIdx), cloneLayerRuntimeState(item));
    }
  }
  return target;
}
export async function runLinearAttentionLayer(inputTensor, layerWeights, options) {
  const {
    layerIdx,
    numTokens,
    hiddenSize,
    config,
    currentSeqLen,
    activationDtype,
    kernelPath,
    linearRuntime,
    getWeightBuffer,
    getNormWeightBuffer,
    recorder,
    executionPolicies = null,
    precomputedInputNorm = null,
    lora = null,
  } = options;

  if (!layerWeights) {
    throw new Error(`linear_attention layer ${layerIdx} has no weights.`);
  }
  if (!layerWeights.qkvProj || !layerWeights.oProj) {
    throw new Error(
      `linear_attention layer ${layerIdx} requires qkvProj and oProj weights.`
    );
  }
  if (!layerWeights.linearInProjZ || !layerWeights.linearInProjA || !layerWeights.linearInProjB) {
    throw new Error(
      `linear_attention layer ${layerIdx} requires in_proj_z, in_proj_a, and in_proj_b weights.`
    );
  }

  if ((inputTensor.precision === 'two-f32') !== (config.sessionSettings?.intermediatePrecision === 'two-f32')) {
    throw new Error('Linear input representation disagrees with its resolved intermediate precision.');
  }
  const runtime = ensureRuntime(linearRuntime);
  const projectionLayout = resolveProjectionLayout(config, layerWeights);
  const layerState = await getLayerRuntimeState(
    runtime,
    layerIdx,
    layerWeights,
    config,
    currentSeqLen,
    projectionLayout
  );

  const projectionDtype = selectRuleValue('shared', 'dtype', 'f16OrF32FromDtype', {
    dtype: config?.inputDtype ?? activationDtype,
  });
  const layerOutputDtype = selectRuleValue('shared', 'dtype', 'f16OrF32FromDtype', {
    dtype: config?.outputDtype ?? activationDtype,
  });
  const phase = numTokens === 1 ? 'decode' : 'prefill';
  let normedTensor = inputTensor;
  let normedCreated = false;
  let qkvTensor = null, zTensor = null, aTensor = null, bTensor = null;
  let coreQkvTensor = null, coreZTensor = null, coreATensor = null, coreBTensor = null, coreTensor = null;
  try {

  // A declared linear_norm_ab step runs the input norm with in_proj_a and in_proj_b.
  const fusedAB = await recordDeclaredLinearNormAB(recorder, {
    kernelPath, phase: options.executionPhase ?? phase, layerIdx, numTokens, inputTensor, precomputedInputNorm, layerWeights, getNormWeightBuffer,
    projectionDtype, rmsNormWeightOffset: config.rmsNormWeightOffset, eps: layerState.rmsNormEps,
    hasABLoRA: !!(getLoRAModule(lora, layerIdx, 'in_proj_a') || getLoRAModule(lora, layerIdx, 'in_proj_b')),
    hiddenSize, rows: projectionLayout.numVHeads,
  });
  if (fusedAB) {
    normedTensor = fusedAB.normed;
    normedCreated = true;
  } else if (precomputedInputNorm) {
    if (
      phase !== 'decode'
      || numTokens !== 1
      || !layerWeights.inputNorm
      || precomputedInputNorm.dtype !== inputTensor.dtype
      || precomputedInputNorm.dtype !== 'f32'
    ) {
      releaseOrTrackBuffer(recorder, precomputedInputNorm.buffer);
      throw new Error(`linear_attention layer ${layerIdx} received an incompatible precomputed input norm tensor.`);
    }
    normedTensor = precomputedInputNorm;
    normedCreated = true;
  } else if (layerWeights.inputNorm) {
    const normWeightBuffer = getNormWeightBuffer(layerWeights.inputNorm, `L${layerIdx}.linear_input_norm`);
    try {
      if (recorder) {
        normedTensor = await recordRMSNorm(recorder, inputTensor, normWeightBuffer, layerState.rmsNormEps, {
          batchSize: numTokens,
          hiddenSize,
          rmsNormWeightOffset: config.rmsNormWeightOffset,
          kernelPath, phase, layerIdx, role: 'input_norm', section: 'layer',
        });
      } else {
        normedTensor = await runRMSNorm(inputTensor, normWeightBuffer, layerState.rmsNormEps, {
          batchSize: numTokens,
          hiddenSize,
          rmsNormWeightOffset: config.rmsNormWeightOffset,
          kernelPath, phase, layerIdx, role: 'input_norm', section: 'layer',
        });
      }
      normedCreated = true;
    } finally {
      if (!isGpuBuffer(layerWeights.inputNorm)) {
        releaseOrTrackBuffer(recorder, normWeightBuffer);
      }
    }
  }

  const qkvLoRA = getLoRAModule(lora, layerIdx, 'in_proj_qkv');
  const zLoRA = getLoRAModule(lora, layerIdx, 'in_proj_z');
  const aLoRA = getLoRAModule(lora, layerIdx, 'in_proj_a');
  const bLoRA = getLoRAModule(lora, layerIdx, 'in_proj_b');
  const outLoRA = getLoRAModule(lora, layerIdx, 'out_proj');
  const qkvzProjection = qkvLoRA || zLoRA ? null : resolveLinearAttentionQKVZProjection(layerWeights, {
    phase,
    numTokens,
    hiddenSize,
    numVHeads: projectionLayout.numVHeads,
    convDim: projectionLayout.convDim,
    valueDim: projectionLayout.valueDim,
    layerIdx,
    runtimeSession: options.runtimeSession,
  });
  const qkvzTensor = qkvzProjection
    ? await projectLinearTensor({
      inputTensor: normedTensor,
      sourceWeight: qkvzProjection.weight,
      role: 'linear_qkvz_proj',
      phase,
      outDim: qkvzProjection.outDim,
      numTokens,
      hiddenSize,
      layerIdx,
      kernelPath,
      outputDtype: projectionDtype,
      getWeightBuffer,
      recorder,
      executionPolicies,
    })
    : null;
  qkvTensor = qkvzTensor ?? await projectLinearTensor({
    inputTensor: normedTensor,
    sourceWeight: layerWeights.qkvProj,
    role: 'linear_qkv_proj',
    phase,
    outDim: projectionLayout.convDim,
    numTokens,
    hiddenSize,
    layerIdx,
    kernelPath,
    outputDtype: projectionDtype,
    getWeightBuffer,
    recorder,
    executionPolicies,
    loraModule: qkvLoRA,
  });
  zTensor = qkvzTensor ?? await projectLinearTensor({
    inputTensor: normedTensor,
    sourceWeight: layerWeights.linearInProjZ,
    role: 'linear_z_proj',
    phase,
    outDim: projectionLayout.valueDim,
    numTokens,
    hiddenSize,
    layerIdx,
    kernelPath,
    outputDtype: projectionDtype,
    getWeightBuffer,
    recorder,
    executionPolicies,
    loraModule: zLoRA,
  });
  const abProjection = fusedAB || aLoRA || bLoRA ? null : resolveLinearAttentionABProjection(layerWeights, {
    phase,
    numTokens,
    hiddenSize,
    numVHeads: projectionLayout.numVHeads,
    layerIdx,
    runtimeSession: options.runtimeSession,
  });
  const abTensor = abProjection
    ? await projectLinearTensor({
      inputTensor: normedTensor,
      sourceWeight: abProjection.weight,
      role: 'linear_ab_proj',
      phase,
      outDim: abProjection.outDim,
      numTokens,
      hiddenSize,
      layerIdx,
      kernelPath,
      outputDtype: projectionDtype,
      getWeightBuffer,
      recorder,
      executionPolicies,
    })
    : null;
  aTensor = fusedAB?.a ?? abTensor ?? await projectLinearTensor({
    inputTensor: normedTensor,
    sourceWeight: layerWeights.linearInProjA,
    role: 'linear_a_proj',
    phase,
    outDim: projectionLayout.numVHeads,
    numTokens,
    hiddenSize,
    layerIdx,
    kernelPath,
    outputDtype: projectionDtype,
    getWeightBuffer,
    recorder,
    executionPolicies,
    loraModule: aLoRA,
  });
  bTensor = fusedAB?.b ?? abTensor ?? await projectLinearTensor({
    inputTensor: normedTensor,
    sourceWeight: layerWeights.linearInProjB,
    role: 'linear_b_proj',
    phase,
    outDim: projectionLayout.numVHeads,
    numTokens,
    hiddenSize,
    layerIdx,
    kernelPath,
    outputDtype: projectionDtype,
    getWeightBuffer,
    recorder,
    executionPolicies,
    loraModule: bLoRA,
  });

  const outProjInputDtype = resolveMatmulStepDtype(
    'linear_out_proj',
    phase,
    layerIdx,
    kernelPath,
    projectionDtype,
    'inputDtype'
  );
  const outProjOutputDtype = resolveMatmulStepDtype(
    'linear_out_proj',
    phase,
    layerIdx,
    kernelPath,
    layerOutputDtype,
    'outputDtype'
  );
  coreQkvTensor = qkvTensor;
  coreZTensor = zTensor;
  coreATensor = aTensor;
  coreBTensor = bTensor;

    if (options.debugProbes?.some((probe) => probe.stage.startsWith('linear_state_'))) {
      await observeLinearAttentionState(layerState, options);
    }
    for (const [stage, tensor, width] of [
      ['post_input_norm', normedTensor, hiddenSize],
      ['linear_qkv_proj', qkvTensor, projectionLayout.convDim],
      ['linear_z_proj', zTensor, projectionLayout.valueDim],
      ['linear_a_proj', aTensor, projectionLayout.numVHeads],
      ['linear_b_proj', bTensor, projectionLayout.numVHeads],
    ]) {
      await runProbes(stage, tensor.buffer, {
        layerIdx, numTokens, hiddenSize: width,
        probes: options.debugProbes, recorder,
        operatorDiagnostics: options.operatorDiagnostics, dtype: tensor.dtype,
        precision: tensor.precision, components: tensor.components, elementStrideBytes: tensor.elementStrideBytes,
      });
    }
    const coreInputDtype = qkvTensor.dtype;
    coreZTensor = await settleLinearAttentionCoreInputDtype(zTensor, coreInputDtype, {
      recorder,
      executionPolicies,
      role: 'linear_z_proj',
    });
    coreATensor = await settleLinearAttentionCoreInputDtype(aTensor, coreInputDtype, {
      recorder,
      executionPolicies,
      role: 'linear_a_proj',
    });
    coreBTensor = await settleLinearAttentionCoreInputDtype(bTensor, coreInputDtype, {
      recorder,
      executionPolicies,
      role: 'linear_b_proj',
    });
    coreTensor = await runLinearAttentionCoreGPU(
      coreQkvTensor,
      coreZTensor,
      coreATensor,
      coreBTensor,
      layerState,
      {
        numTokens,
        runtimeSession: options.runtimeSession,
        outputDtype: outProjInputDtype,
        layerIdx,
        normGateActivation: config.linearNormGateActivation,
        mechanismReplacements: config.pairedMechanismReplacements,
        qkL2NormEps: QK_L2NORM_EPS,
        recorder,
        executionPolicies,
        abPacked: abProjection != null,
        qkvzPacked: qkvzProjection != null,
        bProjOffsetElements: abProjection?.bProjOffsetElements ?? 0,
      }
    );
    await observeLinearActivity(options.operatorDiagnostics?.activity, layerIdx, layerState, projectionLayout,
      coreATensor, coreBTensor, numTokens, abProjection?.bProjOffsetElements ?? 0, recorder);
    await runProbes('linear_core_out', coreTensor.buffer, {
      layerIdx,
      numTokens,
      hiddenSize: projectionLayout.valueDim,
      probes: options.debugProbes,
      recorder,
      operatorDiagnostics: options.operatorDiagnostics,
      dtype: coreTensor.dtype,
      precision: coreTensor.precision, components: coreTensor.components, elementStrideBytes: coreTensor.elementStrideBytes,
    });
    layerState.seqLen = currentSeqLen + numTokens;
    const outProjWeight = getWeightBuffer(layerWeights.oProj, `L${layerIdx}.linear_out_proj`);
    try {
      let result;
      if (recorder) {
        result = await recordMatmul(recorder, coreTensor, outProjWeight, numTokens, hiddenSize, projectionLayout.valueDim, {
          transposeB: 'auto',
          role: 'linear_out_proj',
          layerIdx,
          kernelPath,
          outputDtype: outProjOutputDtype,
          executionPolicies,
        });
      } else {
        result = await runMatmul(coreTensor, outProjWeight, numTokens, hiddenSize, projectionLayout.valueDim, {
          transposeB: 'auto',
          role: 'linear_out_proj',
          layerIdx,
          kernelPath,
          outputDtype: outProjOutputDtype,
          executionPolicies,
        });
      }
      if (result.dtype !== outProjOutputDtype) {
        assertImplicitDtypeTransitionAllowed({
          executionPolicies,
          fromDtype: result.dtype,
          toDtype: outProjOutputDtype,
          op: 'linear_out_proj',
          detail: 'Linear attention output would change dtype implicitly before leaving the layer.',
        });
        const casted = outProjOutputDtype === 'f16'
          ? (recorder ? await recordCastF32ToF16(recorder, result) : await castF32ToF16(result))
          : (recorder ? await recordCastF16ToF32(recorder, result) : await castF16ToF32(result));
        releaseOrTrackBuffer(recorder, result.buffer);
        result = casted;
      }
      return await applyProjectionLoRA({
        inputTensor: coreTensor,
        baseOutput: result,
        loraModule: outLoRA,
        dims: { M: numTokens, N: hiddenSize, K: projectionLayout.valueDim },
        getWeightBuffer,
        recorder,
        kernelPath,
      });
    } finally {
      releaseResolvedWeightBuffer(layerWeights.oProj, outProjWeight, recorder);
    }
  } finally {
    if (normedCreated) {
      releaseOrTrackBuffer(recorder, normedTensor.buffer);
    }
    const released = new Set();
    for (const tensor of [qkvTensor, zTensor, aTensor, bTensor, coreQkvTensor, coreZTensor, coreATensor, coreBTensor, coreTensor]) {
      const buffer = tensor?.buffer ?? null;
      if (!buffer || released.has(buffer)) continue;
      released.add(buffer);
      releaseOrTrackBuffer(recorder, buffer);
    }
  }
}
