import {
  isCpuWeightBuffer,
  isGpuBufferInstance,
  isSplitWeightBuffer,
  isWeightBuffer,
} from '../../../../gpu/weight-buffer.js';
import { resolveActiveExecutionPlan } from '../execution-plan.js';

export function getLogitsWeights(state) {
  const finalNorm = state.weights.get('final_norm');
  const hyperConnectionMixer = state.weights.get('hyper_connection_mixer') ?? null;
  const lmHead = state.weights.get('lm_head');
  const lmHeadBias = state.weights.get('lm_head_bias') ?? null;
  const finalNormBias = state.weights.get('final_norm_bias') ?? null;
  if (
    !state.modelConfig?.hyperConnections && (!finalNorm
    || !(isGpuBufferInstance(finalNorm) || finalNorm instanceof Float32Array || isWeightBuffer(finalNorm)))
  ) {
    throw new Error('Final norm not found or invalid type');
  }
  if (
    !lmHead
    || !(
      isGpuBufferInstance(lmHead)
      || lmHead instanceof Float32Array
      || isWeightBuffer(lmHead)
      || isCpuWeightBuffer(lmHead)
      || isSplitWeightBuffer(lmHead)
    )
  ) {
    throw new Error('LM head not found or invalid type');
  }
  if (lmHeadBias !== null && !(lmHeadBias instanceof Float32Array)) {
    throw new Error('LM head bias is not a Float32Array');
  }
  if (finalNormBias !== null && !(finalNormBias instanceof Float32Array)) {
    throw new Error('Final norm bias is not a Float32Array');
  }
  if (state.modelConfig?.hyperConnections && (!hyperConnectionMixer || finalNorm)) throw new Error('[HyperConnection] Root mixer must replace the final norm.');
  return { finalNorm, hyperConnectionMixer, finalNormBias, lmHead, lmHeadBias };
}

export function getLogitsConfig(state, executionPhase) {
  const config = state.modelConfig;
  const activeExecutionPlan = resolveActiveExecutionPlan(state);
  const activeKernelPath = activeExecutionPlan.kernelPath ?? state.resolvedKernelPath ?? null;
  return {
    hyperConnections: config.hyperConnections,
    executionPhase,
    hiddenSize: config.hiddenSize,
    vocabSize: config.vocabSize,
    normalizationType: config.normalizationType,
    finalNormBiasTensor: config.finalNormBiasTensor,
    rmsNormEps: config.rmsNormEps,
    rmsNormWeightOffset: config.rmsNormWeightOffset,
    useTiedEmbeddings: state.useTiedEmbeddings,
    embeddingVocabSize: state.embeddingVocabSize,
    finalLogitSoftcapping: config.finalLogitSoftcapping,
    logitInputScale: config.logitInputScale,
    logitOutputScale: config.logitOutputScale,
    largeWeights: state.runtimeConfig.inference.largeWeights,
    activationDtype: activeExecutionPlan.activationDtype,
    activationPrecision: activeExecutionPlan.activationPrecision,
    activationComponents: activeExecutionPlan.activationComponents,
    activationElementStrideBytes: activeExecutionPlan.activationElementStrideBytes,
    kernelPath: activeKernelPath,
    executionPolicies: state.executionV1State?.policies ?? null,
    debugProbes: state.runtimeConfig.shared.debug.probes,
  };
}
