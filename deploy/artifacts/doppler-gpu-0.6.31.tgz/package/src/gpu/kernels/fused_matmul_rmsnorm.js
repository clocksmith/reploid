import { getDevice } from '../device.js';
import { acquireBuffer, getBufferRequestedSize, releaseBuffer } from '../../memory/buffer-pool.js';
import { createTensor } from '../tensor.js';
import { getBuffer } from '../weight-buffer.js';
import { dispatch, recordDispatch } from './dispatch.js';
import { getPipelineFast } from './pipeline-cache.js';
import { createUniformBufferWithView } from './uniform-utils.js';
import { WORKGROUP_SIZES } from './constants.js';
import { getKernelThresholds } from '../../config/schema/index.js';
import { trace } from '../../debug/index.js';
import { selectRuleValue } from './rule-registry.js';
import { selectRuleValue as selectLoaderRule } from '../../rules/rule-registry.js';


function resolveNormWeightDtype(byteSize, hiddenSize) {
  if (!byteSize || hiddenSize == null) return null;
  const f16Bytes = hiddenSize * 2;
  const f32Bytes = hiddenSize * 4;
  const sizeMatchesF32 = byteSize >= f32Bytes;
  const sizeMatchesF16 = byteSize >= f16Bytes && !sizeMatchesF32;
  if (!sizeMatchesF16 && !sizeMatchesF32) {
    return null;
  }
  return selectLoaderRule('loader', 'weights', 'normWeightDtypeFromSize', {
    sizeMatchesF16,
    sizeMatchesF32,
  });
}


export function selectMatmulRMSNormFusedVariant(N, dtype) {
  if (!dtype) {
    throw new Error('[MatmulRMSNormFused] dtype is required for variant selection.');
  }
  const isF16 = dtype === 'f16';
  const isSmall = N <= WORKGROUP_SIZES.DEFAULT;
  return selectRuleValue('fusedMatmulRmsnorm', 'variant', { isSmall, isF16 });
}


function assertFusedOptions(options) {
  if (options?.transposeB === undefined) {
    throw new Error('[MatmulRMSNormFused] transposeB is required.');
  }
  if (options?.rmsNormWeightOffset === undefined) {
    throw new Error('[MatmulRMSNormFused] rmsNormWeightOffset is required.');
  }
}


async function executeMatmulRMSNormFused(
  recorder,
  input,
  weight,
  normWeight,
  options
) {
  const device = recorder ? recorder.device : getDevice();
  assertFusedOptions(options);
  const {
    N,
    K,
    eps,
    residual = null,
    outputBuffer = null,
    transposeB,
    rmsNormWeightOffset,
    label = null,
  } = options;
  if (eps == null) {
    throw new Error('[MatmulRMSNormFused] eps is required.');
  }

  const { maxMediumN } = getKernelThresholds().fusedMatmul;
  if (N > maxMediumN) {
    throw new Error(`[MatmulRMSNormFused] N=${N} exceeds maxMediumN=${maxMediumN}; kernel only supports single-workgroup RMSNorm.`);
  }

  const weightBuffer = getBuffer(weight);
  const normWeightBuffer = getBuffer(normWeight);
  const normWeightSize = getBufferRequestedSize(normWeightBuffer);
  const normWeightDtype = resolveNormWeightDtype(normWeightSize, N);
  if (!normWeightDtype) {
    throw new Error(
      `[MatmulRMSNormFused] norm weight size (${normWeightSize} bytes) does not match ` +
      `hiddenSize=${N} (expected ${N * 2} or ${N * 4} bytes).`
    );
  }

  // Select variant based on output size and input dtype
  if (!input.dtype) {
    throw new Error('[MatmulRMSNormFused] input dtype is required.');
  }
  const dtype = input.dtype;
  const variant = selectMatmulRMSNormFusedVariant(N, dtype);

  trace.kernels(`${recorder ? 'recordMatmulRMSNormFused' : 'MatmulRMSNormFused'}: N=${N}, K=${K}, variant=${variant}, dtype=${dtype}, hasResidual=${!!residual}, transposeB=${transposeB}, offset=${rmsNormWeightOffset}`);

  const constants = { RMS_NORM_OFFSET: rmsNormWeightOffset, WEIGHT_IS_F16: normWeightDtype === 'f16' };
  const pipeline = await getPipelineFast('fused_matmul_rmsnorm', variant, null, constants);

  // Output buffer: [1, N] - size depends on dtype
  const bytesPerElement = dtype === 'f16' ? 2 : 4;
  const outputSize = N * bytesPerElement;
  let ownedOutput = null;
  let output = outputBuffer;
  let uniformBuffer = null;
  let residualBuffer = residual;
  const ownsResidualBuffer = !residual;
  let completed = false;
  try {
    ownedOutput = outputBuffer ? null : acquireBuffer(outputSize, undefined, 'matmul_rmsnorm_fused_output');
    output = outputBuffer || ownedOutput;

    // Create uniform buffer (8 u32/f32 = 32 bytes, padded for alignment)
    uniformBuffer = createUniformBufferWithView(
      'matmul_rmsnorm_fused_uniforms',
      32,
      (view) => {
        view.setUint32(0, N, true);
        view.setUint32(4, K, true);
        view.setFloat32(8, eps, true);
        view.setUint32(12, residual ? 1 : 0, true);
        view.setUint32(16, transposeB ? 1 : 0, true);
        // Padding bytes 20-31 are zero-initialized
      },
      recorder,
      device
    );

    // Create placeholder for residual if not provided
    residualBuffer = residual || device.createBuffer({
      label: 'matmul_rmsnorm_residual_placeholder',
      size: 4,
      usage: GPUBufferUsage.STORAGE,
    });

    const bindGroup = device.createBindGroup({
      label: 'matmul_rmsnorm_fused_bind_group',
      layout: pipeline.getBindGroupLayout(0),
      entries: [
        { binding: 0, resource: { buffer: uniformBuffer } },
        { binding: 1, resource: { buffer: input.buffer } },
        { binding: 2, resource: { buffer: weightBuffer } },
        { binding: 3, resource: { buffer: normWeightBuffer } },
        { binding: 4, resource: { buffer: output } },
        { binding: 5, resource: { buffer: residualBuffer } },
      ],
    });

    const workgroups = 1;
    const dispatchLabel = label ? `matmul_rmsnorm_fused:${label}` : 'matmul_rmsnorm_fused';
    if (recorder) {
      recordDispatch(recorder, pipeline, bindGroup, workgroups, dispatchLabel);
      if (ownsResidualBuffer) recorder.trackTemporaryBuffer(residualBuffer);
    } else {
      dispatch(device, pipeline, bindGroup, workgroups, dispatchLabel);
    }

    // Output dtype matches input dtype
    const tensor = createTensor(output, input.dtype, [1, N], 'matmul_rmsnorm_fused_output');
    completed = true;
    return tensor;
  } finally {
    if (!recorder) uniformBuffer?.destroy();
    if ((!recorder || !completed) && ownsResidualBuffer && residualBuffer) {
      residualBuffer.destroy();
    }
    if (!completed && ownedOutput) {
      releaseBuffer(ownedOutput);
    }
  }
}

export async function runMatmulRMSNormFused(
  input,
  weight,
  normWeight,
  options
) {
  return executeMatmulRMSNormFused(null, input, weight, normWeight, options);
}


export async function recordMatmulRMSNormFused(
  recorder,
  input,
  weight,
  normWeight,
  options
) {
  return executeMatmulRMSNormFused(recorder, input, weight, normWeight, options);
}


export function shouldUseFusedMatmulRMSNorm(M, N, K) {
  // Only beneficial for decode (M=1)
  if (M !== 1) {
    return false;
  }

  const { maxMediumN, maxMediumK } = getKernelThresholds().fusedMatmul;
  if (N > maxMediumN) {
    return false;
  }

  if (typeof K === 'number' && K > maxMediumK) {
    return false;
  }

  return true;
}
