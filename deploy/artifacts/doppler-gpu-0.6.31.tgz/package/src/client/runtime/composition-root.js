import { resolveExecutionRegistries, assertExecutionRegistriesAccepted } from '../../config/execution-registry-contract.js';
import { hashTargetPlan, assertQualifiedTargetOperation, assertQualifiedResidentPartition, normalizeTargetPlanSelectionPolicy } from '../../config/target-plan.js';
import { GENERATION_CONTRACT } from '../../config/generation-contract.js';
import { ORDERED_LAYER_PARTITION_SCHEMA } from '../../config/layer-partition-plan.js';
import { canonicalGenerationIdentity } from '../../config/canonical-generation-policy.js';
import { getRequiredWgslFeatures, assertWgslFeaturesSupported } from '../../config/wgsl-language-contract.js';
import { assertInitialExecutionIdentity } from '../../config/initial-execution-identity.js';
import { freezeCapsuleV2, verifyCapsuleV2Artifacts } from '../../config/capsule-v2.js';
import { verifyCapsuleMetadata } from '../../config/capsule.js';
import { computeCanonicalSha256 } from '../../formats/canonical-hash.js';
import { hashCapsuleSequenceInput, hashCapsuleSequenceOutput } from '../../config/capsule-sequence-receipt.js';
import { createVerifiedCapsuleArtifactStore } from './verified-capsule-artifact-store.js';
import { createResourceBinder, createDeviceAvailabilityCheck } from './resource-binder.js';
import { createCommandExecutor } from './command-executor.js';
import { createSessionController } from './session-controller.js';
import { selectQualifiedTargetPlan as selectTargetPlan } from '../../config/target-plan.js';
import { executeCapsuleRerank } from './capsule-rerank.js';
import { snapshotChoiceScoringRequest, validateChoiceScoringResult } from '../../config/choice-scoring.js';
import { createCapsuleOperationAdapters } from './capsule-operation-adapters.js';
import { createCapsuleAdapterExecution } from './capsule-adapter-execution.js';
import { createCapsuleOperationExecutor } from './capsule-operation-executor.js';
import { createCapsuleSessionExecution } from './capsule-session-execution.js';
import { executeCapsuleForecast } from './capsule-forecast.js';
import { executeCapsuleEmbedding } from './capsule-embedding.js';
import { CapsuleReleaseStateError } from '../../config/capsule-release-events.js';
import { createCapsuleReleaseAuthorization } from './capsule-release-authorization.js';
import { createCapsuleLoadScope, assertCapsuleLoadActive } from './capsule-acquisition.js';

export { createForecastProgramFactory } from './capsule-forecast-program.js';

export const RUN_CORE_VERSION = '2.0.0';

function emit(observer, event) {
  observer?.observe?.(Object.freeze({ ...event }));
}

function withRequestSignal(request, signal) {
  // Leave malformed requests intact for the operation owner's validation.
  if (!request || typeof request !== 'object' || Array.isArray(request)) return request;
  const options = request.options;
  if (options !== undefined && (!options || typeof options !== 'object' || Array.isArray(options))) return request;
  if (options?.signal === null) return request;
  return { ...request, options: { ...options, signal } };
}

async function loadModuleSources(capsule, artifactStore) {
  if (typeof artifactStore?.readArtifact !== 'function') return new Map();
  const artifactById = new Map(capsule.artifacts.map((artifact) => [artifact.artifactId, artifact]));
  const modules = new Map();
  for (const module of capsule.wgslModules) {
    const artifact = artifactById.get(module.sourceArtifactId);
    const bytes = await artifactStore.readArtifact(artifact);
    modules.set(module.id, { ...module, source: new TextDecoder().decode(bytes) });
  }
  return modules;
}

export function createDopplerRun(ports) {
  if (!ports || typeof ports !== 'object') throw new Error('createDopplerRun requires injected ports.');
  if (!ports.device) throw new Error('createDopplerRun requires a device port.');
  if (!ports.artifactStore) throw new Error('createDopplerRun requires an artifactStore port.');
  if (!ports.trustedSigners) throw new Error('createDopplerRun requires trustedSigners.');
  if (typeof ports.programFactory !== 'function') throw new Error('createDopplerRun requires programFactory.');
  const registries = resolveExecutionRegistries(ports.registries);
  const { device, capsuleSource = null, artifactStore, cache = null, observer = null, trustedSigners, programFactory,
    resolveResidentPartitionAllocation } = ports;

  return {
    version: RUN_CORE_VERSION,
    ports: { device, capsuleSource, artifactStore, cache, observer },

    async openCapsule(capsuleOrId, options = {}) {
      const residentPartition = options.residentPartition === undefined ? undefined : structuredClone(options.residentPartition);
      const selectionPolicy = normalizeTargetPlanSelectionPolicy({
        acceptedTargetPlanDigests: options.acceptedTargetPlanDigests,
        requiredOperations: options.requiredOperations,
        preferredTargetPlanDigests: options.preferredTargetPlanDigests,
      });
      const acquisition = createCapsuleLoadScope(options);
      options = { ...acquisition.options, residentPartition };
      let verifiedStore;
      let program;
      try {
        const input = typeof capsuleOrId === 'string'
          ? await capsuleSource?.fetchCapsule?.(capsuleOrId, options)
          : capsuleOrId;
        assertCapsuleLoadActive(options.signal);
        const capsule = freezeCapsuleV2(structuredClone(input));
        emit(observer, { type: 'capsule-validation-started', capsuleId: capsule.capsuleId });
        let verification;
        try {
          verification = await verifyCapsuleMetadata(capsule, { ...options, trustedSigners });
          if (verification.lifecycle) {
            if (typeof options.persistReleaseCheckpoint !== 'function') throw new Error('Capsule v3 requires persistReleaseCheckpoint before execution.');
            await options.persistReleaseCheckpoint(verification.lifecycle.checkpoint);
          }
        } catch (error) {
          if (error instanceof CapsuleReleaseStateError && typeof options.persistReleaseCheckpoint === 'function') {
            try { await options.persistReleaseCheckpoint(error.checkpoint); } catch (persistenceError) {
              throw new AggregateError([error, persistenceError], 'Release rejected; its verified checkpoint could not be persisted.', { cause: error });
            }
          }
          throw error;
        }
        assertCapsuleLoadActive(options.signal);
        const releaseAuthorization = createCapsuleReleaseAuthorization(verification.lifecycle);
        const deviceProfile = typeof device.getProfile === 'function'
          ? await device.getProfile()
          : {
              hasF16: Boolean(device.hasF16),
              hasSubgroups: Boolean(device.hasSubgroups),
              wgslLanguageFeatures: device.wgslLanguageFeatures,
              maxBufferSize: Number(device.maxBufferSize || 0),
            };
        assertCapsuleLoadActive(options.signal);
        const selectedPlan = selectTargetPlan(capsule.targetPlans, deviceProfile, selectionPolicy);
        assertExecutionRegistriesAccepted(selectedPlan, registries);
        const assertDeviceAvailable = createDeviceAvailabilityCheck(device);
        assertDeviceAvailable();
        const targetPlanDigest = hashTargetPlan(selectedPlan);
        emit(observer, { type: 'target-selected', capsuleId: capsule.capsuleId, targetId: selectedPlan.targetId, targetPlanDigest });
        verifiedStore = createVerifiedCapsuleArtifactStore(capsule, artifactStore, options, ports.artifactBacking);
        const manifestArtifact = capsule.artifacts.find((artifact) => artifact.artifactId === capsule.program.manifestArtifactId);
        const readManifest = async () => {
          const value = freezeCapsuleV2(JSON.parse(new TextDecoder('utf-8', { fatal: true }).decode(await verifiedStore.readArtifact(manifestArtifact))));
          if (value.modelId !== capsule.modelId) throw new Error('Signed manifest model identity mismatch.');
          return value;
        };
        let manifest, residentAllocation = null;
        if (options.residentPartition !== undefined) {
          manifest = await readManifest();
          if (typeof resolveResidentPartitionAllocation !== 'function') {
            throw new Error('Resident partition opening requires an allocation validator port.');
          }
          residentAllocation = resolveResidentPartitionAllocation(manifest, manifestArtifact.hash, options.residentPartition);
          releaseAuthorization.assertAssignment(residentAllocation);
          assertQualifiedResidentPartition(selectedPlan, deviceProfile.surface, residentAllocation);
          if (selectedPlan.tokenSelection !== undefined) throw new Error('Resident partitions require the declared CPU sampling contract.');
          options = { ...options, residentPartition: residentAllocation };
        }
        const selectivePieces = Boolean(residentAllocation && capsule.program.pieceIndexArtifactId !== undefined);
        if (selectivePieces) await verifiedStore.enableResidentPieces();
        const verifiedClosure = selectivePieces
          ? { ...capsule, artifacts: capsule.artifacts.filter(artifact => artifact.role !== 'weight-shard') }
          : capsule;
        const artifactReceipts = await verifyCapsuleV2Artifacts(verifiedClosure, verifiedStore);
        assertDeviceAvailable();
        verification = freezeCapsuleV2({ ...verification, artifactReceipts,
          ...(selectivePieces ? { artifactVerificationScope: 'resident-pieces' } : {}) });
        if (!selectivePieces) await cache?.set?.(capsule.semanticRoot, {
          schema: 'doppler.capsule-verification-cache/v1', semanticRoot: capsule.semanticRoot, artifactReceipts,
        });
        assertCapsuleLoadActive(options.signal);
        emit(observer, { type: 'capsule-validation-complete', capsuleId: capsule.capsuleId, semanticRoot: capsule.semanticRoot,
          artifactMetrics: verifiedStore.getMetrics(),
          artifactVerificationScope: selectivePieces ? 'resident-pieces' : 'whole-closure' });
        const modules = await loadModuleSources(capsule, verifiedStore);
        for (const ref of selectedPlan.kernelClosure) {
          const module = modules.get(ref.moduleId);
          const required = getRequiredWgslFeatures(module.source);
          assertWgslFeaturesSupported(required, selectedPlan.capabilityPredicate.requiredWgslFeatures,
            `WGSL module "${module.id}" outside TargetPlan "${selectedPlan.targetId}" language declarations`);
          assertWgslFeaturesSupported(required, deviceProfile.wgslLanguageFeatures, `WGSL module "${module.id}"`);
        }
        if (manifest === undefined) manifest = await readManifest();
        let observedInitialExecutionIdentity = null;
        program = await programFactory({ capsule, targetPlan: selectedPlan, artifactStore: verifiedStore, deviceProfile, options, registries, observer });
        assertCapsuleLoadActive(options.signal);
        assertDeviceAvailable();
        if (selectedPlan.schema === 'doppler.target-plan/v2') {
          if (typeof program?.getInitialExecutionIdentity !== 'function') {
            throw new Error('TargetPlan v2 requires the loaded program to report initial execution identity.');
          }
          observedInitialExecutionIdentity = await program.getInitialExecutionIdentity();
          assertInitialExecutionIdentity(
            selectedPlan.initialExecutionIdentity,
            observedInitialExecutionIdentity
          );
          emit(observer, {
            type: 'initial-execution-identity-bound',
            capsuleId: capsule.capsuleId,
            targetId: selectedPlan.targetId,
            identityDigest: observedInitialExecutionIdentity.digest,
          });
        }
        const resourceBinder = createResourceBinder(device, program);
        const commandExecutor = createCommandExecutor(device, resourceBinder, program);
        const sessionController = createSessionController(commandExecutor, resourceBinder, program);
        const execution = createCapsuleSessionExecution();
        let closed = false;

        async function assertExecutionCurrent() {
          resourceBinder.assertDeviceAvailable();
          // Capsule and selectedPlan belong to the deeply frozen clone verified
          // at load. Rehashing that immutable closure per token cannot reveal a
          // change. The live program and device still require observation.
          if (selectedPlan.schema === 'doppler.target-plan/v2') {
            assertInitialExecutionIdentity(selectedPlan.initialExecutionIdentity, await program.getInitialExecutionIdentity());
          }
        }

        if (selectivePieces) verification = freezeCapsuleV2({ ...verification,
          pieceVerification: { ...verifiedStore.getPieceVerification(), observation: 'resident-opening' } });
        const session = {
          get generationContract() { return GENERATION_CONTRACT; },
          modelId: capsule.modelId,
          capsuleId: capsule.capsuleId,
          semanticRoot: capsule.semanticRoot,
          schema: 'doppler.capsule-session/v1',
          capsuleIdentity: verification.identity,
          manifest,
          manifestHash: manifestArtifact.hash,
          get loaded() { return !closed; },
          get closed() { return closed; },
          selectedTargetId: selectedPlan.targetId,
          selectedTargetPlanDigest: targetPlanDigest,
          selectedPlan,
          deviceProfile,
          verification,
          observedInitialExecutionIdentity,
          units: { resourceBinder, commandExecutor, sessionController },

          async forecast(request) {
            if (closed) throw new Error('Capsule runtime session is closed.');
            releaseAuthorization.assertAssignment(request?.assignmentHash);
            await assertExecutionCurrent();
            assertQualifiedTargetOperation(selectedPlan, deviceProfile.surface, 'forecast');
            try {
              return releaseAuthorization.bindResult(await executeCapsuleForecast({ identity: verification.identity,
                release: verification.lifecycle?.release ?? capsule.release,
                targetPlan: selectedPlan, targetPlanDigest, program, request,
                artifactReceipts: verification.artifactReceipts,
                releaseEventDigest: verification.lifecycle?.event.digest ?? null }));
            } finally { await assertExecutionCurrent(); }
          },

          async embed(request) {
            if (closed) throw new Error('Capsule runtime session is closed.');
            await assertExecutionCurrent();
            assertQualifiedTargetOperation(selectedPlan, deviceProfile.surface, 'embed');
            try {
              return releaseAuthorization.bindResult(await executeCapsuleEmbedding({ identity: verification.identity,
                release: verification.lifecycle?.release ?? capsule.release,
                manifest, manifestHash: manifestArtifact.hash,
                targetPlan: selectedPlan, targetPlanDigest, program, request,
                artifactReceipts: verification.artifactReceipts,
                releaseEventDigest: verification.lifecycle?.event.digest ?? null }));
            } finally { await assertExecutionCurrent(); }
          },

          async encodeSequence(sequence, sequenceOptions = {}) {
            if (closed) throw new Error('Capsule runtime session is closed.');
            releaseAuthorization.assertAssignment(sequenceOptions.assignment);
            assertQualifiedTargetOperation(selectedPlan, deviceProfile.surface, 'encodeSequence');
            if (typeof program.encodeSequence !== 'function') throw new Error('Selected Capsule program does not implement sequence execution.');
            if (sequenceOptions.signal?.aborted) throw sequenceOptions.signal.reason ?? new Error('Sequence execution cancelled.');
            await assertExecutionCurrent();
            const { signal, ...requestOptions } = sequenceOptions;
            const executionOptions = { ...freezeCapsuleV2(structuredClone(requestOptions)), signal };
            const inputHash = hashCapsuleSequenceInput(sequence, executionOptions);
            const assignmentHash = executionOptions.assignment ? computeCanonicalSha256(executionOptions.assignment) : null;
            try {
              const result = await program.encodeSequence(sequence, executionOptions);
              if (sequenceOptions.signal?.aborted) throw sequenceOptions.signal.reason ?? new Error('Sequence execution cancelled.');
              const payload = {
                schema: 'doppler.capsule-execution-receipt/v1',
                operation: 'encodeSequence',
                capsule: verification.identity,
                targetId: selectedPlan.targetId,
                targetPlanDigest,
                artifactReceipts: verification.artifactReceipts,
                releaseEventDigest: verification.lifecycle?.event.digest ?? null,
                assignmentHash,
                inputHash,
                outputHash: hashCapsuleSequenceOutput(result),
              };
              return { ...result, receipt: releaseAuthorization.bindReceipt(freezeCapsuleV2({ ...payload, receiptDigest: computeCanonicalSha256(payload) })) };
            } finally { await assertExecutionCurrent(); }
          },

          resetGenerationState() {
            if (closed) throw new Error('Capsule runtime session is closed.');
            resourceBinder.assertDeviceAvailable();
            return program.reset?.();
          },

          async *generate(generationOptions = {}, control) {
            if (closed) throw new Error('Capsule runtime session is closed.');
            await assertExecutionCurrent();
            assertQualifiedTargetOperation(selectedPlan, deviceProfile.surface, 'generate');
            try {
              return yield* sessionController.generateTokens(selectedPlan, { ...generationOptions, modules }, control);
            } finally {
              await assertExecutionCurrent();
            }
          },

          async generateText(generationOptions = {}) {
            const tokens = [];
            const iterator = this.generate(generationOptions);
            try {
              while (true) {
                const step = await iterator.next();
                if (step.done) return { text: program.decodeTokens(tokens), tokenIds: tokens, modelId: capsule.modelId, ...step.value };
                tokens.push(step.value);
              }
            } finally { await iterator.return?.(); }
          },

          async scoreChoices(request, control = {}) {
            const snapshot = snapshotChoiceScoringRequest(request);
            if (closed) throw new Error('Capsule runtime session is closed.');
            await assertExecutionCurrent();
            assertQualifiedTargetOperation(selectedPlan, deviceProfile.surface, 'scoreChoices');
            if (typeof program.scoreChoices !== 'function') throw new Error('Capsule program has no choice-scoring implementation.');
            try { return validateChoiceScoringResult(snapshot, await program.scoreChoices(snapshot, control)); }
            finally { await assertExecutionCurrent(); }
          },

          async rerank(request) {
            if (closed) throw new Error('Capsule runtime session is closed.');
            await assertExecutionCurrent();
            assertQualifiedTargetOperation(selectedPlan, deviceProfile.surface, 'rerank');
            try {
              const receipt = releaseAuthorization.bindReceipt(await executeCapsuleRerank({
                capsule: verification.lifecycle ? { ...capsule, release: verification.lifecycle.release } : capsule,
                targetPlan: selectedPlan,
                targetPlanDigest,
                program,
                request,
              }));
              emit(observer, {
                type: 'capsule-rerank-complete',
                capsuleId: capsule.capsuleId,
                targetId: selectedPlan.targetId,
                receiptDigest: receipt.receiptDigest,
              });
              return receipt;
            } finally {
              await assertExecutionCurrent();
            }
          },

          close() {
            closed = true;
            return execution.close(async () => {
              const failures = [];
              try { await sessionController.close(); } catch (error) { failures.push(error); }
              try { commandExecutor.clearPipelineCache(); } catch (error) { failures.push(error); }
              try { await verifiedStore.close(); } catch (error) { failures.push(error); }
              emit(observer, { type: 'capsule-session-closed', capsuleId: capsule.capsuleId, targetPlanDigest,
                artifactMetrics: verifiedStore.getMetrics() });
              if (failures.length === 1) throw failures[0];
              if (failures.length) throw new AggregateError(failures, 'Capsule session cleanup failed');
            });
          },
        };
        if (residentAllocation) {
          const resident = program.residentPartition;
          const ordered = residentAllocation.plan.schema === ORDERED_LAYER_PARTITION_SCHEMA;
          const requiredMethods = ['getDescriptor', 'getRecoveryCapabilities', 'tokenize', 'closeAttempt', 'close',
            ...(ordered ? ['executeStage'] : ['executeGroup0', 'executeGroup1'])];
          if (!resident || requiredMethods.some(method => typeof resident[method] !== 'function')) {
            throw new Error('Loaded resident is missing required partition methods.');
          }
          const canonical = residentAllocation.canonicalGeneration === undefined ? null
            : canonicalGenerationIdentity(residentAllocation.canonicalGeneration.policy,
              residentAllocation.canonicalGeneration.executionIdentity, residentAllocation.plan.vocabSize);
          const canonicalMethods = ['getCanonicalGeneration', 'admitCanonicalPrompt', 'executeCanonicalGroup0',
            'executeCanonicalGroup1', 'commitCanonicalTransition'];
          if (canonical && canonicalMethods.some(method => typeof resident[method] !== 'function')) {
            throw new Error('Loaded canonical resident is missing required methods.');
          }
          if (canonical && computeCanonicalSha256(resident.getCanonicalGeneration()) !== computeCanonicalSha256(canonical)) {
            throw new Error('Loaded canonical generation differs from its verified allocation.');
          }
          const recovery = resident.getRecoveryCapabilities();
          if (recovery?.schema !== 'doppler.resident-recovery/v1'
            || ['inputReplay', 'checkpointExport', 'checkpointImport'].some(key => recovery[key] !== false)) {
            throw new Error('Loaded resident recovery capabilities are unsupported.');
          }
          const recoveryCapabilities = Object.freeze({ schema: recovery.schema, inputReplay: false,
            checkpointExport: false, checkpointImport: false });
          const descriptor = resident.getDescriptor();
          if (descriptor?.schema !== (ordered ? 'doppler.resident-partition/v2' : 'doppler.resident-partition/v1')
            || (ordered && descriptor.stageCount !== residentAllocation.plan.stageCount) || descriptor.ready !== true
            || descriptor.modelId !== capsule.modelId || descriptor.modelIdentity !== manifestArtifact.hash
            || descriptor.planId !== residentAllocation.planId || descriptor.index !== residentAllocation.index
            || JSON.stringify(descriptor.layerRange) !== JSON.stringify(residentAllocation.plan.partitions[residentAllocation.index].layerRange)
            || descriptor.generationDigest !== computeCanonicalSha256(residentAllocation.generation)
            || (descriptor.canonicalGenerationId ?? null) !== (canonical?.generationId ?? null)) {
            throw new Error('Loaded resident descriptor differs from its verified Capsule allocation.');
          }
          const invokeResident = async (method, request) => {
            if (closed) throw new Error('Capsule runtime session is closed.');
            if (canonicalMethods.includes(method) && !canonical) throw new Error('Canonical resident execution was not allocated.');
            if (ordered && ['executeGroup0', 'executeGroup1'].includes(method)) throw new Error('Legacy groups cannot execute an ordered allocation.');
            if (!ordered && method === 'executeStage') throw new Error('Ordered stage execution requires a v3 layer plan.');
            releaseAuthorization.assertAssignment(residentAllocation);
            const { signal, ...data } = request;
            const snapshot = { ...structuredClone(data), signal };
            await assertExecutionCurrent();
            try { return await resident[method](snapshot); }
            finally { await assertExecutionCurrent(); }
          };
          session.residentPartition = Object.freeze({
            getDescriptor: () => ({ ...resident.getDescriptor(), ready: !closed && resident.getDescriptor().ready }),
            getRecoveryCapabilities: () => recoveryCapabilities,
            getCanonicalGeneration: () => canonical,
            tokenize: request => invokeResident('tokenize', request),
            executeStage: request => invokeResident('executeStage', request),
            executeGroup0: request => invokeResident('executeGroup0', request),
            executeGroup1: request => invokeResident('executeGroup1', request),
            admitCanonicalPrompt: request => invokeResident('admitCanonicalPrompt', request),
            executeCanonicalGroup0: request => invokeResident('executeCanonicalGroup0', request),
            executeCanonicalGroup1: request => invokeResident('executeCanonicalGroup1', request),
            commitCanonicalTransition: request => invokeResident('commitCanonicalTransition', request),
            closeAttempt: request => resident.closeAttempt(structuredClone(request)),
            close: () => session.close(),
          });
        }
        // Internal adapters run under the caller's single execution lease.
        const local = { ...session };
        function requireBaseProgram() {
          if (residentAllocation) throw new Error('A resident partition cannot execute an unsplit Capsule operation.');
          if (program.getActiveAdapterIdentity?.()) throw new Error('Capsule adapter remains active; close and reopen the session.');
        }
        const runLocal = (task, signal) => execution.run(currentSignal => {
          requireBaseProgram();
          return task(currentSignal);
        }, signal);
        const adapters = createCapsuleOperationAdapters({ program,
          generate: (request, control) => local.generate(request, control), rerank: (request) => local.rerank(request),
          scoreChoices: (request, control) => local.scoreChoices(request, control),
          embed: (request) => local.embed(request),
          encodeSequence: (sequence, options) => local.encodeSequence(sequence, options) });
        assertCapsuleLoadActive(options.signal);
        emit(observer, { type: 'capsule-load-complete', capsuleId: capsule.capsuleId, artifactMetrics: verifiedStore.getMetrics() });
        const executeOperation = createCapsuleOperationExecutor({ adapters,
            prepareExecution: createCapsuleAdapterExecution({ program, capsule: { ...verification.identity, modelId: capsule.modelId }, targetPlan: selectedPlan }),
            identity: { capsule: verification.identity, modelId: capsule.modelId, targetId: selectedPlan.targetId, targetPlanDigest,
              artifactReceipts: verification.artifactReceipts, releaseEventDigest: verification.lifecycle?.event.digest ?? null,
              ...releaseAuthorization.receiptFields },
            async assertCurrent(request) {
              if (residentAllocation) throw new Error('A resident partition cannot execute an unsplit Capsule operation.');
              if (closed) throw new Error('Capsule runtime session is closed.');
              releaseAuthorization.assertAssignment(request.assignment);
              await assertExecutionCurrent();
            },
          });
        return Object.assign(session, {
          generate: (options = {}) => execution.stream(async function* (signal) {
            requireBaseProgram();
            return yield* local.generate({ ...options, signal });
          }, options.signal),
          generateText: async (options = {}) => runLocal(signal => local.generateText({ ...options, signal }), options.signal),
          scoreChoices: (request, control = {}) => {
            const snapshot = snapshotChoiceScoringRequest(request);
            return runLocal(signal => local.scoreChoices(snapshot, { signal }), control.signal);
          },
          forecast: async request => runLocal(signal => local.forecast({ ...request, signal }), request?.signal),
          embed: async request => runLocal(signal => local.embed(withRequestSignal(request, signal)), request?.options?.signal),
          rerank: async request => runLocal(signal => local.rerank(withRequestSignal(request, signal)), request?.options?.signal),
          encodeSequence: async (sequence, options = {}) => runLocal(signal => local.encodeSequence(sequence, { ...options, signal }), options.signal),
          resetGenerationState: () => runLocal(() => local.resetGenerationState()),
          executeOperation: (request, control = {}) => execution.stream(signal => executeOperation(request, { ...control, signal }), control.signal),
        });
      } catch (error) {
        acquisition.abort(error);
        const failures = [error];
        try { await program?.close?.(); } catch (cleanupError) { failures.push(cleanupError); }
        try { await verifiedStore?.close(); } catch (cleanupError) { failures.push(cleanupError); }
        if (failures.length > 1) throw new AggregateError(failures, 'Capsule loading and cleanup failed.', { cause: error });
        throw error;
      } finally { acquisition.close(); }
    },
  };
}

// Compatibility names share the same implementation.
export { createDopplerRun as createDopplerRuntime, RUN_CORE_VERSION as RUNTIME_CORE_VERSION };
