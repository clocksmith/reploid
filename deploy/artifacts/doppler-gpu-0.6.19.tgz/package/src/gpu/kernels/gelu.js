
import { createTensor, dtypeBytes } from '../tensor.js';
import { WORKGROUP_SIZES } from './constants.js';
import { unifiedKernelWrapper, withKernelOutput } from './kernel-execution.js';
import { selectRuleValue } from './rule-registry.js';
import { getKernelPathActivationSpec } from '../../config/kernel-path-loader.js';

function selectGeluVariant(isF16) {
  return selectRuleValue('gelu', 'variant', { isF16 });
}

function resolveOverrides(context) {
  const overrides = selectRuleValue('gelu', 'overrides', context);
  return overrides && Object.keys(overrides).length > 0 ? overrides : null;
}

async function _gelu(target, input, options = {}) {
  const { size, gate = null, outputBuffer = null } = options;

  const isF16 = input.dtype === 'f16';
  const bytesPerElement = dtypeBytes(input.dtype);
  const variant = selectGeluVariant(isF16);
  const declared = getKernelPathActivationSpec('gelu', options.phase, options.layerIdx, options.kernelPath);
  if (declared && declared.variant !== variant) {
    throw new Error(`GeLU input ${input.dtype} does not match declared kernel ${declared.variant}.`);
  }
  for (const [key, actual] of Object.entries({ HAS_GATE: Boolean(gate), USE_ROWSPLIT: false })) {
    if (declared?.constants?.[key] != null && Number(declared.constants[key]) !== Number(actual)) {
      throw new Error(`GeLU ${key} disagrees with the declared execution step.`);
    }
  }
  const overrides = { ...resolveOverrides({ hasGate: Boolean(gate), useRowsplit: false }), ...declared?.constants };

  const inferredSize = size || (input.buffer.size / bytesPerElement);
  const outputSize = inferredSize * bytesPerElement;
  const gateBuffer = gate ?? input;

  options.signal?.throwIfAborted();
  return withKernelOutput(target, outputBuffer, outputSize, 'gelu_output', async (output) => {
    await unifiedKernelWrapper(
      'gelu', target, variant,
      [input, output, gateBuffer],
      { size: inferredSize, rowsplit_dim: 0 },
      Math.ceil(inferredSize / WORKGROUP_SIZES.DEFAULT),
      overrides, null, null, options.signal
    );

    return createTensor(output, input.dtype, [inferredSize], 'gelu_output');
  });
}

export async function runGeLU(input, options = {}) {
  return _gelu(null, input, options);
}

export async function recordGeLU(recorder, input, options = {}) {
  return _gelu(recorder, input, options);
}
