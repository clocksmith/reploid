import { testHarness as defaultHarness } from './test-page.js';
import { createTensor } from '../../../src/gpu/tensor.js';
import {
  acquireBuffer,
  readBufferSlice,
  releaseBuffer,
  uploadData,
} from '../../../src/memory/buffer-pool.js';
import {
  applyPrefixEmbeddingOverride,
  normalizePrefixEmbeddingOverride,
} from '../../../src/inference/pipelines/text/generator/prefix-embedding.js';
import { runGather } from '../../../src/gpu/kernels/gather.js';
import { runRMSNorm, recordRMSNorm } from '../../../src/gpu/kernels/rmsnorm.js';
import { runMatmul, recordMatmul } from '../../../src/gpu/kernels/matmul.js';
import { createWeightBuffer } from '../../../src/gpu/weight-buffer.js';
import { getDevice } from '../../../src/gpu/device.js';
import { CommandRecorder } from '../../../src/gpu/command-recorder.js';
import { getRuntimeConfig, setRuntimeConfig } from '../../../src/config/runtime.js';
import { runLinearAttentionCoreGPU } from '../../../src/gpu/kernels/linear-attention-core.js';
import { getShaderModule } from '../../../src/gpu/kernels/shader-cache.js';
import rmsNormAccuracy from '../../fixtures/rmsnorm-inverse-root.json' with { type: 'json' };
import q4Accuracy from '../../fixtures/q4k-ordered-accumulation.json' with { type: 'json' };
import linearAccuracy from '../../fixtures/linear-core-refined-accuracy.json' with { type: 'json' };
import linearActivation from '../../fixtures/linear-core-activation-accuracy.json' with { type: 'json' };
import {
  layerNormRef,
  groupNormRef,
  conv2dRef,
  conv2dBackwardRef,
  biasAddRef,
  biasAddBackwardRef,
  pixelShuffleRef,
  upsample2dRef,
  upsample2dBackwardRef,
  modulateRef,
  crossEntropyLossRef,
  crossEntropyBackwardRef,
  embedBackwardRef,
  adamRef,
  softmaxBackwardRef,
  siluBackwardRef,
  geluBackwardRef,
  scaleBackwardRef,
  ropeBackwardRef,
  rmsNormBackwardRef,
} from '../reference/index.js';

function generateUint32(size, max, seed = 123) {
  const out = new Uint32Array(size);
  let state = seed >>> 0;
  for (let i = 0; i < size; i++) {
    state = (state * 1664525 + 1013904223) >>> 0;
    out[i] = max === 0 ? 0 : state % max;
  }
  return out;
}

function generateNormalizedWeights(numTokens, topK, seed = 321) {
  const weights = new Float32Array(numTokens * topK);
  let state = seed >>> 0;
  for (let t = 0; t < numTokens; t++) {
    let sum = 0;
    for (let k = 0; k < topK; k++) {
      state = (state * 1103515245 + 12345) >>> 0;
      const val = (state & 0xffff) / 0xffff;
      weights[t * topK + k] = val;
      sum += val;
    }
    if (sum > 0) {
      for (let k = 0; k < topK; k++) {
        weights[t * topK + k] /= sum;
      }
    }
  }
  return weights;
}

function compareExact(expected, actual) {
  if (expected.length !== actual.length) return false;
  for (let i = 0; i < expected.length; i++) {
    if (expected[i] !== actual[i]) return false;
  }
  return true;
}

async function decodeLinearReference(operand) {
  const bytes = Uint8Array.from(atob(operand.data), value => value.charCodeAt(0));
  const digest = Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256', bytes)),
    value => value.toString(16).padStart(2, '0')).join('');
  if (digest !== operand.sha256) throw new Error('Linear reference operand identity changed');
  return operand.dtype === 'f64' ? new Float64Array(bytes.buffer) : new Float32Array(bytes.buffer);
}

function f16ToF32(bits) {
  const sign = (bits & 0x8000) >> 15;
  const exp = (bits & 0x7c00) >> 10;
  const mant = bits & 0x03ff;
  if (exp === 0) {
    if (mant === 0) return sign ? -0 : 0;
    return (sign ? -1 : 1) * Math.pow(2, -14) * (mant / 1024);
  }
  if (exp === 31) {
    return mant === 0 ? (sign ? -Infinity : Infinity) : NaN;
  }
  return (sign ? -1 : 1) * Math.pow(2, exp - 15) * (1 + mant / 1024);
}

function f32ToF16Bits(value) {
  const view = new DataView(new ArrayBuffer(4));
  view.setFloat32(0, value, true);
  const bits = view.getUint32(0, true);
  const sign = (bits >> 31) & 1;
  const exp = (bits >> 23) & 0xff;
  const mant = bits & 0x7fffff;

  let hExp = 0;
  let hMant = 0;
  if (exp === 0xff) {
    hExp = 0x1f;
    hMant = mant ? 0x200 : 0;
  } else if (exp !== 0) {
    const newExp = exp - 127 + 15;
    if (newExp >= 0x1f) {
      hExp = 0x1f;
    } else if (newExp > 0) {
      hExp = newExp;
      hMant = mant >> 13;
    }
  }
  return (sign << 15) | (hExp << 10) | hMant;
}

function f32ArrayToF16(arr) {
  const out = new Uint16Array(arr.length);
  for (let i = 0; i < arr.length; i++) {
    out[i] = f32ToF16Bits(arr[i]);
  }
  return out;
}

function bf16ToF32Array(bf16) {
  const out = new Float32Array(bf16.length);
  for (let i = 0; i < bf16.length; i++) {
    const view = new DataView(new ArrayBuffer(4));
    view.setUint32(0, bf16[i] << 16, true);
    out[i] = view.getFloat32(0, true);
  }
  return out;
}

function bf16ToF16Array(bf16) {
  const asF32 = bf16ToF32Array(bf16);
  return f32ArrayToF16(asF32);
}

function isFiniteArray(arr) {
  for (let i = 0; i < arr.length; i++) {
    if (!Number.isFinite(arr[i])) return false;
  }
  return true;
}

function isUnsupportedCapabilityError(error) {
  const message = error?.message || String(error || '');
  return (
    message.includes('requires features: shader-f16')
    || message.includes('shader-f16 support')
    || message.includes('requires unsupported GPU features')
    || message.includes('extension \'f16\' is not allowed in the current environment')
  );
}

function transposeRef(input, rows, cols) {
  const output = new Float32Array(rows * cols);
  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      output[c * rows + r] = input[r * cols + c];
    }
  }
  return output;
}

function matmulRefRowMajorB(input, weights, M, N, K) {
  const output = new Float32Array(M * N);
  for (let m = 0; m < M; m++) {
    const aBase = m * K;
    for (let n = 0; n < N; n++) {
      const bBase = n * K;
      let sum = 0;
      for (let k = 0; k < K; k++) {
        sum += input[aBase + k] * weights[bBase + k];
      }
      output[m * N + n] = sum;
    }
  }
  return output;
}

async function defineKernelTest(h, name, options) {
  const {
    dims,
    inputs,
    ref,
    gpu,
    tolerance,
    seed = 1234
  } = options;

  // Generate input data
  const generatedInputs = {};
  let currentSeed = seed;
  for (const [key, type] of Object.entries(inputs)) {
    if (type === 'float') {
      generatedInputs[key] = h.generateTestData(Object.values(dims).reduce((a, b) => a * b, 1), currentSeed++);
    } else if (type === 'uint') {
      generatedInputs[key] = generateUint32(Object.values(dims).reduce((a, b) => a * b, 1), 100, currentSeed++);
    }
  }

  const expected = await ref(h, generatedInputs, dims);
  const actual = await gpu(h, generatedInputs, dims);
  
  const result = h.compareArrays(expected, actual, tolerance);
  if (!result.passed) {
    console.error(`[KernelTests] ${name} mismatch`, result);
  }
  return result.passed;
}

export async function runKernelSuite(harness) {
  const h = harness || (typeof window !== 'undefined' ? window.testHarness : null) || defaultHarness;
  if (!h) throw new Error('Kernel harness not ready');

  const tests = [];

  tests.push([
    'matmul_f32',
    async () => {
      const M = 32, N = 48, K = 16;
      const A = h.generateTestData(M * K, 42);
      const B = h.generateTestData(K * N, 1337);
      const expected = h.matmulRef(A, B, M, N, K, 1.0);
      const actual = await h.runMatmul(null, A, B, M, N, K, 1.0);
      const result = h.compareArrays(expected, actual, h.KERNEL_TOLERANCES.matmul_f32);
      return result.passed;
    },
  ]);

  tests.push([
    'matmul_q4k',
    async () => {
      const M = 2, N = 4, K = 256;
      const A = h.generateTestData(M * K, 2101, { min: -0.5, max: 0.5 });
      const B = h.generateTestData(N * K, 2102, { min: -0.5, max: 0.5 });
      const numBlocks = N;
      const B_q4k = h.references.quantizeQ4_KRef(B, numBlocks);
      const B_dequant = h.references.dequantQ4_KRef(B_q4k, numBlocks);
      const expected = matmulRefRowMajorB(A, B_dequant, M, N, K);
      const actual = await h.runMatmulQ4K(null, A, B_q4k, M, N, K, 1.0);
      const result = h.compareArrays(expected, actual, { rtol: 1e-2, atol: 1e-2 });
      return result.passed;
    },
  ]);

  tests.push([
    'matmul_q4k_declared_widetile_accuracy',
    async () => {
      await h.getGPU();
      const decode = async (operand, Type) => {
        const bytes = Uint8Array.from(atob(operand.data), value => value.charCodeAt(0));
        const hash = Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256', bytes)),
          value => value.toString(16).padStart(2, '0')).join('');
        if (hash !== operand.sha256) throw new Error('Q4 accuracy operand identity changed');
        return new Type(bytes.buffer);
      };
      const input = await decode(q4Accuracy.input, Float32Array);
      const weights = await decode(q4Accuracy.weights, Uint8Array);
      const expected = await decode(q4Accuracy.reference, Float64Array);
      const { M, N, K, maxAbsoluteError } = q4Accuracy;
      const step = { op: 'qkv_proj', kernel: 'fused_matmul_q4_widetile.wgsl', entry: 'main',
        constants: { TILE_M: 4, TILE_N: 256 } };
      const options = { role: 'qkv_proj', phaseOverride: 'prefill', layerIdx: 0, outputDtype: 'f32',
        kernelPath: { activationDtype: 'f32', prefill: { steps: [step] }, decode: { steps: [step] } } };
      let inputBuffer, weightBuffer;
      try {
        inputBuffer = acquireBuffer(input.byteLength); weightBuffer = acquireBuffer(weights.byteLength);
        uploadData(inputBuffer, input); uploadData(weightBuffer, weights);
        const tensor = createTensor(inputBuffer, 'f32', [M, K]);
        const weight = createWeightBuffer(weightBuffer, 'q4k', 'row', [N, K]);
        for (const recorded of [false, true]) {
          const recorder = recorded ? new CommandRecorder(getDevice()) : null;
          let output;
          try {
            output = recorded ? await recordMatmul(recorder, tensor, weight, M, N, K, options)
              : await runMatmul(tensor, weight, M, N, K, options);
            if (recorder) await recorder.submitAndWait();
            const actual = new Float32Array(await readBufferSlice(output.buffer, 0, M * N * 4));
            for (let index = 0; index < expected.length; index++) {
              if (!Number.isFinite(actual[index]) || Math.abs(actual[index] - expected[index]) > maxAbsoluteError) {
                throw new Error(`Declared Q4 WideTile accuracy failed at ${index}: ${actual[index]} != ${expected[index]}`);
              }
            }
          } finally { if (output) releaseBuffer(output.buffer); recorder?.abort(); }
        }
        return true;
      } finally { if (weightBuffer) releaseBuffer(weightBuffer); if (inputBuffer) releaseBuffer(inputBuffer); }
    },
  ]);

  tests.push([
    'linear_attention_declared_activation_accuracy',
    async () => {
      await h.getGPU();
      const device = getDevice(), values = await decodeLinearReference(linearActivation.input);
      const owned = [], uniforms = [], allocate = data => {
        const buffer = acquireBuffer(data.byteLength); owned.push(buffer); uploadData(buffer, data); return buffer;
      };
      try {
        for (const dtype of ['f32', 'f16']) {
          const input = dtype === 'f16' ? f32ArrayToF16(values) : values;
          const rounded = dtype === 'f16' ? Float32Array.from(input, f16ToF32) : values;
          const inputBuffer = allocate(input), weight = allocate(new Float32Array(values.length).fill(1));
          const state = allocate(new Float32Array(values.length)), output = allocate(new Float32Array(values.length));
          const data = new ArrayBuffer(64), view = new DataView(data);
          [1, values.length, 1, 1, 1, 1, values.length - 2, 1, 1, values.length - 2, 1, 0]
            .forEach((value, index) => view.setUint32(index * 4, value, true));
          view.setFloat32(48, 1e-6, true); view.setFloat32(52, 1e-6, true);
          const params = device.createBuffer({ size: 64, usage: GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST });
          uniforms.push(params); device.queue.writeBuffer(params, 0, data);
          const module = await getShaderModule(device, `gated_delta_conv${dtype === 'f16' ? '_f16' : ''}.wgsl`);
          const pipeline = await device.createComputePipelineAsync({ layout: 'auto',
            compute: { module, entryPoint: 'main', constants: { WORKGROUP_SIZE: 256 } } });
          const group = device.createBindGroup({ layout: pipeline.getBindGroupLayout(0), entries:
            [params, inputBuffer, weight, state, output].map((buffer, binding) => ({ binding, resource: { buffer } })) });
          for (const recorded of [false, true]) {
            const recorder = recorded ? new CommandRecorder(device) : null;
            try {
              uploadData(state, new Float32Array(values.length));
              const encoder = recorder?.getEncoder() ?? device.createCommandEncoder();
              const pass = encoder.beginComputePass(); pass.setPipeline(pipeline); pass.setBindGroup(0, group);
              pass.dispatchWorkgroups(Math.ceil(values.length / 256)); pass.end();
              if (recorder) await recorder.submitAndWait(); else device.queue.submit([encoder.finish()]);
              const actual = new Float32Array(await readBufferSlice(output, 0, values.length * 4));
              for (let i = 0; i < actual.length; i++) {
                const expected = rounded[i] / (1 + Math.exp(-rounded[i]));
                const ulp = expected === 0 ? 2 ** -149 : 2 ** (Math.floor(Math.log2(Math.abs(expected))) - 23);
                if (!Number.isFinite(actual[i]) || Math.abs(actual[i] - expected) > linearActivation.maxUlp * ulp) {
                  throw new Error(`Declared ${dtype} linear activation failed at ${i}: ${actual[i]} != ${expected}`);
                }
              }
            } finally { recorder?.abort(); }
          }
        }
        return true;
      } finally {
        for (const buffer of owned) releaseBuffer(buffer);
        for (const buffer of uniforms) buffer.destroy();
      }
    },
  ]);

  tests.push([
    'linear_attention_captured_prefill_and_continuation_accuracy',
    async () => {
      await h.getGPU();
      const p = linearAccuracy.params, priorConfig = getRuntimeConfig();
      const inputs = Object.fromEntries(await Promise.all(linearAccuracy.input.map(async operand =>
        [operand.role, await decodeLinearReference(operand)])));
      const references = Object.fromEntries(await Promise.all(['prefill', 'decode'].map(async phase =>
        [phase, Object.fromEntries(await Promise.all(linearAccuracy[phase].map(async operand =>
          [operand.role, await decodeLinearReference(operand)])))])));
      try {
        setRuntimeConfig(linearAccuracy.decodeRuntimeConfig);
        for (const recorded of [false, true]) {
          const owned = [], allocate = data => {
            const buffer = acquireBuffer(data.byteLength); owned.push(buffer); uploadData(buffer, data); return buffer;
          };
          try {
            const layerState = { ...p, vSize: p.valueDim,
              convStateGPU: allocate(new Float32Array(p.convDim * p.convKernelSize)),
              recurrentStateGPU: allocate(new Float32Array(p.numVHeads * p.headKDim * p.headVDim)) };
            for (const role of ['convWeight', 'dtBias', 'aLog', 'normWeight']) layerState[`${role}GPU`] = allocate(inputs[role]);
            const buffers = Object.fromEntries(['qkv', 'z', 'a', 'b'].map(role => [role, allocate(inputs[role])]));
            const packed = new Float32Array(p.numVHeads * 2);
            packed.set(inputs.a.subarray(0, p.numVHeads)); packed.set(inputs.b.subarray(0, p.numVHeads), p.numVHeads);
            const packedBuffer = allocate(packed);
            for (const phase of ['prefill', 'decode']) {
              const count = phase === 'prefill' ? p.numTokens : 1;
              const recorder = recorded ? new CommandRecorder(getDevice()) : null;
              let output;
              try {
                const tensor = (role, width) => createTensor(buffers[role], 'f32', [count, width]);
                const ab = createTensor(packedBuffer, 'f32', [1, p.numVHeads * 2]);
                output = await runLinearAttentionCoreGPU(tensor('qkv', p.convDim), tensor('z', p.valueDim),
                  phase === 'prefill' ? tensor('a', p.numVHeads) : ab,
                  phase === 'prefill' ? tensor('b', p.numVHeads) : ab, layerState,
                  { recorder, numTokens: count, layerIdx: 0, qkL2NormEps: p.qkL2NormEps, outputDtype: 'f32',
                    abPacked: phase === 'decode', qkvzPacked: false,
                    bProjOffsetElements: phase === 'decode' ? p.numVHeads : 0 });
                if (recorder) await recorder.submitAndWait();
                for (const [role, buffer] of [['output', output.buffer], ['state', layerState.recurrentStateGPU]]) {
                  const expected = references[phase][role];
                  const actual = new Float32Array(await readBufferSlice(buffer, 0, expected.length * 4));
                  for (let i = 0; i < expected.length; i++) {
                    if (!Number.isFinite(actual[i]) || Math.abs(actual[i] - expected[i]) > linearAccuracy.maxAbsoluteError) {
                      throw new Error(`Captured linear ${phase} ${role} failed at ${i}: ${actual[i]} != ${expected[i]}`);
                    }
                  }
                }
              } finally { if (output) releaseBuffer(output.buffer); recorder?.abort(); }
            }
          } finally { for (const buffer of owned) releaseBuffer(buffer); }
        }
        return true;
      } finally { setRuntimeConfig(priorConfig); }
    },
  ]);

  tests.push([
    'matmul_f16w',
    async () => {
      const M = 2, N = 6, K = 32;
      const A = h.generateTestData(M * K, 2201);
      const B = h.generateTestData(N * K, 2202);
      const B_f16 = f32ArrayToF16(B);
      const B_rounded = new Float32Array(B_f16.length);
      for (let i = 0; i < B_f16.length; i++) {
        B_rounded[i] = f16ToF32(B_f16[i]);
      }
      const expected = matmulRefRowMajorB(A, B_rounded, M, N, K);
      const actual = await h.runMatmulF16W(null, A, B_f16, M, N, K);
      const result = h.compareArrays(expected, actual, h.KERNEL_TOLERANCES.matmul_f16);
      return result.passed;
    },
  ]);

  tests.push([
    'dequant_matmul_f16w',
    async () => {
      const M = 2, N = 4, K = 256;
      const A = h.generateTestData(M * K, 2301, { min: -0.5, max: 0.5 });
      const B = h.generateTestData(N * K, 2302, { min: -0.5, max: 0.5 });
      const numBlocks = N;
      const B_q4k = h.references.quantizeQ4_KRef(B, numBlocks);
      const B_dequant = h.references.dequantQ4_KRef(B_q4k, numBlocks);
      const B_f16 = f32ArrayToF16(B_dequant);
      const B_rounded = new Float32Array(B_f16.length);
      for (let i = 0; i < B_f16.length; i++) {
        B_rounded[i] = f16ToF32(B_f16[i]);
      }
      const expected = matmulRefRowMajorB(A, B_rounded, M, N, K);
      const actual = await h.runDequantAndMatmulF16W(null, A, B_q4k, M, N, K, numBlocks);
      const result = h.compareArrays(expected, actual, { rtol: 1e-2, atol: 1e-2 });
      return result.passed;
    },
  ]);

  tests.push([
    'matmul_transpose_a',
    async () => {
      const M = 16, N = 32, K = 8;
      const A_raw = h.generateTestData(K * M, 4201); // A is [K, M]
      const B = h.generateTestData(K * N, 4202); // B is [K, N]

      // Reference: C = A^T * B where A is [K, M], B is [K, N]
      const A_T = new Float32Array(M * K);
      for (let m = 0; m < M; m += 1) {
        const outputBase = m * K;
        const rawBase = m;
        for (let k = 0; k < K; k += 1) {
          A_T[outputBase + k] = A_raw[rawBase + k * M];
        }
      }
      const expected = h.matmulRef(A_T, B, M, N, K);
      
      const actual = await h.runMatmulTransposeA(null, A_raw, B, M, N, K);
      const result = h.compareArrays(expected, actual, h.KERNEL_TOLERANCES.matmul_f32);
      if (!result.passed) {
        console.error('[KernelTests] matmul_transpose_a mismatch', JSON.stringify({
          ...result,
          firstMismatches: result.firstMismatches,
        }));
      }
      return result.passed;
    },
  ]);

  tests.push([
    'matmul_f32_unaligned',
    async () => {
      const M = 13, N = 17, K = 7;
      const A = h.generateTestData(M * K, 43);
      const B = h.generateTestData(K * N, 1338);
      const expected = h.matmulRef(A, B, M, N, K, 1.0);
      const actual = await h.runMatmul(null, A, B, M, N, K, 1.0);
      const result = h.compareArrays(expected, actual, h.KERNEL_TOLERANCES.matmul_f32);
      return result.passed;
    },
  ]);

  tests.push([
    'bias_add_backward',
    async () => {
      const numTokens = 3;
      const dim = 7;
      const gradOutput = h.generateTestData(numTokens * dim, 1506);
      const expected = biasAddBackwardRef(gradOutput, numTokens, dim);
      const actual = await h.runBiasAddBackward(null, gradOutput, numTokens, dim);
      const result = h.compareArrays(expected, actual, h.KERNEL_TOLERANCES.residual);
      return result.passed;
    },
  ]);

  tests.push([
    'upsample2d_backward',
    async () => {
      const options = { channels: 2, inHeight: 3, inWidth: 3, scale: 2 };
      options.outHeight = options.inHeight * options.scale;
      options.outWidth = options.inWidth * options.scale;
      const gradOutput = h.generateTestData(options.channels * options.outHeight * options.outWidth, 1507);
      const expected = upsample2dBackwardRef(gradOutput, options);
      const actual = await h.runUpsample2DBackward(null, gradOutput, options);
      const result = h.compareArrays(expected, actual, h.KERNEL_TOLERANCES.residual);
      return result.passed;
    },
  ]);

  tests.push([
    'conv2d_backward',
    async () => {
      const options = {
        inChannels: 2,
        outChannels: 2,
        height: 4,
        width: 4,
        kernelH: 3,
        kernelW: 3,
        stride: 1,
        pad: 1,
      };
      options.outHeight = options.height;
      options.outWidth = options.width;
      const input = h.generateTestData(options.inChannels * options.height * options.width, 1508);
      const weight = h.generateTestData(options.outChannels * options.inChannels * options.kernelH * options.kernelW, 1509);
      const gradOutput = h.generateTestData(options.outChannels * options.outHeight * options.outWidth, 1510);
      
      const expected = conv2dBackwardRef(input, weight, gradOutput, options);
      const actual = await h.runConv2DBackward(null, input, weight, gradOutput, options);
      const conv2dBackwardTolerance = { rtol: 1e-5, atol: 1e-6 };
      
      const inputResult = h.compareArrays(expected.gradInput, actual.gradInput, conv2dBackwardTolerance);
      const weightResult = h.compareArrays(expected.gradWeight, actual.gradWeight, conv2dBackwardTolerance);
      const inPass = inputResult.passed;
      const wPass = weightResult.passed;
      if (!inPass || !wPass) {
        console.error('[KernelTests] conv2d_backward mismatch', JSON.stringify({
          inPass,
          wPass,
          inputResult: {
            ...inputResult,
            firstMismatches: inputResult.firstMismatches,
          },
          weightResult: {
            ...weightResult,
            firstMismatches: weightResult.firstMismatches,
          },
        }));
      }
      return inPass && wPass;
    },
  ]);

  tests.push([
    'attention_backward',
    async () => {
      const seqLen = 3; // Unaligned
      const kvLen = seqLen;
      const numHeads = 2;
      const numKVHeads = numHeads;
      const headDim = 8;
      const scale = 1.0 / Math.sqrt(headDim);
      
      const Q = h.generateTestData(seqLen * numHeads * headDim, 1603);
      const K = h.generateTestData(kvLen * numKVHeads * headDim, 1604);
      const V = h.generateTestData(kvLen * numKVHeads * headDim, 1605);
      const gradOutput = h.generateTestData(seqLen * numHeads * headDim, 1606);
      
      // We need a proper softmax matrix for the reference
      const scores = new Float32Array(numHeads * seqLen * kvLen);
      const headsPerKV = numHeads / numKVHeads;
      for (let hIdx = 0; hIdx < numHeads; hIdx++) {
        const kvHead = Math.floor(hIdx / headsPerKV);
        for (let q = 0; q < seqLen; q++) {
          let maxVal = -Infinity;
          for (let k = 0; k < kvLen; k++) {
            let score = 0;
            for (let d = 0; d < headDim; d++) {
              score += Q[(q * numHeads + hIdx) * headDim + d] * K[(k * numKVHeads + kvHead) * headDim + d];
            }
            score *= scale;
            scores[(hIdx * seqLen + q) * kvLen + k] = score;
            maxVal = Math.max(maxVal, score);
          }
          let sumExp = 0;
          for (let k = 0; k < kvLen; k++) {
            const val = Math.exp(scores[(hIdx * seqLen + q) * kvLen + k] - maxVal);
            scores[(hIdx * seqLen + q) * kvLen + k] = val;
            sumExp += val;
          }
          for (let k = 0; k < kvLen; k++) {
            scores[(hIdx * seqLen + q) * kvLen + k] /= sumExp;
          }
        }
      }

      const expected = h.references.attentionBackwardRef(Q, K, V, scores, gradOutput, seqLen, kvLen, numHeads, numKVHeads, headDim, scale);
      const actual = await h.runAttentionBackward(null, Q, K, V, scores, gradOutput, seqLen, numHeads, headDim, scale);
      
      const qPass = h.compareArrays(expected.gradQ, actual.gradQ, h.KERNEL_TOLERANCES.attention).passed;
      const kPass = h.compareArrays(expected.gradK, actual.gradK, h.KERNEL_TOLERANCES.attention).passed;
      const vPass = h.compareArrays(expected.gradV, actual.gradV, h.KERNEL_TOLERANCES.attention).passed;
      if (!qPass || !kPass || !vPass) {
        const qResult = h.compareArrays(expected.gradQ, actual.gradQ, h.KERNEL_TOLERANCES.attention);
        const kResult = h.compareArrays(expected.gradK, actual.gradK, h.KERNEL_TOLERANCES.attention);
        const vResult = h.compareArrays(expected.gradV, actual.gradV, h.KERNEL_TOLERANCES.attention);
        console.error('[KernelTests] attention_backward mismatch', JSON.stringify({
          qPass,
          kPass,
          vPass,
          qResult: {
            ...qResult,
            firstMismatches: qResult.firstMismatches,
          },
          kResult: {
            ...kResult,
            firstMismatches: kResult.firstMismatches,
          },
          vResult: {
            ...vResult,
            firstMismatches: vResult.firstMismatches,
          },
        }));
      }
      return qPass && kPass && vPass;
    },
  ]);

  tests.push([
    'rmsnorm_unaligned',
    async () => {
      const numTokens = 7;
      const hiddenSize = 31;
      const input = h.generateTestData(numTokens * hiddenSize, 93);
      const weight = h.generateTestData(hiddenSize, 94);
      const expected = h.references.rmsNormRef(input, weight, numTokens, hiddenSize, 1e-6);
      const actual = await h.runRMSNorm(null, input, weight, numTokens, hiddenSize, 1e-6);
      const result = h.compareArrays(expected, actual, h.KERNEL_TOLERANCES.rmsnorm);
      return result.passed;
    },
  ]);

  tests.push([
    'layernorm_unaligned',
    async () => {
      const batchSize = 3;
      const hiddenSize = 17;
      const input = h.generateTestData(batchSize * hiddenSize, 95);
      const weight = h.generateTestData(hiddenSize, 96);
      const bias = h.generateTestData(hiddenSize, 97);
      const expected = layerNormRef(input, weight, bias, batchSize, hiddenSize, 1e-5);
      const actual = await h.runLayerNorm(null, input, weight, bias, batchSize, hiddenSize, 1e-5);
      const result = h.compareArrays(expected, actual, h.KERNEL_TOLERANCES.rmsnorm);
      return result.passed;
    },
  ]);

  tests.push([
    'softmax',
    async () => {
      const outerSize = 4;
      const innerSize = 32;
      const input = h.generateTestData(outerSize * innerSize, 7);
      const expected = h.softmax(input, innerSize, outerSize, 1.0);
      const actual = await h.runSoftmax(null, input, innerSize, outerSize, 1.0);
      const result = h.compareArrays(expected, actual, h.KERNEL_TOLERANCES.softmax);
      return result.passed;
    },
  ]);

  tests.push([
    'rmsnorm',
    async () => {
      const numTokens = 4;
      const hiddenSize = 32;
      const input = h.generateTestData(numTokens * hiddenSize, 91);
      const weight = h.generateTestData(hiddenSize, 92);
      const expected = h.references.rmsNormRef(input, weight, numTokens, hiddenSize, 1e-6);
      const actual = await h.runRMSNorm(null, input, weight, numTokens, hiddenSize, 1e-6);
      const result = h.compareArrays(expected, actual, h.KERNEL_TOLERANCES.rmsnorm);
      return result.passed;
    },
  ]);

  tests.push([
    'rmsnorm_declared_main_accuracy',
    async () => {
      await h.getGPU();
      const decode = async (operand, Type) => {
        const bytes = Uint8Array.from(atob(operand.data), value => value.charCodeAt(0));
        const hash = Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256', bytes)),
          value => value.toString(16).padStart(2, '0')).join('');
        if (hash !== operand.sha256) throw new Error('RMSNorm accuracy operand identity changed');
        return new Type(bytes.buffer);
      };
      const input = await decode(rmsNormAccuracy.input, Float32Array);
      const packedWeights = await decode(rmsNormAccuracy.weight, Uint16Array);
      const weights = Float32Array.from(packedWeights,
        value => f16ToF32(value) + Number(rmsNormAccuracy.weightOffset));
      const { hiddenSize, epsilon, maxAbsoluteError } = rmsNormAccuracy;
      const expected = h.references.rmsNormRef(input, weights, 1, hiddenSize, epsilon);
      const step = { op: 'input_norm', kernel: 'rmsnorm.wgsl', entry: 'main' };
      const options = { batchSize: 1, hiddenSize, rmsNormWeightOffset: rmsNormAccuracy.weightOffset,
        role: 'input_norm', section: 'layer', phase: 'prefill', layerIdx: 0,
        kernelPath: { activationDtype: 'f32', prefill: { steps: [step] }, decode: { steps: [step] } } };
      let inputBuffer, weightBuffer;
      try {
        inputBuffer = acquireBuffer(input.byteLength);
        weightBuffer = acquireBuffer(packedWeights.byteLength);
        uploadData(inputBuffer, input); uploadData(weightBuffer, packedWeights);
        const tensor = createTensor(inputBuffer, 'f32', [1, hiddenSize]);
        const weight = createWeightBuffer(weightBuffer, 'f16', 'row', [hiddenSize]);
        for (const recorded of [false, true]) {
          const recorder = recorded ? new CommandRecorder(getDevice()) : null;
          let output;
          try {
            output = recorded ? await recordRMSNorm(recorder, tensor, weight, epsilon, options)
              : await runRMSNorm(tensor, weight, epsilon, options);
            if (recorder) await recorder.submitAndWait();
            const actual = new Float32Array(await readBufferSlice(output.buffer, 0, input.byteLength));
            for (let index = 0; index < expected.length; index++) {
              if (!Number.isFinite(actual[index]) || Math.abs(actual[index] - expected[index]) > maxAbsoluteError) {
                throw new Error(`Declared RMSNorm main accuracy failed at ${index}: ${actual[index]} != ${expected[index]}`);
              }
            }
          } finally {
            if (output) releaseBuffer(output.buffer);
            recorder?.abort();
          }
        }
        return true;
      } finally {
        if (weightBuffer) releaseBuffer(weightBuffer);
        if (inputBuffer) releaseBuffer(inputBuffer);
      }
    },
  ]);

  tests.push([
    'rope',
    async () => {
      const seqLen = 4;
      const numHeads = 2;
      const headDim = 8;
      const input = h.generateTestData(seqLen * numHeads * headDim, 314);
      const { cos, sin } = h.references.computeRopeFreqs(headDim, seqLen);
      const expected = h.references.ropeRef(input, cos, sin, seqLen, numHeads, headDim, 0);
      const actual = await h.runRoPE(null, input, seqLen, numHeads, headDim, 0);
      const result = h.compareArrays(expected, actual, h.KERNEL_TOLERANCES.rope);
      return result.passed;
    },
  ]);

  tests.push([
    'silu',
    async () => {
      const input = h.generateTestData(1024, 123);
      const expected = h.references.siluRef(input);
      const actual = await h.runSiLU(null, input);
      const result = h.compareArrays(expected, actual, h.KERNEL_TOLERANCES.silu);
      return result.passed;
    },
  ]);

  tests.push([
    'silu_gated',
    async () => {
      const gate = h.generateTestData(1024, 124);
      const up = h.generateTestData(1024, 125);
      const expected = h.references.siluGatedRef(gate, up);
      const actual = await h.runSiLUGated(null, gate, up);
      const result = h.compareArrays(expected, actual, h.KERNEL_TOLERANCES.silu);
      return result.passed;
    },
  ]);

  tests.push([
    'gelu',
    async () => {
      const input = h.generateTestData(1024, 201);
      const expected = h.references.geluRef(input);
      const actual = await h.runGeLU(null, input);
      const result = h.compareArrays(expected, actual, h.KERNEL_TOLERANCES.silu);
      return result.passed;
    },
  ]);

  tests.push([
    'geglu',
    async () => {
      const gate = h.generateTestData(1024, 202);
      const up = h.generateTestData(1024, 203);
      const expected = h.references.gegluRef(gate, up);
      const actual = await h.runGeGLU(null, gate, up);
      const result = h.compareArrays(expected, actual, h.KERNEL_TOLERANCES.silu);
      return result.passed;
    },
  ]);

  tests.push([
    'gather',
    async () => {
      const vocabSize = 64;
      const embedDim = 16;
      const numTokens = 8;
      const embeddings = h.generateTestData(vocabSize * embedDim, 401);
      const indices = generateUint32(numTokens, vocabSize, 402);
      const expected = h.references.gatherRef(embeddings, indices, vocabSize, embedDim);
      const actual = await h.runGather(null, embeddings, indices, vocabSize, embedDim);
      const result = h.compareArrays(expected, actual, { rtol: 0, atol: 0 });
      return result.passed;
    },
  ]);

  tests.push([
    'gather_f16_f32_glmocr_prefill_geometry',
    async () => {
      await h.getGPU();
      const vocabSize = 4;
      const hiddenSize = 1536;
      const numTokens = 4362;
      const embedding = new Float32Array(vocabSize * hiddenSize);
      for (let token = 0; token < vocabSize; token++) {
        for (let dim = 0; dim < hiddenSize; dim++) {
          embedding[token * hiddenSize + dim] = (token + 1) * 0.125 + (dim % 8) * 0.03125;
        }
      }
      const indices = new Uint32Array(numTokens);
      for (let token = 0; token < numTokens; token++) {
        indices[token] = token % vocabSize;
      }
      const embeddingBuffer = acquireBuffer(
        embedding.length * Uint16Array.BYTES_PER_ELEMENT,
        undefined,
        'gather_glmocr_embedding'
      );
      const indicesBuffer = acquireBuffer(
        indices.byteLength,
        undefined,
        'gather_glmocr_indices'
      );
      uploadData(embeddingBuffer, f32ArrayToF16(embedding));
      uploadData(indicesBuffer, indices);
      let outputTensor = null;
      try {
        outputTensor = await runGather(
          indicesBuffer,
          embeddingBuffer,
          numTokens,
          hiddenSize,
          vocabSize,
          {
            transpose: false,
            embeddingDtype: 'f16',
            outputDtype: 'f32',
          }
        );
        for (const token of [0, 1, numTokens - 1]) {
          const actual = new Float32Array(
            await readBufferSlice(
              outputTensor.buffer,
              token * hiddenSize * Float32Array.BYTES_PER_ELEMENT,
              hiddenSize * Float32Array.BYTES_PER_ELEMENT
            )
          );
          const sourceToken = indices[token];
          for (let dim = 0; dim < hiddenSize; dim++) {
            const expected = embedding[sourceToken * hiddenSize + dim];
            if (actual[dim] !== expected) {
              return false;
            }
          }
        }
        return true;
      } finally {
        if (outputTensor) {
          releaseBuffer(outputTensor.buffer);
        }
        releaseBuffer(embeddingBuffer);
        releaseBuffer(indicesBuffer);
      }
    },
  ]);

  tests.push([
    'prefix_embedding_override_composition',
    async () => {
      await h.getGPU();
      const hiddenSize = 4;
      const numTokens = 4;
      const base = new Float32Array([
        1, 2, 3, 4,
        5, 6, 7, 8,
        9, 10, 11, 12,
        13, 14, 15, 16,
      ]);
      const replacement = new Float32Array([
        101, 102, 103, 104,
        105, 106, 107, 108,
      ]);
      const expected = base.slice();
      expected.set(replacement, hiddenSize);
      const baseBuffer = h.makeBuffer(base);
      const replacementBuffer = h.makeBuffer(replacement);
      let outputTensor = null;
      try {
        const override = normalizePrefixEmbeddingOverride(
          {
            prefixLength: 2,
            offset: 1,
            embeddings: replacementBuffer,
          },
          hiddenSize,
          numTokens,
          'prefix_embedding_override_composition'
        );
        outputTensor = await applyPrefixEmbeddingOverride(
          createTensor(baseBuffer, 'f32', [numTokens, hiddenSize], 'prefix_embedding_base'),
          override,
          hiddenSize,
          'prefix_embedding_override_composition'
        );
        const actual = new Float32Array(
          await h.readBufferData(outputTensor.buffer, expected.byteLength)
        );
        return compareExact(expected, actual);
      } finally {
        if (outputTensor) {
          releaseBuffer(outputTensor.buffer);
        }
        baseBuffer.destroy();
        replacementBuffer.destroy();
      }
    },
  ]);

  tests.push([
    'prefix_embedding_override_survives_base_pool_reuse',
    async () => {
      await h.getGPU();
      const hiddenSize = 4;
      const numTokens = 4;
      const base = new Float32Array([
        1, 2, 3, 4,
        5, 6, 7, 8,
        9, 10, 11, 12,
        13, 14, 15, 16,
      ]);
      const replacement = new Float32Array([
        101, 102, 103, 104,
        105, 106, 107, 108,
      ]);
      const expected = base.slice();
      expected.set(replacement, hiddenSize);
      const baseBuffer = acquireBuffer(base.byteLength, undefined, 'prefix_embedding_recycled_base');
      const replacementBuffer = acquireBuffer(
        replacement.byteLength,
        undefined,
        'prefix_embedding_recycled_replacement'
      );
      uploadData(baseBuffer, base);
      uploadData(replacementBuffer, replacement);
      let baseOwned = true;
      let replacementOwned = true;
      let outputTensor = null;
      let recycledBuffer = null;
      try {
        const override = normalizePrefixEmbeddingOverride(
          {
            prefixLength: 2,
            offset: 1,
            embeddings: replacementBuffer,
          },
          hiddenSize,
          numTokens,
          'prefix_embedding_override_survives_base_pool_reuse'
        );
        outputTensor = await applyPrefixEmbeddingOverride(
          createTensor(baseBuffer, 'f32', [numTokens, hiddenSize], 'prefix_embedding_recycled_base'),
          override,
          hiddenSize,
          'prefix_embedding_override_survives_base_pool_reuse'
        );
        releaseBuffer(baseBuffer);
        baseOwned = false;
        recycledBuffer = acquireBuffer(
          baseBuffer.size,
          undefined,
          'prefix_embedding_recycled_base_consumer'
        );
        uploadData(recycledBuffer, new Float32Array(recycledBuffer.size / 4));
        const actual = new Float32Array(
          await h.readBufferData(outputTensor.buffer, expected.byteLength)
        );
        return recycledBuffer === baseBuffer && compareExact(expected, actual);
      } finally {
        if (outputTensor) {
          releaseBuffer(outputTensor.buffer);
        }
        if (recycledBuffer) {
          releaseBuffer(recycledBuffer);
        } else if (baseOwned) {
          releaseBuffer(baseBuffer);
        }
        if (replacementOwned) {
          releaseBuffer(replacementBuffer);
          replacementOwned = false;
        }
      }
    },
  ]);

  tests.push([
    'prefix_embedding_override_glmocr_geometry',
    async () => {
      await h.getGPU();
      const hiddenSize = 1536;
      const numTokens = 4362;
      const prefixLength = 4350;
      const offset = 5;
      const base = new Float32Array(numTokens * hiddenSize);
      const replacement = new Float32Array(prefixLength * hiddenSize);
      const baseRows = new Map([
        [0, new Float32Array([1, 2, 3, 4, 5, 6, 7, 8])],
        [4, new Float32Array([11, 12, 13, 14, 15, 16, 17, 18])],
        [4355, new Float32Array([21, 22, 23, 24, 25, 26, 27, 28])],
        [4361, new Float32Array([31, 32, 33, 34, 35, 36, 37, 38])],
      ]);
      const replacementRows = new Map([
        [0, new Float32Array([101, 102, 103, 104, 105, 106, 107, 108])],
        [prefixLength - 1, new Float32Array([111, 112, 113, 114, 115, 116, 117, 118])],
      ]);
      for (const [row, values] of baseRows) {
        base.set(values, row * hiddenSize);
      }
      for (const [row, values] of replacementRows) {
        replacement.set(values, row * hiddenSize);
      }
      const baseBuffer = acquireBuffer(base.byteLength, undefined, 'prefix_embedding_glmocr_base');
      const replacementBuffer = acquireBuffer(
        replacement.byteLength,
        undefined,
        'prefix_embedding_glmocr_replacement'
      );
      uploadData(baseBuffer, base);
      uploadData(replacementBuffer, replacement);
      let outputTensor = null;
      try {
        const override = normalizePrefixEmbeddingOverride(
          {
            prefixLength,
            offset,
            embeddings: replacementBuffer,
          },
          hiddenSize,
          numTokens,
          'prefix_embedding_override_glmocr_geometry'
        );
        outputTensor = await applyPrefixEmbeddingOverride(
          createTensor(baseBuffer, 'f32', [numTokens, hiddenSize], 'prefix_embedding_glmocr_base'),
          override,
          hiddenSize,
          'prefix_embedding_override_glmocr_geometry'
        );
        const expectedRows = new Map([
          ...baseRows,
          [offset, replacementRows.get(0)],
          [offset + prefixLength - 1, replacementRows.get(prefixLength - 1)],
        ]);
        for (const [row, expectedPrefix] of expectedRows) {
          const byteOffset = row * hiddenSize * Float32Array.BYTES_PER_ELEMENT;
          const actualRow = new Float32Array(
            await readBufferSlice(
              outputTensor.buffer,
              byteOffset,
              hiddenSize * Float32Array.BYTES_PER_ELEMENT
            )
          );
          if (!compareExact(expectedPrefix, actualRow.slice(0, expectedPrefix.length))) {
            return false;
          }
          for (let dim = expectedPrefix.length; dim < actualRow.length; dim++) {
            if (actualRow[dim] !== 0) {
              return false;
            }
          }
        }
        return true;
      } finally {
        if (outputTensor) {
          releaseBuffer(outputTensor.buffer);
        }
        releaseBuffer(baseBuffer);
        releaseBuffer(replacementBuffer);
      }
    },
  ]);

  tests.push([
    'residual',
    async () => {
      const x = h.generateTestData(512, 501);
      const residual = h.generateTestData(512, 502);
      const expected = h.references.residualAddRef(x, residual);
      const actual = await h.runResidual(null, x, residual);
      const result = h.compareArrays(expected, actual, h.KERNEL_TOLERANCES.residual);
      return result.passed;
    },
  ]);

  tests.push([
    'residual_output_scale',
    async () => {
      const x = h.generateTestData(512, 503);
      const residual = h.generateTestData(512, 504);
      const outputScale = 0.125;
      const expected = h.references.outputScaledResidualAddRef(x, residual, outputScale);
      const actual = await h.runResidual(null, x, residual, { outputScale });
      const result = h.compareArrays(expected, actual, h.KERNEL_TOLERANCES.residual);
      return result.passed;
    },
  ]);

  tests.push([
    'topk',
    async () => {
      const numTokens = 2;
      const numExperts = 16;
      const topK = 4;
      const probs = h.generateTestData(numTokens * numExperts, 601, { min: 0, max: 1 });
      const expected = h.references.topkRef(probs, numTokens, numExperts, topK, true);
      const actual = await h.runTopK(null, probs, numTokens, numExperts, topK, { normalize: true });
      const indicesMatch = compareExact(expected.indices, actual.indices);
      const weightsMatch = h.compareArrays(
        expected.weights,
        actual.weights,
        h.KERNEL_TOLERANCES.topk.weights
      ).passed;
      return indicesMatch && weightsMatch;
    },
  ]);

  tests.push([
    'softmax_topk',
    async () => {
      const numTokens = 2;
      const numExperts = 16;
      const topK = 4;
      const logits = h.generateTestData(numTokens * numExperts, 602);
      const expected = h.references.softmaxTopkRef(logits, numTokens, numExperts, topK, true);
      const actual = await h.runSoftmaxTopK(null, logits, numTokens, numExperts, topK, {
        normalize: true,
        inputDtype: 'f32',
        weightsDtype: 'f32',
      });
      const indicesMatch = compareExact(expected.indices, actual.indices);
      const weightsMatch = h.compareArrays(
        expected.weights,
        actual.weights,
        h.KERNEL_TOLERANCES.topk.weights
      ).passed;
      return indicesMatch && weightsMatch;
    },
  ]);

  tests.push([
    'scatter_add',
    async () => {
      const numTokens = 4;
      const hiddenSize = 8;
      const numExperts = 3;
      const topK = 2;
      const expertOutputs = h.generateTestData(numExperts * numTokens * hiddenSize, 701);
      const indices = generateUint32(numTokens * topK, numExperts, 702);
      const weights = generateNormalizedWeights(numTokens, topK, 703);
      const expected = h.references.scatterAddRef(
        expertOutputs,
        indices,
        weights,
        numTokens,
        hiddenSize,
        numExperts,
        topK
      );
      const actual = await h.runScatterAdd(
        null,
        expertOutputs,
        indices,
        weights,
        numTokens,
        hiddenSize,
        numExperts,
        topK
      );
      const result = h.compareArrays(expected, actual, h.KERNEL_TOLERANCES.scatter_add);
      return result.passed;
    },
  ]);

  tests.push([
    'moe_gather',
    async () => {
      const numTokens = 4;
      const hiddenSize = 8;
      const numExperts = 3;
      const topK = 2;
      const tokens = h.generateTestData(numTokens * hiddenSize, 801);
      const indices = generateUint32(numTokens * topK, numExperts, 802);
      const expected = h.references.moeGatherRef(tokens, indices, numTokens, hiddenSize, numExperts, topK);
      const actual = await h.runMoEGather(null, tokens, indices, numTokens, hiddenSize, numExperts, topK);
      const tokensMatch = h.compareArrays(
        expected.gatheredTokens,
        actual.gatheredTokens,
        h.KERNEL_TOLERANCES.moe_gather
      ).passed;
      const countsMatch = compareExact(expected.tokenCounts, actual.tokenCounts);
      return tokensMatch && countsMatch;
    },
  ]);

  tests.push([
    'attention',
    async () => {
      const seqLen = 2;
      const kvLen = 4;
      const numHeads = 2;
      const numKVHeads = 1;
      const headDim = 8;
      const Q = h.generateTestData(seqLen * numHeads * headDim, 901);
      const K = h.generateTestData(kvLen * numKVHeads * headDim, 902);
      const V = h.generateTestData(kvLen * numKVHeads * headDim, 903);
      const expected = h.references.attentionRef(Q, K, V, seqLen, kvLen, numHeads, numKVHeads, headDim, null);
      const actual = await h.runAttention(null, Q, K, V, seqLen, kvLen, numHeads, numKVHeads, headDim, null);
      const result = h.compareArrays(expected, actual, h.KERNEL_TOLERANCES.attention);
      return result.passed;
    },
  ]);

  tests.push([
    'dequant_q4k_f32',
    async () => {
      const numBlocks = 2;
      const values = h.generateTestData(numBlocks * 256, 1001);
      const quantized = h.references.quantizeQ4_KRef(values, numBlocks);
      const expected = h.references.dequantQ4_KRef(quantized, numBlocks);
      const actual = await h.runDequantQ4K(null, quantized, numBlocks);
      const result = h.compareArrays(expected, actual, h.KERNEL_TOLERANCES.dequant);
      if (!result.passed) {
        console.error('[KernelTests] dequant_q4k_f32 mismatch', JSON.stringify(result));
      }
      return result.passed;
    },
  ]);

  // === Q4K vec4 dequant parity: tests main_vec4 entry point (TranslateGemma 4B failure path) ===

  tests.push([
    'dequant_q4k_vec4_1block',
    async () => {
      const resolvedVariant = h.selectDequantKernel({ useVec4: true, outputDtype: 'f32' });
      if (!resolvedVariant.includes('vec4')) {
        console.warn(`[SKIP] dequant_q4k_vec4_1block: resolved variant "${resolvedVariant}" is not vec4`);
        return true; // skip, not fail
      }
      console.log(`[dequant_q4k_vec4_1block] variant=${resolvedVariant}`);

      const numBlocks = 1;
      const values = h.generateTestData(numBlocks * 256, 2001);
      const quantized = h.references.quantizeQ4_KRef(values, numBlocks);
      const expected = h.references.dequantQ4_KRef(quantized, numBlocks);
      const actual = await h.runDequantQ4K_Vec4(null, quantized, numBlocks);
      const result = h.compareArrays(expected, actual, h.KERNEL_TOLERANCES.dequant);
      if (!result.passed) {
        console.error(`[FAIL] dequant_q4k_vec4_1block: maxErr=${result.maxError}, failIdx=${result.failIndex}`);
      }
      return result.passed;
    },
  ]);

  tests.push([
    'dequant_q4k_vec4_10blocks',
    async () => {
      // 10 blocks = one row of TranslateGemma 4B q_proj (K=2560, blocksPerRow=10)
      const resolvedVariant = h.selectDequantKernel({ useVec4: true, outputDtype: 'f32' });
      if (!resolvedVariant.includes('vec4')) {
        console.warn(`[SKIP] dequant_q4k_vec4_10blocks: resolved variant "${resolvedVariant}" is not vec4`);
        return true;
      }
      console.log(`[dequant_q4k_vec4_10blocks] variant=${resolvedVariant}, numBlocks=10`);

      const numBlocks = 10;
      const values = h.generateTestData(numBlocks * 256, 2002);
      const quantized = h.references.quantizeQ4_KRef(values, numBlocks);
      const expected = h.references.dequantQ4_KRef(quantized, numBlocks);
      const actual = await h.runDequantQ4K_Vec4(null, quantized, numBlocks);
      const result = h.compareArrays(expected, actual, h.KERNEL_TOLERANCES.dequant);
      if (!result.passed) {
        console.error(`[FAIL] dequant_q4k_vec4_10blocks: maxErr=${result.maxError}, failIdx=${result.failIndex}`);
      }
      return result.passed;
    },
  ]);

  tests.push([
    'dequant_q4k_vec4_projection_scale',
    async () => {
      // Full TranslateGemma 4B q_proj geometry: 2048 rows × 10 blocks/row = 20480 blocks
      const resolvedVariant = h.selectDequantKernel({ useVec4: true, outputDtype: 'f32' });
      if (!resolvedVariant.includes('vec4')) {
        console.warn(`[SKIP] dequant_q4k_vec4_projection_scale: resolved variant "${resolvedVariant}" is not vec4`);
        return true;
      }

      const numBlocks = 20480;
      console.log(`[dequant_q4k_vec4_projection_scale] variant=${resolvedVariant}, numBlocks=${numBlocks} (2048×10)`);

      const values = h.generateTestData(numBlocks * 256, 2003);
      const quantized = h.references.quantizeQ4_KRef(values, numBlocks);
      const expected = h.references.dequantQ4_KRef(quantized, numBlocks);
      const actual = await h.runDequantQ4K_Vec4(null, quantized, numBlocks);

      // Sample-check: compare first row (10 blocks = 2560 elements), middle row, last row
      const rowBlocks = 10;
      const checkRows = [0, 1024, 2047];
      for (const row of checkRows) {
        const start = row * rowBlocks * 256;
        const end = start + rowBlocks * 256;
        const result = h.compareArrays(
          expected.slice(start, end),
          actual.slice(start, end),
          h.KERNEL_TOLERANCES.dequant
        );
        if (!result.passed) {
          console.error(
            `[FAIL] dequant_q4k_vec4_projection_scale row ${row}: ` +
            `maxErr=${result.maxError}, failIdx=${result.failIndex} (absolute idx=${start + result.failIndex})`
          );
          return false;
        }
      }
      return true;
    },
  ]);

  tests.push([
    'dequant_q4k_vec4_real_weights',
    async () => {
      // Use real Q4K bytes from the TranslateGemma 4B artifact (if available via fetch)
      const resolvedVariant = h.selectDequantKernel({ useVec4: true, outputDtype: 'f32' });
      if (!resolvedVariant.includes('vec4')) {
        console.warn(`[SKIP] dequant_q4k_vec4_real_weights: resolved variant "${resolvedVariant}" is not vec4`);
        return true;
      }

      // Try to fetch 10 blocks (1 row) from the Q4K artifact
      const manifestUrl = '/models/local/translategemma-4b-it-q4k-ehf16-af32/manifest.json';
      let manifest;
      try {
        const resp = await fetch(manifestUrl);
        if (!resp.ok) {
          console.warn(`[SKIP] dequant_q4k_vec4_real_weights: manifest fetch failed (${resp.status})`);
          return true;
        }
        manifest = await resp.json();
      } catch {
        console.warn('[SKIP] dequant_q4k_vec4_real_weights: manifest not available');
        return true;
      }

      const qprojInfo = manifest.tensors['language_model.model.layers.0.self_attn.q_proj.weight'];
      if (!qprojInfo) {
        console.warn('[SKIP] dequant_q4k_vec4_real_weights: q_proj tensor not found in manifest');
        return true;
      }

      const shardIdx = qprojInfo.shard;
      const shardFile = manifest.shards.find(s => s.index === shardIdx)?.filename;
      if (!shardFile) {
        console.warn('[SKIP] dequant_q4k_vec4_real_weights: shard file not found');
        return true;
      }

      // Read first row (10 blocks × 144 bytes = 1440 bytes)
      const blockBytes = 144;
      const blocksPerRow = 10;
      const readSize = blocksPerRow * blockBytes;
      const shardUrl = `/models/local/translategemma-4b-it-q4k-ehf16-af32/${shardFile}`;
      let rowData;
      try {
        const resp = await fetch(shardUrl, {
          headers: { Range: `bytes=${qprojInfo.offset}-${qprojInfo.offset + readSize - 1}` },
        });
        if (!resp.ok) {
          console.warn(`[SKIP] dequant_q4k_vec4_real_weights: shard fetch failed (${resp.status})`);
          return true;
        }
        rowData = new Uint8Array(await resp.arrayBuffer());
      } catch {
        console.warn('[SKIP] dequant_q4k_vec4_real_weights: shard not fetchable');
        return true;
      }

      if (rowData.length !== readSize) {
        console.warn(`[SKIP] dequant_q4k_vec4_real_weights: expected ${readSize} bytes, got ${rowData.length}`);
        return true;
      }

      console.log(`[dequant_q4k_vec4_real_weights] variant=${resolvedVariant}, blocksPerRow=${blocksPerRow}`);

      const expected = h.references.dequantQ4_KRef(rowData, blocksPerRow);
      const actual = await h.runDequantQ4K_Vec4(null, rowData, blocksPerRow);
      const result = h.compareArrays(expected, actual, h.KERNEL_TOLERANCES.dequant);
      if (!result.passed) {
        console.error(
          `[FAIL] dequant_q4k_vec4_real_weights: maxErr=${result.maxError}, failIdx=${result.failIndex}, ` +
          `expected[${result.failIndex}]=${expected[result.failIndex]}, actual[${result.failIndex}]=${actual[result.failIndex]}`
        );
      }
      return result.passed;
    },
  ]);

  tests.push([
    'dequant_q4k_f16',
    async () => {
      const numBlocks = 2;
      const values = h.generateTestData(numBlocks * 256, 1002);
      const quantized = h.references.quantizeQ4_KRef(values, numBlocks);
      const expected = h.references.dequantQ4_KRef(quantized, numBlocks);
      const expectedF16 = f32ArrayToF16(expected);
      const expectedRounded = new Float32Array(expectedF16.length);
      for (let i = 0; i < expectedF16.length; i++) {
        expectedRounded[i] = f16ToF32(expectedF16[i]);
      }
      const actual = await h.runDequantQ4K_F16(null, quantized, numBlocks);
      const result = h.compareArrays(expectedRounded, actual, { rtol: 1e-3, atol: 1e-3 });
      return result.passed;
    },
  ]);

  tests.push([
    'dequant_q6k_smoke',
    async () => {
      const numBlocks = 1;
      const quantized = new Uint8Array(numBlocks * 210);
      const actual = await h.runDequantQ6K(null, quantized, numBlocks);
      return actual.length === numBlocks * 256 && isFiniteArray(actual);
    },
  ]);

  tests.push([
    'cast_f32_to_f16',
    async () => {
      const input = h.generateTestData(128, 1101);
      const expectedBits = f32ArrayToF16(input);
      const actualBits = await h.runF32ToF16(null, input);
      const expected = new Float32Array(expectedBits.length);
      const actual = new Float32Array(actualBits.length);
      for (let i = 0; i < expectedBits.length; i++) {
        expected[i] = f16ToF32(expectedBits[i]);
        actual[i] = f16ToF32(actualBits[i]);
      }
      const result = h.compareArrays(expected, actual, { rtol: 1e-3, atol: 1e-3 });
      return result.passed;
    },
  ]);

  tests.push([
    'cast_f16_to_f32',
    async () => {
      const input = f32ArrayToF16(h.generateTestData(128, 1102));
      const expected = new Float32Array(input.length);
      for (let i = 0; i < input.length; i++) {
        expected[i] = f16ToF32(input[i]);
      }
      const actual = await h.runF16ToF32(null, input);
      const result = h.compareArrays(expected, actual, { rtol: 1e-5, atol: 1e-6 });
      return result.passed;
    },
  ]);

  tests.push([
    'bf16_to_f32',
    async () => {
      const floats = h.generateTestData(128, 1103);
      const bf16 = new Uint16Array(floats.length);
      const view = new DataView(new ArrayBuffer(4));
      for (let i = 0; i < floats.length; i++) {
        view.setFloat32(0, floats[i], true);
        bf16[i] = view.getUint32(0, true) >>> 16;
      }
      const expected = bf16ToF32Array(bf16);
      const actual = await h.runBF16ToF32(null, bf16);
      const result = h.compareArrays(expected, actual, { rtol: 1e-5, atol: 1e-6 });
      return result.passed;
    },
  ]);

  tests.push([
    'bf16_to_f16',
    async () => {
      const floats = h.generateTestData(128, 1104);
      const bf16 = new Uint16Array(floats.length);
      const view = new DataView(new ArrayBuffer(4));
      for (let i = 0; i < floats.length; i++) {
        view.setFloat32(0, floats[i], true);
        bf16[i] = view.getUint32(0, true) >>> 16;
      }
      const expected = bf16ToF16Array(bf16);
      const actual = await h.runBF16ToF16(null, bf16);
      return compareExact(expected, actual);
    },
  ]);

  tests.push([
    'bias_add',
    async () => {
      const numTokens = 4;
      const dim = 16;
      const data = h.generateTestData(numTokens * dim, 1201);
      const bias = h.generateTestData(dim, 1202);
      const expected = biasAddRef(data, bias, numTokens, dim);
      const actual = await h.runBiasAdd(null, data, bias, numTokens, dim);
      const result = h.compareArrays(expected, actual, h.KERNEL_TOLERANCES.residual);
      return result.passed;
    },
  ]);

  tests.push([
    'bias_add_f32_data_f16_bias',
    async () => {
      const numTokens = 4;
      const dim = 16;
      const data = h.generateTestData(numTokens * dim, 1206);
      const bias = h.generateTestData(dim, 1207);
      const roundedBias = h.toF16RoundedFloat32(bias);
      const expected = biasAddRef(data, roundedBias, numTokens, dim);
      const actual = await h.runBiasAdd(null, data, bias, numTokens, dim, {
        biasDtype: 'f16',
        biasWrapper: 'weight',
      });
      const result = h.compareArrays(expected, actual, h.KERNEL_TOLERANCES.residual);
      return result.passed;
    },
  ]);

  tests.push([
    'bias_add_glmocr_geometry',
    async () => {
      const numTokens = 1624;
      const dim = 1024;
      const data = h.generateTestData(numTokens * dim, 1208);
      const bias = h.generateTestData(dim, 1209);
      const roundedBias = h.toF16RoundedFloat32(bias);
      const expected = biasAddRef(data, roundedBias, numTokens, dim);
      const actual = await h.runBiasAdd(null, data, bias, numTokens, dim, {
        biasDtype: 'f16',
      });
      const result = h.compareArrays(expected, actual, h.KERNEL_TOLERANCES.residual);
      return result.passed;
    },
  ]);

  tests.push([
    'matmul_bias_glmocr_projection_geometry',
    async () => {
      const M = 1624;
      const N = 1024;
      const K = 1176;
      const data = new Float32Array(M * K);
      const weight = new Float32Array(N * K);
      const bias = h.generateTestData(N, 1210);
      const roundedBias = h.toF16RoundedFloat32(bias);
      const expected = new Float32Array(M * N);
      for (let row = 0; row < M; row++) {
        expected.set(roundedBias, row * N);
      }
      const actual = await h.runMatmulBias(null, data, weight, bias, M, N, K);
      const result = h.compareArrays(expected, actual, h.KERNEL_TOLERANCES.residual);
      return result.passed;
    },
  ]);

  tests.push([
    'scale',
    async () => {
      const input = h.generateTestData(256, 1203);
      const scale = 0.5;
      const expected = input.map((v) => v * scale);
      const actual = await h.runScale(null, input, scale);
      const result = h.compareArrays(expected, actual, h.KERNEL_TOLERANCES.residual);
      return result.passed;
    },
  ]);

  tests.push([
    'scale_backward',
    async () => {
      const input = h.generateTestData(256, 1204);
      const gradOutput = h.generateTestData(256, 1205);
      const scale = 0.75;
      const expected = scaleBackwardRef(gradOutput, scale);
      const actual = await h.runScaleBackward(null, input, gradOutput, scale);
      const result = h.compareArrays(expected, actual, { rtol: 1e-5, atol: 1e-6 });
      if (!result.passed) {
        console.error('[KernelTests] scale_backward mismatch', result);
      }
      return result.passed;
    },
  ]);

  tests.push([
    'softmax_backward',
    async () => {
      const rows = 4;
      const cols = 16;
      const logits = h.generateTestData(rows * cols, 1206);
      const softmax = h.softmax(logits, cols, rows, 1.0);
      const gradOutput = h.generateTestData(rows * cols, 1207);
      const expected = softmaxBackwardRef(softmax, gradOutput, rows, cols);
      const actual = await h.runSoftmaxBackward(null, softmax, gradOutput, rows, cols);
      const result = h.compareArrays(expected, actual, h.KERNEL_TOLERANCES.softmax);
      return result.passed;
    },
  ]);

  tests.push([
    'silu_backward',
    async () => {
      const input = h.generateTestData(512, 1208);
      const gradOutput = h.generateTestData(512, 1209);
      const expected = siluBackwardRef(input, gradOutput);
      const actual = await h.runSiluBackward(null, input, gradOutput);
      const result = h.compareArrays(expected, actual, h.KERNEL_TOLERANCES.silu);
      return result.passed;
    },
  ]);

  tests.push([
    'gelu_backward',
    async () => {
      const input = h.generateTestData(512, 1210);
      const gradOutput = h.generateTestData(512, 1211);
      const expected = geluBackwardRef(input, gradOutput);
      const actual = await h.runGeluBackward(null, input, gradOutput);
      const result = h.compareArrays(expected, actual, h.KERNEL_TOLERANCES.silu);
      return result.passed;
    },
  ]);

  tests.push([
    'rmsnorm_backward',
    async () => {
      const numTokens = 4;
      const hiddenSize = 16;
      const input = h.generateTestData(numTokens * hiddenSize, 1212);
      const weight = h.generateTestData(hiddenSize, 1213);
      const gradOutput = h.generateTestData(numTokens * hiddenSize, 1214);
      const expected = rmsNormBackwardRef(input, weight, gradOutput, numTokens, hiddenSize, 1e-6);
      const actual = await h.runRmsNormBackward(null, input, weight, gradOutput, numTokens, hiddenSize, 1e-6);
      const result = h.compareArrays(expected, actual, h.KERNEL_TOLERANCES.rmsnorm);
      return result.passed;
    },
  ]);

  tests.push([
    'rope_backward',
    async () => {
      const seqLen = 4;
      const numHeads = 2;
      const headDim = 8;
      const gradOutput = h.generateTestData(seqLen * numHeads * headDim, 1215);
      const { cos, sin } = h.references.computeRopeFreqs(headDim, seqLen);
      const expected = ropeBackwardRef(gradOutput, cos, sin, seqLen, numHeads, headDim, 0);
      const actual = await h.runRoPEBackward(null, gradOutput, cos, sin, seqLen, numHeads, headDim, 0);
      const result = h.compareArrays(expected, actual, h.KERNEL_TOLERANCES.rope);
      return result.passed;
    },
  ]);

  tests.push([
    'layernorm',
    async () => {
      const batchSize = 2;
      const hiddenSize = 16;
      const input = h.generateTestData(batchSize * hiddenSize, 1216);
      const weight = h.generateTestData(hiddenSize, 1217);
      const bias = h.generateTestData(hiddenSize, 1218);
      const expected = layerNormRef(input, weight, bias, batchSize, hiddenSize, 1e-5);
      const actual = await h.runLayerNorm(null, input, weight, bias, batchSize, hiddenSize, 1e-5);
      const result = h.compareArrays(expected, actual, h.KERNEL_TOLERANCES.rmsnorm);
      return result.passed;
    },
  ]);

  tests.push([
    'layernorm_f32_data_f16_params',
    async () => {
      const batchSize = 3;
      const hiddenSize = 16;
      const input = h.generateTestData(batchSize * hiddenSize, 1316);
      const weight = h.generateTestData(hiddenSize, 1317);
      const bias = h.generateTestData(hiddenSize, 1318);
      const roundedWeight = h.toF16RoundedFloat32(weight);
      const roundedBias = h.toF16RoundedFloat32(bias);
      const expected = layerNormRef(input, roundedWeight, roundedBias, batchSize, hiddenSize, 1e-5);
      const actual = await h.runLayerNorm(
        null,
        input,
        weight,
        bias,
        batchSize,
        hiddenSize,
        1e-5,
        { paramDtype: 'f16' }
      );
      const result = h.compareArrays(expected, actual, h.KERNEL_TOLERANCES.rmsnorm);
      if (!result.passed) {
        console.error('[KernelTests] layernorm f16 params mismatch', {
          result,
          expected: Array.from(expected.slice(0, 8)),
          actual: Array.from(actual.slice(0, 8)),
        });
      }
      return result.passed;
    },
  ]);

  tests.push([
    'layernorm_backward',
    async () => {
      const numTokens = 4;
      const hiddenSize = 16;
      const input = h.generateTestData(numTokens * hiddenSize, 1235);
      const weight = h.generateTestData(hiddenSize, 1236);
      const gradOutput = h.generateTestData(numTokens * hiddenSize, 1237);
      const expected = await h.runLayerNormBackward(null, input, weight, gradOutput, numTokens, hiddenSize, 1e-5);
      const actual = await h.runLayerNormBackward(null, input, weight, gradOutput, numTokens, hiddenSize, 1e-5);
      const result = h.compareArrays(expected, actual, h.KERNEL_TOLERANCES.rmsnorm);
      if (!result.passed) {
        console.error('[KernelTests] layernorm_backward mismatch', result);
      }
      return result.passed;
    },
  ]);

  tests.push([
    'groupnorm',
    async () => {
      const channels = 4;
      const height = 2;
      const width = 2;
      const numGroups = 2;
      const input = h.generateTestData(channels * height * width, 1219);
      const weight = h.generateTestData(channels, 1220);
      const bias = h.generateTestData(channels, 1221);
      const expected = groupNormRef(input, weight, bias, channels, height, width, numGroups, 1e-5);
      const actual = await h.runGroupNorm(null, input, weight, bias, channels, height, width, numGroups, 1e-5);
      const result = h.compareArrays(expected, actual, h.KERNEL_TOLERANCES.rmsnorm);
      return result.passed;
    },
  ]);

  tests.push([
    'groupnorm_stats',
    async () => {
      const channels = 4;
      const height = 2;
      const width = 2;
      const numGroups = 2;
      const input = h.generateTestData(channels * height * width, 1222);
      const weight = h.generateTestData(channels, 1223);
      const bias = h.generateTestData(channels, 1224);
      const actual = await h.runGroupNorm(null, input, weight, bias, channels, height, width, numGroups, 1e-5);
      return actual.length === channels * height * width && isFiniteArray(actual);
    },
  ]);

  tests.push([
    'modulate',
    async () => {
      const numTokens = 2;
      const hiddenSize = 8;
      const input = h.generateTestData(numTokens * hiddenSize, 1222);
      const mod = h.generateTestData(hiddenSize * 3, 1223);
      const options = { scaleOffset: 0, shiftOffset: hiddenSize, gateOffset: hiddenSize * 2, hasGate: true, addOne: true };
      const expected = modulateRef(input, mod, numTokens, hiddenSize, options);
      const actual = await h.runModulate(null, input, mod, numTokens, hiddenSize, options);
      const result = h.compareArrays(expected, actual, h.KERNEL_TOLERANCES.residual);
      return result.passed;
    },
  ]);

  tests.push([
    'conv2d',
    async () => {
      const options = {
        inChannels: 2,
        outChannels: 2,
        height: 3,
        width: 3,
        kernelH: 3,
        kernelW: 3,
        stride: 1,
        pad: 1,
      };
      const input = h.generateTestData(options.inChannels * options.height * options.width, 1224);
      const weight = h.generateTestData(options.outChannels * options.inChannels * options.kernelH * options.kernelW, 1225);
      const bias = h.generateTestData(options.outChannels, 1226);
      const expected = conv2dRef(input, weight, bias, options);
      const actual = await h.runConv2D(null, input, weight, bias, options);
      const result = h.compareArrays(expected, actual, h.KERNEL_TOLERANCES.residual);
      return result.passed;
    },
  ]);

  tests.push([
    'pixel_shuffle',
    async () => {
      const options = {
        outChannels: 1,
        gridWidth: 2,
        gridHeight: 2,
        patchSize: 2,
      };
      options.outHeight = options.gridHeight * options.patchSize;
      options.outWidth = options.gridWidth * options.patchSize;
      options.patchChannels = options.outChannels * options.patchSize * options.patchSize;
      const input = h.generateTestData(options.gridWidth * options.gridHeight * options.patchChannels, 1227);
      const expected = pixelShuffleRef(input, options);
      const actual = await h.runPixelShuffle(null, input, options);
      const result = h.compareArrays(expected, actual, h.KERNEL_TOLERANCES.residual);
      return result.passed;
    },
  ]);

  tests.push([
    'upsample2d',
    async () => {
      const options = {
        channels: 2,
        height: 2,
        width: 2,
        scale: 2,
      };
      options.outHeight = options.height * options.scale;
      options.outWidth = options.width * options.scale;
      const input = h.generateTestData(options.channels * options.height * options.width, 1228);
      const expected = upsample2dRef(input, options);
      const actual = await h.runUpsample2D(null, input, options);
      const result = h.compareArrays(expected, actual, h.KERNEL_TOLERANCES.residual);
      return result.passed;
    },
  ]);

  tests.push([
    'transpose',
    async () => {
      const rows = 4;
      const cols = 6;
      const input = h.generateTestData(rows * cols, 1229);
      const expected = transposeRef(input, rows, cols);
      const actual = await h.runTranspose(null, input, rows, cols);
      const result = h.compareArrays(expected, actual, h.KERNEL_TOLERANCES.residual);
      return result.passed;
    },
  ]);

  tests.push([
    'split_qkv',
    async () => {
      const numTokens = 2;
      const qSize = 4;
      const kSize = 4;
      const vSize = 4;
      const qkv = h.generateTestData(numTokens * (qSize + kSize + vSize), 1230);
      const expected = h.references.splitQkvRef(qkv, numTokens, qSize, kSize, vSize);
      const actual = await h.runSplitQKV(null, qkv, numTokens, qSize, kSize, vSize);
      const qPass = h.compareArrays(expected.Q, actual.Q, h.KERNEL_TOLERANCES.residual).passed;
      const kPass = h.compareArrays(expected.K, actual.K, h.KERNEL_TOLERANCES.residual).passed;
      const vPass = h.compareArrays(expected.V, actual.V, h.KERNEL_TOLERANCES.residual).passed;
      return qPass && kPass && vPass;
    },
  ]);

  tests.push([
    'vision_patch_embed',
    async () => {
      const geometry = {
        gridHeight: 2,
        gridWidth: 3,
        channels: 3,
        patchSize: 2,
        temporalPatchSize: 2,
        hiddenSize: 5,
      };
      const image = h.generateTestData(3 * 4 * 6, 12301);
      const weight = h.generateTestData(5 * 3 * 2 * 2 * 2, 12302);
      const bias = h.generateTestData(5, 12303);
      const expected = h.references.visionPatchEmbedRef(image, weight, bias, geometry);
      const actual = await h.runVisionPatchEmbed(null, image, weight, bias, geometry);
      return h.compareArrays(expected, actual, h.KERNEL_TOLERANCES.matmul).passed;
    },
  ]);

  tests.push([
    'vision_spatial_merge',
    async () => {
      const geometry = {
        gridHeight: 4,
        gridWidth: 6,
        hiddenSize: 5,
        mergeSize: 2,
        channelFirst: false,
        inputBlockMajor: false,
      };
      const input = h.generateTestData(4 * 6 * 5, 12304);
      const expected = h.references.visionSpatialMergeRef(input, geometry);
      const actual = await h.runVisionSpatialMerge(null, input, geometry);
      return h.compareArrays(expected, actual, h.KERNEL_TOLERANCES.residual).passed;
    },
  ]);

  tests.push([
    'vision_spatial_merge_channel_first',
    async () => {
      const geometry = {
        gridHeight: 4,
        gridWidth: 6,
        hiddenSize: 5,
        mergeSize: 2,
        channelFirst: true,
        inputBlockMajor: true,
      };
      const input = h.generateTestData(4 * 6 * 5, 123041);
      const expected = h.references.visionSpatialMergeRef(input, geometry);
      const actual = await h.runVisionSpatialMerge(null, input, geometry);
      return h.compareArrays(expected, actual, h.KERNEL_TOLERANCES.residual).passed;
    },
  ]);

  tests.push([
    'vision_average_pool',
    async () => {
      const geometry = { gridHeight: 4, gridWidth: 6, hiddenSize: 8, poolingSize: 2 };
      const input = h.generateTestData(4 * 6 * 8, 12305);
      const expected = h.references.visionAveragePoolRef(input, geometry);
      const actual = await h.runVisionAveragePool(null, input, geometry);
      return h.compareArrays(expected, actual, h.KERNEL_TOLERANCES.residual).passed;
    },
  ]);

  tests.push([
    'vision_position_embedding',
    async () => {
      const geometry = {
        gridHeight: 3,
        gridWidth: 4,
        positionEmbeddingSize: 6,
        hiddenSize: 8,
      };
      const table = h.generateTestData(2 * 6 * 8, 12306);
      const expected = h.references.visionPositionEmbeddingRef(table, geometry);
      const actual = await h.runVisionPositionEmbedding(null, table, geometry);
      return h.compareArrays(expected, actual, h.KERNEL_TOLERANCES.residual).passed;
    },
  ]);

  tests.push([
    'vision_rope_2d',
    async () => {
      const geometry = {
        numTokens: 12,
        numHeads: 2,
        headDim: 16,
        gridHeight: 3,
        gridWidth: 4,
        ropeTheta: 10000,
        spatialMergeSize: 1,
      };
      const input = h.generateTestData(12 * 2 * 16, 12307);
      const expected = h.references.visionRope2DRef(input, geometry);
      const actual = await h.runVisionRope2D(null, input, geometry);
      const result = h.compareArrays(expected, actual, h.KERNEL_TOLERANCES.vision_rope_2d);
      if (!result.passed) {
        console.error('[KernelTests] vision_rope_2d mismatch', JSON.stringify(result));
      }
      return result.passed;
    },
  ]);

  tests.push([
    'vision_rope_2d_block_major',
    async () => {
      const geometry = {
        numTokens: 24,
        numHeads: 2,
        headDim: 16,
        gridHeight: 4,
        gridWidth: 6,
        ropeTheta: 10000,
        spatialMergeSize: 2,
      };
      const input = h.generateTestData(24 * 2 * 16, 123071);
      const expected = h.references.visionRope2DRef(input, geometry);
      const actual = await h.runVisionRope2D(null, input, geometry);
      return h.compareArrays(expected, actual, h.KERNEL_TOLERANCES.vision_rope_2d).passed;
    },
  ]);

  tests.push([
    'swiglu',
    async () => {
      const size = 128;
      const gate = h.generateTestData(size, 1231);
      const up = h.generateTestData(size, 1232);
      const gateBias = h.generateTestData(size, 1233);
      const upBias = h.generateTestData(size, 1234);
      const expected = new Float32Array(size);
      for (let i = 0; i < size; i++) {
        const g = gate[i] + gateBias[i];
        const u = up[i] + upBias[i];
        const silu = g / (1 + Math.exp(-g));
        expected[i] = silu * u;
      }
      const actual = await h.runSwiGLU(null, gate, up, gateBias, upBias);
      const result = h.compareArrays(expected, actual, h.KERNEL_TOLERANCES.silu);
      return result.passed;
    },
  ]);

  tests.push([
    'fused_matmul_residual',
    async () => {
      const N = 16;
      const K = 8;
      const input = h.generateTestData(K, 1301);
      const weight = h.generateTestData(N * K, 1302);
      const residual = h.generateTestData(N, 1303);
      const expected = h.fusedMatmulResidualRef(input, weight, residual, N, K, 1.0);
      const actual = await h.runFusedMatmulResidual(null, input, weight, residual, N, K, 1.0);
      const result = h.compareArrays(expected, actual, h.KERNEL_TOLERANCES.residual);
      return result.passed;
    },
  ]);

  tests.push([
    'fused_matmul_rmsnorm',
    async () => {
      const N = 16;
      const K = 8;
      const input = h.generateTestData(K, 1304);
      const weight = h.generateTestData(N * K, 1305);
      const normWeight = h.generateTestData(N, 1306);
      const expected = h.fusedMatmulRMSNormRef(input, weight, normWeight, N, K, 1e-5, null);
      const actual = await h.runFusedMatmulRMSNorm(null, input, weight, normWeight, N, K, 1e-5, null);
      const result = h.compareArrays(expected, actual, h.KERNEL_TOLERANCES.rmsnorm);
      return result.passed;
    },
  ]);

  tests.push([
    'fused_ffn',
    async () => {
      const hiddenSize = 8;
      const intermediateSize = 16;
      const input = h.generateTestData(hiddenSize, 1307);
      const gateW = h.generateTestData(intermediateSize * hiddenSize, 1308);
      const upW = h.generateTestData(intermediateSize * hiddenSize, 1309);
      const expected = h.fusedFFNRef(input, gateW, upW, hiddenSize, intermediateSize, 'silu');
      const actual = await h.runFusedFFN(null, input, gateW, upW, hiddenSize, intermediateSize, 'silu');
      const result = h.compareArrays(expected, actual, h.KERNEL_TOLERANCES.silu);
      return result.passed;
    },
  ]);

  tests.push([
    'attention_tiered',
    async () => {
      const seqLen = 1;
      const kvLen = 4;
      const numHeads = 2;
      const numKVHeads = 1;
      const headDim = 8;
      const Q = h.generateTestData(seqLen * numHeads * headDim, 1404);
      const K = h.generateTestData(kvLen * numKVHeads * headDim, 1405);
      const V = h.generateTestData(kvLen * numKVHeads * headDim, 1406);
      const qF16 = f32ArrayToF16(Q);
      const kF16 = f32ArrayToF16(K);
      const vF16 = f32ArrayToF16(V);
      const qRounded = new Float32Array(qF16.length);
      const kRounded = new Float32Array(kF16.length);
      const vRounded = new Float32Array(vF16.length);
      for (let i = 0; i < qF16.length; i++) qRounded[i] = f16ToF32(qF16[i]);
      for (let i = 0; i < kF16.length; i++) kRounded[i] = f16ToF32(kF16[i]);
      for (let i = 0; i < vF16.length; i++) vRounded[i] = f16ToF32(vF16[i]);
      const expected = h.toF16RoundedFloat32(
        h.references.attentionRef(qRounded, kRounded, vRounded, seqLen, kvLen, numHeads, numKVHeads, headDim, null)
      );
      const actual = await h.runAttentionTiered(null, Q, K, V, seqLen, kvLen, numHeads, numKVHeads, headDim);
      const tieredTolerance = { rtol: 1e-3, atol: 1e-4 };
      const result = h.compareArrays(expected, actual, tieredTolerance);
      if (!result.passed) {
        console.error('[KernelTests] attention_tiered mismatch', result);
      }
      return result.passed;
    },
  ]);

  tests.push([
    'attention_tiered_quant',
    async () => {
      const seqLen = 1;
      const kvLen = 4;
      const numHeads = 2;
      const numKVHeads = 1;
      const headDim = 8;
      const Q = h.generateTestData(seqLen * numHeads * headDim, 1407);
      const K = h.generateTestData(kvLen * numKVHeads * headDim, 1408);
      const V = h.generateTestData(kvLen * numKVHeads * headDim, 1409);
      const kF16 = f32ArrayToF16(K);
      const vF16 = f32ArrayToF16(V);
      const kRounded = new Float32Array(kF16.length);
      const vRounded = new Float32Array(vF16.length);
      for (let i = 0; i < kF16.length; i++) kRounded[i] = f16ToF32(kF16[i]);
      for (let i = 0; i < vF16.length; i++) vRounded[i] = f16ToF32(vF16[i]);
      const expected = h.references.attentionRef(Q, kRounded, vRounded, seqLen, kvLen, numHeads, numKVHeads, headDim, null);
      const actual = await h.runAttentionTieredQuant(null, Q, K, V, seqLen, kvLen, numHeads, numKVHeads, headDim);
      const result = h.compareArrays(expected, actual, h.KERNEL_TOLERANCES.attention);
      return result.passed;
    },
  ]);

  tests.push([
    'cross_entropy_loss',
    async () => {
      const numTokens = 4;
      const vocabSize = 16;
      const logits = h.generateTestData(numTokens * vocabSize, 1501);
      const softmax = h.softmax(logits, vocabSize, numTokens, 1.0);
      const targets = generateUint32(numTokens, vocabSize, 1502);
      const expected = crossEntropyLossRef(softmax, targets, numTokens, vocabSize);
      const actual = await h.runCrossEntropyLoss(null, softmax, targets, numTokens, vocabSize);
      const result = h.compareArrays(expected, actual, h.KERNEL_TOLERANCES.residual);
      return result.passed;
    },
  ]);

  tests.push([
    'cross_entropy_backward',
    async () => {
      const numTokens = 4;
      const vocabSize = 16;
      const logits = h.generateTestData(numTokens * vocabSize, 1503);
      const softmax = h.softmax(logits, vocabSize, numTokens, 1.0);
      const targets = generateUint32(numTokens, vocabSize, 1504);
      const gradOutput = h.generateTestData(numTokens, 1505);
      const expected = crossEntropyBackwardRef(softmax, targets, gradOutput, numTokens, vocabSize);
      const actual = await h.runCrossEntropyBackward(null, softmax, targets, gradOutput, numTokens, vocabSize);
      const result = h.compareArrays(expected, actual, h.KERNEL_TOLERANCES.residual);
      return result.passed;
    },
  ]);

  tests.push([
    'kv_quantize_smoke',
    async () => {
      const numKVHeads = 1;
      const headDim = 4;
      const numTokens = 1;
      const keyVals = h.generateTestData(numKVHeads * numTokens * headDim, 1601);
      const valVals = h.generateTestData(numKVHeads * numTokens * headDim, 1602);
      const keys = f32ArrayToF16(keyVals);
      const values = f32ArrayToF16(valVals);
      const result = await h.runKVQuantize(null, keys, values, numKVHeads, headDim, numTokens, 'int8');
      return result.outputK.length > 0 && result.scalesK.length > 0;
    },
  ]);

  tests.push([
    'argmax',
    async () => {
      const logits = h.generateTestData(64, 1701);
      const expected = h.references.argmaxRef(logits);
      const actual = await h.runArgmax(null, logits);
      return expected === actual;
    },
  ]);

  tests.push([
    'sample_topk_smoke',
    async () => {
      const logits = h.generateTestData(64, 1702);
      const temperature = 1.0;
      const topK = 4;
      const randomValue = h.references.seededRandom(42);
      const actual = await h.runSampleTopK(null, logits, temperature, topK, randomValue);
      return Number.isFinite(actual) && actual >= 0 && actual < logits.length;
    },
  ]);

  tests.push([
    'check_stop',
    async () => {
      const eosTokenId = 2;
      const maxTokens = 5;
      const case1 = await h.runCheckStop(null, 1, eosTokenId, maxTokens, 3);
      const case2 = await h.runCheckStop(null, 2, eosTokenId, maxTokens, 3);
      const case3 = await h.runCheckStop(null, 1, eosTokenId, maxTokens, 5);
      return case1 === false && case2 === true && case3 === true;
    },
  ]);

  tests.push([
    'embed_backward',
    async () => {
      const numTokens = 4;
      const hiddenSize = 16;
      const vocabSize = 8;
      const input = generateUint32(numTokens, vocabSize, 1801);
      const gradOutput = h.generateTestData(numTokens * hiddenSize, 1802);
      const expected = h.references.embedBackwardRef(input, gradOutput, numTokens, hiddenSize, vocabSize);
      const actual = await h.runEmbedBackward(null, input, gradOutput, vocabSize);
      const result = h.compareArrays(expected, actual, { rtol: 1e-5, atol: 1e-6 });
      if (!result.passed) {
        console.error('[KernelTests] embed_backward mismatch', result);
      }
      return result.passed;
    },
  ]);

  tests.push([
    'attention_backward_smoke',
    async () => {
      const seqLen = 2;
      const numHeads = 1;
      const headDim = 4;
      const scale = 1 / Math.sqrt(headDim);
      const q = h.generateTestData(seqLen * numHeads * headDim, 1803);
      const k = h.generateTestData(seqLen * numHeads * headDim, 1804);
      const v = h.generateTestData(seqLen * numHeads * headDim, 1805);
      const softmax = new Float32Array(numHeads * seqLen * seqLen);
      for (let hIdx = 0; hIdx < numHeads; hIdx++) {
        for (let i = 0; i < seqLen; i++) {
          let maxVal = -Infinity;
          for (let j = 0; j < seqLen; j++) {
            let score = 0;
            for (let d = 0; d < headDim; d++) {
              const qIdx = (i * numHeads + hIdx) * headDim + d;
              const kIdx = (j * numHeads + hIdx) * headDim + d;
              score += q[qIdx] * k[kIdx];
            }
            score *= scale;
            const idx = (hIdx * seqLen + i) * seqLen + j;
            softmax[idx] = score;
            maxVal = Math.max(maxVal, score);
          }
          let sum = 0;
          for (let j = 0; j < seqLen; j++) {
            const idx = (hIdx * seqLen + i) * seqLen + j;
            const val = Math.exp(softmax[idx] - maxVal);
            softmax[idx] = val;
            sum += val;
          }
          for (let j = 0; j < seqLen; j++) {
            const idx = (hIdx * seqLen + i) * seqLen + j;
            softmax[idx] /= sum;
          }
        }
      }
      const gradOutput = h.generateTestData(seqLen * numHeads * headDim, 1806);
      const result = await h.runAttentionBackward(null, q, k, v, softmax, gradOutput, seqLen, numHeads, headDim, scale);
      return result && isFiniteArray(result.gradQ) && isFiniteArray(result.gradK) && isFiniteArray(result.gradV);
    },
  ]);

  tests.push([
    'adam',
    async () => {
      const count = 32;
      const params = h.generateTestData(count, 1901);
      const grads = h.generateTestData(count, 1902);
      const moment1 = h.generateTestData(count, 1903);
      const moment2 = h.generateTestData(count, 1904);
      const options = {
        count,
        step: 2,
        lr: 0.001,
        beta1: 0.9,
        beta2: 0.999,
        eps: 1e-8,
        weightDecay: 0.01,
      };
      const expected = adamRef(params, grads, moment1, moment2, options);
      const actual = await h.runAdam(null, params, grads, moment1, moment2, options);
      const pPass = h.compareArrays(expected.params, actual.params, h.KERNEL_TOLERANCES.residual).passed;
      const m1Pass = h.compareArrays(expected.moment1, actual.moment1, h.KERNEL_TOLERANCES.residual).passed;
      const m2Pass = h.compareArrays(expected.moment2, actual.moment2, h.KERNEL_TOLERANCES.residual).passed;
      return pPass && m1Pass && m2Pass;
    },
  ]);

  const results = [];
  for (const [name, fn] of tests) {
    const start = performance.now();
    try {
      const passed = await fn();
      results.push({ name, passed, duration: Math.round(performance.now() - start) });
    } catch (error) {
      if (isUnsupportedCapabilityError(error)) {
        console.warn(`[KernelTests] ${name} skipped: ${error.message || String(error)}`);
        results.push({ name, passed: false, skipped: true, duration: Math.round(performance.now() - start) });
        continue;
      }
      console.error(`[KernelTests] ${name} failed:`, error);
      results.push({ name, passed: false, duration: Math.round(performance.now() - start) });
    }
  }

  return results;
}
