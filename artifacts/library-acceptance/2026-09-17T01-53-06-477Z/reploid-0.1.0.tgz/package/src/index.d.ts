import type { Json, ResolvedConfig } from './config/index.js';
import type { Store } from './artifacts/store.js';
import type { ResponseParserInstance } from './agent/response-parser.js';
export { createAgentRuntime } from './agent/runtime.js';
export { createToolRunner } from './agent/tool-runner.js';
export { default as ResponseParser } from './agent/response-parser.js';
export { default as AgentLoop } from './agent/legacy-loop.js';

export interface Message { role: string; content: string; origin?: string }
export interface GenerationResult { content?: string; raw?: string; model?: string | null; provider?: string | null; evidence?: unknown }
export interface Control { signal?: AbortSignal }
export interface GenerationProvider { generate(messages: Message[], onUpdate?: ((chunk: string) => void) | null, control?: Control): Promise<GenerationResult> }
export interface Closable { close(): void | Promise<void> }
export type Authorize = (request: Record<string, unknown>) => boolean | Promise<boolean>;
export interface AgentPorts {
  initialContext(request: { goal: string; environment: string; swarmEnabled: boolean; signal: AbortSignal }): Promise<Message[]>;
  generate: GenerationProvider['generate'];
  executeTool(name: string, args: Record<string, unknown>, control?: Control): Promise<unknown> | unknown;
  getModelLabel(): string;
  getModelConfig(): unknown;
  authorize?: Authorize;
  initialize?(control?: Control): Promise<unknown>;
  on?(event: string, listener: (value: unknown) => void): (() => void) | void;
  listToolNames?(): string[];
  getSwarmSnapshot?(): unknown;
  hasAvailableProvider?(): boolean;
  writeRuntimeArtifact?(path: string, content: string): Promise<unknown>;
  getAnchorObservations?(request: Record<string, unknown>): Promise<unknown[]>;
  rotateIdentity?(input?: object): Promise<unknown>;
}
export interface AgentSnapshot {
  instanceId: string; status: string; running: boolean; goal: string | null; context: Message[];
  [field: string]: unknown;
}
export interface ReploidPorts {
  instanceId: string; authorize: Authorize; agent?: AgentPorts; responseParser?: ResponseParserInstance;
  providers?: Record<string, GenerationProvider>; mesh?: GenerationProvider & { connect(): Promise<unknown>; describe?(): unknown };
  tools?: Record<string, (args: Record<string, unknown>, control?: Control) => unknown | Promise<unknown>>;
  initialContext?: AgentPorts['initialContext']; stores?: Record<string, Store>; crypto?: Crypto; owned?: Closable[];
}
export interface ReploidInstance extends Closable {
  readonly config: ResolvedConfig; readonly instanceId: string;
  prepare(request: { goal: string; environment?: string }): AgentSnapshot;
  execute(request: { goal: string; environment?: string }): Promise<AgentSnapshot>;
  connect(): Promise<unknown>;
  on(event: string, listener: (value: unknown) => void): () => void;
  subscribe(listener: (snapshot: AgentSnapshot) => void): () => void;
  getSnapshot(): AgentSnapshot; cancel(): void;
  checkpoint(): Promise<Json>; restore(checkpoint: Json): Promise<AgentSnapshot>;
  close(): Promise<void>;
}
export function createReploid(options: { config: ResolvedConfig; ports: ReploidPorts }): ReploidInstance;

export { CYCLE_ARTIFACT_ROOT, getCycleId, getCycleArtifactPath, createCycleArtifactWriter } from './agent/cycle-artifacts.js';
