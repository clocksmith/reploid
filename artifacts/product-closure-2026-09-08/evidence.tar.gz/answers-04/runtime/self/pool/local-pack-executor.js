import { dopplerExecutionAdapterSet } from './adapter-execution.js';
import { assertPackSession, hashDopplerEvidence } from './executable-pack.js';
import { validateOperationModel } from './operation-model.js';
import { assertPackOperationRequest, runPackOperation, snapshotPackOperationData } from './pack-operation.js';
import { DopplerRuntimeService } from '../infrastructure/doppler-runtime-service.js';
import { prepareLocalPackRelease } from './pack-release-policy.js';
import { createPackOperationRegistry } from './pack-operation-adapters.js';
import { resolveDopplerExecutionContract } from '../config/doppler-execution-contracts.js';
import defaultSessionPolicy from './local-session-policy.json' with { type: 'json' };

/** Application-selected sessions do not admit a model to the public peer catalog.
 * Remote callers must validate delegation before supplying an assignment. */
export function createLocalPackExecutor({ service = DopplerRuntimeService, scope = `reploid:documents:${crypto.randomUUID()}`,
  prepareRelease = prepareLocalPackRelease, registry = createPackOperationRegistry(), sessionPolicy = defaultSessionPolicy } = {}) {
  sessionPolicy = snapshotPackOperationData(sessionPolicy);
  if (sessionPolicy.schema !== 'reploid.local-session-policy/v1'
    || ['maxSessions', 'maxReservedBytes', 'artifactBytesMultiplier', 'workingBytesPerSession']
      .some(key => !Number.isSafeInteger(sessionPolicy[key]) || sessionPolicy[key] < 1)) {
    throw new Error('Explicit bounded local session policy required');
  }
  let disposed = false;
  let active = false;
  let epoch = 0;
  let controller = null;
  let settlement = Promise.resolve();
  let retained = null;
  const sessions = new Map();
  const ownedScopes = new Set();
  let reservedBytes = 0;
  let lastModelKey = null;
  let releasing = false;
  const metrics = { preparations: 0, loadAttempts: 0, modelLoads: 0, modelReuses: 0, modelSwitches: 0,
    sessionEvictions: 0, peakReservedBytes: 0,
    completedOperations: 0, failedOperations: 0, prepareMs: 0, loadMs: 0, releaseMs: 0, executionMs: 0 };
  const measure = async (field, operation) => {
    const started = performance.now();
    try { return await operation(); } finally { metrics[field] += performance.now() - started; }
  };
  const releaseScope = async (key) => {
    releasing = true;
    try {
      await measure('releaseMs', () => service.close(key));
      ownedScopes.delete(key);
      for (const [modelKey, entry] of sessions) {
        if (entry.scope !== key) continue;
        sessions.delete(modelKey);
        reservedBytes -= entry.reservedBytes;
        if (retained === entry) retained = null;
      }
    }
    catch (error) { disposed = true; throw error; }
    finally { releasing = false; }
  };
  const releaseSession = async () => {
    // Attempt every close even when one session fails; failed ownership is retained.
    const errors = [];
    for (const key of ownedScopes) {
      try { await releaseScope(key); } catch (error) { errors.push(error); }
    }
    if (errors.length) throw new AggregateError(errors, 'Document session cleanup failed');
    retained = null;
    lastModelKey = null;
  };
  return {
    async run({ model: modelInput, input, options = {}, assignment = null, limits, signal = null, onPartial = null, beforeExecute = null, adapterSet = [], adapterArtifactStore = null, assertAdaptersCurrent = null }) {
      if (disposed || active) throw new Error(disposed ? 'Document executor is closed' : 'A document operation is already running');
      const model = snapshotPackOperationData(modelInput);
      const validation = validateOperationModel(model, registry);
      if (!validation.ok) throw new Error(validation.reasons.join('; '));
      if (typeof model.runtimeVersion !== 'string' || !model.runtimeVersion) throw new Error('Exact runtime version required');
      const source = new URL(model.packSource);
      if (!['https:', 'http:'].includes(source.protocol) || source.username || source.password) throw new Error('Pack source must be an HTTP(S) URL without credentials');
      if (!model.packOpenOptions?.trustedSigners || !Object.keys(model.packOpenOptions.trustedSigners).length) throw new Error('Application-selected trusted signers required');
      const contract = resolveDopplerExecutionContract(model.executablePack.schema);
      const request = snapshotPackOperationData({ schema: contract.requestSchema,
        operation: { name: model.executablePack.requiredOperation, version: registry[model.executablePack.requiredOperation].version }, input, options,
        assignment, limits, ...(adapterSet.length ? { adapterSet: dopplerExecutionAdapterSet(snapshotPackOperationData(adapterSet), model) } : {}) });
      assertPackOperationRequest(model.executablePack, request, registry);
      const remaining = limits?.deadlineAt - Date.now();
      if (!Number.isSafeInteger(limits?.deadlineAt) || remaining <= 0 || remaining > 2147483647) throw new Error('Document operation requires a future bounded deadline');
      const currentEpoch = ++epoch;
      active = true;
      controller = new AbortController();
      const localController = controller;
      const timer = setTimeout(() => localController.abort(new Error('Document operation deadline exceeded')), remaining);
      const abort = () => localController.abort(signal.reason);
      signal?.addEventListener('abort', abort, { once: true });
      if (signal?.aborted) abort();
      const assertCurrent = () => {
        localController.signal.throwIfAborted();
        if (Date.now() >= limits.deadlineAt) throw new Error('Document operation deadline exceeded');
        if (disposed || currentEpoch !== epoch) throw new Error('Document operation is no longer current');
        if (retained) releasePolicy?.checkTime?.(retained.session);
      };
      let releasePolicy;
      let rejectCancellation;
      const cancelled = new Promise((_resolve, reject) => { rejectCancellation = reject; });
      const onCancel = () => rejectCancellation(localController.signal.reason || new Error('Document operation cancelled'));
      localController.signal.addEventListener('abort', onCancel, { once: true });
      if (localController.signal.aborted) onCancel();
      const operation = (async () => {
        let execution;
        let completed = false;
        try {
          assertCurrent();
          const modelKey = await hashDopplerEvidence(model);
          assertCurrent();
          if (lastModelKey && lastModelKey !== modelKey) metrics.modelSwitches++;
          retained = sessions.get(modelKey) ?? null;
          const artifactBytes = model.executablePack.artifacts.reduce((sum, artifact) => {
            if (!Number.isSafeInteger(artifact.sizeBytes) || artifact.sizeBytes < 0) throw new Error('Invalid model artifact size');
            return sum + artifact.sizeBytes;
          }, 0);
          const reservation = artifactBytes * sessionPolicy.artifactBytesMultiplier + sessionPolicy.workingBytesPerSession;
          if (!Number.isSafeInteger(reservation) || reservation > sessionPolicy.maxReservedBytes) {
            throw new Error('Model exceeds the local session memory reservation budget');
          }
          assertCurrent();
          metrics.preparations++;
          const prepared = await measure('prepareMs', () => service.prepare(null, { bindingSchema: model.executablePack.schema }));
          assertCurrent();
          if (prepared.version !== model.runtimeVersion) throw new Error('Document Pack requires a different Doppler release');
          releasePolicy = await prepareRelease({ model });
          assertCurrent();
          if (!retained) {
            while (sessions.size >= sessionPolicy.maxSessions || reservedBytes + reservation > sessionPolicy.maxReservedBytes) {
              await releaseScope(sessions.values().next().value.scope);
              metrics.sessionEvictions++;
              assertCurrent();
            }
            const sessionScope = `${scope}:${modelKey}`;
            ownedScopes.add(sessionScope);
            if (typeof service[contract.openMethod] !== 'function') throw new Error(`Doppler service requires ${contract.openMethod}`);
            metrics.loadAttempts++;
            const session = await measure('loadMs', () => service[contract.openMethod]({ scope: sessionScope, source: source.href,
              options: { ...releasePolicy.options, acceptedTargetPlanDigests: model.executablePack.acceptedTargetPlanDigests } }));
            metrics.modelLoads++;
            retained = { session, modelKey, modelId: model.modelId, scope: sessionScope, reservedBytes: reservation };
            sessions.set(modelKey, retained);
            reservedBytes += reservation;
            metrics.peakReservedBytes = Math.max(metrics.peakReservedBytes, reservedBytes);
          } else metrics.modelReuses++;
          // Map order is the last successful selection order, used for idle eviction.
          sessions.delete(modelKey);
          sessions.set(modelKey, retained);
          lastModelKey = modelKey;
          const { session } = retained;
          assertCurrent();
          await assertPackSession(model.executablePack, session);
          if (session.modelId !== model.modelId) throw new Error('Loaded Pack model id mismatch');
          await releasePolicy.assertCurrent(session);
          execution = await measure('executionMs', () => runPackOperation({ binding: model.executablePack, session, request,
            runtimeVersion: model.runtimeVersion, signal: localController.signal, adapterArtifactStore, onPartial, beforeExecute,
            assertCurrent: async () => { assertCurrent(); await assertAdaptersCurrent?.(); assertCurrent(); }, registry }));
          assertCurrent();
          await releasePolicy.assertCurrent(session);
          assertCurrent();
          completed = true;
          metrics.completedOperations++;
        } finally {
          if (!completed) metrics.failedOperations++;
          try { if (!completed) await releaseSession(); } finally {
            try { releasePolicy?.close(); } finally {
              signal?.removeEventListener('abort', abort);
              active = false;
              controller = null;
            }
          }
        }
        assertCurrent();
        return execution;
      })();
      settlement = operation.catch(() => null);
      // Return cancellation/deadline promptly, while retaining the physical
      // execution slot until the underlying runtime and its cleanup settle.
      return Promise.race([operation, cancelled]).finally(() => {
        clearTimeout(timer);
        localController.signal.removeEventListener('abort', onCancel);
      });
    },
    getState() { return { active, draining: active && (controller?.signal.aborted === true || disposed || releasing),
      disposed, retainedModelId: retained?.modelId ?? null,
      sessions: [...sessions.values()].map(entry => ({ modelId: entry.modelId, modelKey: entry.modelKey, reservedBytes: entry.reservedBytes })),
      memory: { reservedBytes, maxReservedBytes: sessionPolicy.maxReservedBytes,
        basis: 'artifact bytes times configured multiplier plus per-session working reservation; not measured GPU or process memory' },
      metrics: { ...metrics } }; },
    cancel() {
      ++epoch;
      if (controller) controller.abort(new Error('Document operation cancelled'));
      else if (!active && ownedScopes.size) {
        active = true;
        settlement = releaseSession().finally(() => { active = false; });
        // A failed release poisons this executor. It may never reuse that scope.
        settlement.catch(() => {});
      }
    },
    async close() {
      disposed = true;
      ++epoch;
      controller?.abort(new Error('Document executor closed'));
      await settlement;
      await releaseSession();
    }
  };
}
