"""Paired prompt development with the verified upstream checkpoint; no training."""
import hashlib
import json
import platform
import sys
import time
from pathlib import Path
import torch
import transformers
from transformers import AutoModelForCausalLM, AutoTokenizer, GenerationConfig

root = Path(__file__).resolve().parent
source = Path('/tmp/reploid-answer-source.I0UxsH')
experiment_path = Path(sys.argv[1]) if len(sys.argv) > 1 else root / 'experiment.json'
experiment_bytes = experiment_path.read_bytes()
experiment = json.loads(experiment_bytes)
sha = lambda value: 'sha256:' + hashlib.sha256(value).hexdigest()
report_path = experiment_path.with_name(experiment.get('resultFile', 'results.json'))
assert not report_path.exists(), 'Do not overwrite an existing observation'
report = {
    'schema': 'reploid.document-answer-prompt-development-result/v1',
    'experimentDigest': sha(experiment_bytes), 'complete': False,
    'semanticSupportQualified': False, 'sourceFiles': [], 'cases': [],
    'engine': {'torch': torch.__version__, 'transformers': transformers.__version__,
               'python': platform.python_version(), 'device': 'cpu', 'dtype': 'float32',
               'attention': 'eager', 'threads': 4, 'seed': 0},
}
def retain():
    report_path.write_text(json.dumps(report, indent=2) + '\n')
try:
    assert torch.__version__ == '2.11.0+cpu' and transformers.__version__ == '5.6.2'
    for line in (source / 'verification.jsonl').read_text().splitlines():
        expected = json.loads(line)
        path = source / expected['path']
        with path.open('rb') as stream:
            actual = 'sha256:' + hashlib.file_digest(stream, 'sha256').hexdigest()
        assert actual == expected['sha256'] and path.stat().st_size == expected['bytes']
        report['sourceFiles'].append(expected)
    assert sha((root / experiment.get('candidateFile', 'candidate.js')).read_bytes()) == experiment['candidateDigest']
    assert sha((root / 'baseline.js').read_bytes()) == experiment['baselineDigest']
    assert sha((root / 'development.json').read_bytes()) == experiment['corpusDigest']
    torch.set_num_threads(4)
    torch.manual_seed(0)
    torch.use_deterministic_algorithms(True)
    tokenizer = AutoTokenizer.from_pretrained(source, local_files_only=True, trust_remote_code=False)
    model = AutoModelForCausalLM.from_pretrained(source, local_files_only=True, trust_remote_code=False,
        dtype=torch.float32, attn_implementation='eager').eval()
    source_generation = json.loads((source / 'generation_config.json').read_text())
    config = GenerationConfig(do_sample=False, max_new_tokens=experiment['options']['maxTokens'],
        repetition_penalty=experiment['options']['repetitionPenalty'], use_cache=True,
        bos_token_id=source_generation['bos_token_id'], pad_token_id=source_generation['pad_token_id'],
        eos_token_id=source_generation['eos_token_id'])
    for row in experiment['rows']:
        began = time.monotonic()
        formatted = tokenizer.apply_chat_template([{'role': 'user', 'content': row['prompt']}],
            tokenize=False, add_generation_prompt=True, enable_thinking=False)
        token_ids = tokenizer(formatted, add_special_tokens=False, return_tensors='pt')['input_ids']
        assert token_ids.shape[1] + config.max_new_tokens <= experiment['options']['maxSeqLen']
        with torch.inference_mode():
            generated = model.generate(input_ids=token_ids, attention_mask=torch.ones_like(token_ids),
                generation_config=config)[0, token_ids.shape[1]:].tolist()
        observation = {'id': row['id'], 'arm': row['arm'], 'promptDigest': sha(row['prompt'].encode()),
            'promptTokenIds': token_ids[0].tolist(), 'tokenIds': generated,
            'output': tokenizer.decode(generated, skip_special_tokens=True),
            'elapsedSeconds': time.monotonic() - began}
        report['cases'].append(observation)
        retain()
        print(json.dumps({key: observation[key] for key in ['id', 'arm', 'output', 'elapsedSeconds']}), flush=True)
    report['complete'] = True
except Exception as error:
    report['error'] = {'type': type(error).__name__, 'message': str(error)}
    raise
finally:
    retain()
