import { readFile, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { buildDocumentAnswerPrompt as baseline } from '/home/clocksmith/deco/reploid/self/pool/document-answer.js';
import { buildDocumentAnswerPrompt as candidate } from './candidate.js';
const root = new URL('./', import.meta.url);
const digest = bytes => 'sha256:' + createHash('sha256').update(bytes).digest('hex');
const read = async path => JSON.parse(await readFile(path, 'utf8'));
const corpusBytes = await readFile(new URL('development.json', root));
const corpus = JSON.parse(corpusBytes);
const policy = await read('/home/clocksmith/deco/reploid/self/pool/document-search-policy.json');
const config = await read('/tmp/reploid-answer-source.I0UxsH/evaluation-config.json');
const baselineBytes = await readFile('/home/clocksmith/deco/reploid/self/pool/document-answer.js');
const candidateBytes = await readFile(new URL('candidate.js', root));
const experiment = {
  schema: 'reploid.document-answer-prompt-development/v1',
  frozenAt: new Date().toISOString(), corpusDigest: digest(corpusBytes),
  baselineDigest: digest(baselineBytes), candidateDigest: digest(candidateBytes),
  hypothesis: 'Explicit independent examples improve grounded completeness, conflict reporting, and abstention without introducing unsupported claims.',
  selectionRule: 'Review every sentence against cited actual passages. Require all eight cases to satisfy unchanged corpus acceptance and case expectations before any held-out browser evaluation. Do not select on citation syntax alone. No product promotion on development results.',
  boundary: 'Same operator, CPU source screening, no independent qualification, no training, no held-out results.',
  options: config.generationOptions,
  rows: corpus.cases.flatMap(entry => ['baseline', 'candidate'].map(arm => ({
    id: entry.id, arm, question: entry.question, passages: entry.passages, review: entry.review,
    prompt: (arm === 'baseline' ? baseline : candidate)({ question: entry.question, passages: entry.passages,
      abstention: policy.answerAbstention, unknown: policy.answerUnknown }),
  }))),
};
await writeFile(new URL('baseline.js', root), baselineBytes, { flag: 'wx' });
await writeFile(new URL('experiment.json', root), JSON.stringify(experiment, null, 2) + '\n', { flag: 'wx' });
console.log(JSON.stringify({ corpusDigest: experiment.corpusDigest, candidateDigest: experiment.candidateDigest, rows: experiment.rows.length }));
