import { readFile, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { buildDocumentAnswerPrompt } from './concise.js';
const root = new URL('./', import.meta.url);
const read = async path => JSON.parse(await readFile(path, 'utf8'));
const original = await read(new URL('experiment.json', root));
const policy = await read('/home/clocksmith/deco/reploid/self/pool/document-search-policy.json');
const corpus = await read(new URL('development.json', root));
const candidate = await readFile(new URL('concise.js', root));
const experiment = {
  ...original, frozenAt: new Date().toISOString(), candidateFile: 'concise.js', resultFile: 'concise-results.json',
  candidateDigest: 'sha256:' + createHash('sha256').update(candidate).digest('hex'),
  hypothesis: 'Removing redundant instructions and examples reduces omitted answers and unsupported additions on the same development cohort.',
  boundary: 'Second development candidate after failed few-shot screening. Reuses exposed development cases, not a holdout. No promotion authority.',
  rows: corpus.cases.map(entry => ({ id: entry.id, arm: 'concise', question: entry.question,
    passages: entry.passages, review: entry.review, prompt: buildDocumentAnswerPrompt({
      question: entry.question, passages: entry.passages, abstention: policy.answerAbstention, unknown: policy.answerUnknown }),
  })),
};
await writeFile(new URL('concise-experiment.json', root), JSON.stringify(experiment, null, 2) + '\n', { flag: 'wx' });
console.log(JSON.stringify({ candidateDigest: experiment.candidateDigest, cases: experiment.rows.length }));
