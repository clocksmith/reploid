"""CPU source diagnostic for the already-exposed document-answer cases; no training."""
import hashlib
import json
import platform
import time
from pathlib import Path

import torch
import transformers
from transformers import AutoModelForCausalLM, AutoTokenizer, GenerationConfig

root = Path(__file__).resolve().parent
inputs_bytes = (root / 'source-inputs.json').read_bytes()
inputs = json.loads(inputs_bytes)
assert inputs['executionDigest'] == 'sha256:ece0d5eab6481d09a0ab1f4a4aa2f86e7041a60353877b4f05d8e2757c4d2cd5'
assert torch.__version__ == '2.11.0+cpu'
assert transformers.__version__ == '5.6.2'
output = root / 'source-reference-02'
output.mkdir()
sha = lambda data: 'sha256:' + hashlib.sha256(data).hexdigest()
report = {
    'schema': 'reploid.document-answer-source-diagnostic/v1',
    'hypothesis': 'The source model reproduces the observed consent error under identical tokenized inputs.',
    'inputDigest': sha(inputs_bytes), 'executionDigest': inputs['executionDigest'],
    'engine': {'torch': torch.__version__, 'transformers': transformers.__version__,
               'python': platform.python_version(), 'device': 'cpu', 'dtype': 'float32',
               'attention': 'eager', 'threads': 4, 'seed': 0},
    'sourceFiles': [], 'cases': [], 'complete': False, 'semanticSupportQualified': False,
    'boundary': 'Independent reference implementation, same operator; exposed diagnostic cases, not held-out qualification.'
}

def retain():
    (output / 'reference.json').write_text(json.dumps(report, indent=2) + '\n')

try:
    for line in (root / 'verification.jsonl').read_text().splitlines():
        expected = json.loads(line)
        path = root / expected['path']
        with path.open('rb') as stream:
            digest = 'sha256:' + hashlib.file_digest(stream, 'sha256').hexdigest()
        assert digest == expected['sha256'] and path.stat().st_size == expected['bytes']
        report['sourceFiles'].append(expected)
    torch.set_num_threads(report['engine']['threads'])
    torch.manual_seed(report['engine']['seed'])
    torch.use_deterministic_algorithms(True)
    tokenizer = AutoTokenizer.from_pretrained(root, local_files_only=True, trust_remote_code=False)
    for row in inputs['rows']:
        formatted = tokenizer.apply_chat_template([{'role': 'user', 'content': row['prompt']}],
            tokenize=False, add_generation_prompt=True, enable_thinking=False)
        assert formatted == row['formatted'], f"Chat template mismatch: {row['id']}"
        ids = tokenizer(formatted, add_special_tokens=False)['input_ids']
        assert ids == row['tokenIds'], f"Tokenization mismatch: {row['id']}"
    report['tokenizationMatchedCases'] = len(inputs['rows'])
    retain()
    print(json.dumps({'phase': 'tokenization', 'matchedCases': len(inputs['rows'])}), flush=True)
    model = AutoModelForCausalLM.from_pretrained(root, local_files_only=True, trust_remote_code=False,
        dtype=torch.float32, attn_implementation='eager').eval()
    source_generation = json.loads((root / 'generation_config.json').read_text())
    eos = source_generation['eos_token_id']
    eos_ids = eos if isinstance(eos, list) else [eos]
    for row in inputs['rows']:
        began = time.monotonic()
        observation = {'id': row['id'], 'promptTokenIds': row['tokenIds'], 'boundaries': {}}
        hooks = []
        def capture(name):
            def hook(module, args, result):
                if name in observation['boundaries']:
                    return
                value = result[0] if isinstance(result, tuple) else result
                value = value.detach().float().cpu().contiguous()
                last = value[0, -1].reshape(-1)
                observation['boundaries'][name] = {
                    'shape': list(value.shape), 'lastTokenSamples': last[:16].tolist(),
                    'lastTokenDigest': sha(last.numpy().tobytes()),
                    'finite': bool(torch.isfinite(value).all()),
                }
            return hook
        hooks.append(model.model.embed_tokens.register_forward_hook(capture('embeddings')))
        hooks.append(model.model.layers[0].input_layernorm.register_forward_hook(capture('layer0-input-norm')))
        token_ids = torch.tensor([row['tokenIds']], dtype=torch.long)
        try:
            with torch.inference_mode():
                first = model(input_ids=token_ids, attention_mask=torch.ones_like(token_ids),
                    use_cache=False, logits_to_keep=1).logits[0, -1].float()
                values, indices = torch.topk(first, 8)
                observation['firstLogits'] = {'ids': indices.tolist(), 'values': values.tolist(),
                    'digest': sha(first.numpy().tobytes())}
                config = GenerationConfig(do_sample=False, max_new_tokens=row['options']['maxTokens'],
                    repetition_penalty=row['options']['repetitionPenalty'], use_cache=True,
                    bos_token_id=source_generation['bos_token_id'],
                    pad_token_id=source_generation['pad_token_id'], eos_token_id=eos)
                generated = model.generate(input_ids=token_ids, attention_mask=torch.ones_like(token_ids),
                    generation_config=config)[0, token_ids.shape[1]:].tolist()
            # Both runtimes retain EOS in token IDs; decode text with special tokens omitted.
            visible = generated[:-1] if generated and generated[-1] in eos_ids else generated
            text = tokenizer.decode(visible, skip_special_tokens=True)
            observation.update({'rawGeneratedTokenIds': generated, 'visibleTokenIds': visible,
                'output': text, 'exactTokens': generated == row['observedTokenIds'],
                'exactText': text == row['observedOutput'],
                'elapsedSeconds': time.monotonic() - began})
            report['cases'].append(observation)
            retain()
            print(json.dumps({'id': row['id'], 'exactTokens': observation['exactTokens'],
                'exactText': observation['exactText'], 'output': text}), flush=True)
        finally:
            for hook in hooks:
                hook.remove()
    report['complete'] = True
except Exception as error:
    report['error'] = {'type': type(error).__name__, 'message': str(error)}
    raise
finally:
    retain()
