import fs from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { formatChatMessages } from '/home/clocksmith/deco/reploid/node_modules/doppler-gpu/src/inference/pipelines/text/chat-format.js';
import { Tokenizer } from '/home/clocksmith/deco/reploid/node_modules/doppler-gpu/src/inference/tokenizer.js';

const root = '/tmp/reploid-answer-source.I0UxsH';
const bytes = await fs.readFile(`${root}/answers-linux-01/execution.json`);
const execution = JSON.parse(bytes);
const manifest = JSON.parse(await fs.readFile(`${root}/capsule/artifacts/model/manifest.json`));
const tokenizer = new Tokenizer();
await tokenizer.initialize(manifest, {
  loadTokenizerJson: async () => JSON.parse(await fs.readFile(`${root}/converted/tokenizer.json`)),
});
const rows = execution.cases.map(row => {
  const formatted = formatChatMessages([{ role: 'user', content: row.input.prompt }], manifest.inference.chatTemplate.type);
  return { id: row.id, prompt: row.input.prompt, formatted, tokenIds: tokenizer.encode(formatted),
    observedTokenIds: row.tokenIds, observedOutput: row.output, options: row.options };
});
const report = { executionDigest: `sha256:${createHash('sha256').update(bytes).digest('hex')}`,
  runtimeVersion: execution.runtime.version, tokenizerTiming: tokenizer.getLoadTiming(), rows };
await fs.writeFile(`${root}/source-inputs.json`, JSON.stringify(report, null, 2) + '\n', { flag: 'wx' });
console.log(JSON.stringify({ cases: rows.length, promptTokens: rows.map(row => row.tokenIds.length) }));
