import { readFile, writeFile, mkdir } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { pathToFileURL } from 'node:url';
import path from 'node:path';
import assert from 'node:assert/strict';
const read = async file => JSON.parse(await readFile(file, 'utf8'));
if (process.argv.length !== 3) throw new Error('Usage: node replay-installed.mjs /absolute/replay-config.json');
const settings = await read(path.resolve(process.argv[2]));
for (const field of ['runtimeRoot', 'playwrightModule', 'outputDirectory', 'capsuleDirectory', 'adapterDir',
  'referencePath', 'openOptionsPath', 'runtimePackageReceiptPath', 'runtimeFileVerificationPath', 'chromium']) {
  assert(typeof settings[field] === 'string' && path.isAbsolute(settings[field]), `Absolute ${field} required`);
}
const verifiedFiles = await read(settings.runtimeFileVerificationPath);
assert.equal(verifiedFiles.passed, true);
for (const file of verifiedFiles.files) {
  const bytes = await readFile(path.join(settings.runtimeRoot, file.path));
  assert.equal(bytes.length, file.sizeBytes, file.path);
  assert.equal(createHash('sha256').update(bytes).digest('hex'), file.sha256, file.path);
}
const { chromium } = await import(pathToFileURL(settings.playwrightModule).href);
const { createStaticFileServer } = await import(pathToFileURL(path.join(settings.runtimeRoot,
  'src/tooling/node-browser-command-runner.js')).href);
const directory = settings.outputDirectory;
await mkdir(directory); // Retain each attempt separately; never overwrite an earlier report.
const reference = await read(settings.referencePath);
const openOptions = await read(settings.openOptionsPath);
const report = { schema: 'reploid.signed-adapter-operation-qualification/v1', passed: false,
  boundary: { physicalGpu: true, sourceTokenComparison: true, signedCapsule: true, publicExecuteOperation: true,
    publishedRuntime: false, sourceTreeRuntime: false, cleanPackageInstall: true, independentMachines: false, operatorCount: 1,
    peerTransport: false, durableProviderReplay: false, specialistQuality: false },
  phases: [], logs: [], requests: [] };
report.runtimePackage = await read(settings.runtimePackageReceiptPath);
report.replayConfiguration = settings;
let server, browser, timer;
try {
  server = await createStaticFileServer({ rootDir: settings.runtimeRoot, host: '127.0.0.1', port: 0,
    staticMounts: [{ urlPrefix: '/capsule', rootDir: settings.capsuleDirectory },
      { urlPrefix: '/adapter', rootDir: settings.adapterDir }] });
  browser = await chromium.launch({ executablePath: settings.chromium, headless: true, args: settings.launchArgs });
  timer = setTimeout(() => { report.timeout = true; void browser.close(); }, settings.timeoutMs);
  const page = await browser.newPage();
  await page.exposeFunction('retainPhase', async phase => {
    report.phases.push(phase);
    await writeFile(`${directory}/operation-progress.json`, JSON.stringify(report, null, 2));
  });
  page.on('console', message => report.logs.push({ type: message.type(), text: message.text() }));
  await page.route('**/*', route => {
    const url = new URL(route.request().url()); report.requests.push(url.href);
    if (url.origin !== server.baseUrl || route.request().method() !== 'GET') return route.abort();
    if (url.pathname === '/diagnostic') return route.fulfill({ contentType: 'text/html', body: '<!doctype html><title>Signed adapter operation qualification</title>' });
    return route.continue();
  });
  await page.goto(`${server.baseUrl}/diagnostic`);
  report.raw = await page.evaluate(async ({ settings, reference, openOptions }) => {
    const gpu = navigator.gpu;
    globalThis.qualificationGPU = gpu;
    const adapter = await gpu.requestAdapter();
    if (!adapter || adapter.info.vendor !== settings.requiredVendor || (adapter.isFallbackAdapter ?? adapter.info.isFallbackAdapter) !== false) throw new Error('Required physical GPU unavailable');
    const { openCapsule } = await import('/src/client/capsule-host.browser.js');
    const { getCapsuleIdentity } = await import('/src/config/capsule.js');
    const { hashCapsuleObservation } = await import('/src/config/capsule-operation.js');
    const { CAPSULE_OPERATIONS } = await import('/src/config/capsule-operation.js');
    const capsule = await (await fetch('/capsule/capsule.json')).json();
    const identity = getCapsuleIdentity(capsule);
    const manifest = reference.adapter.manifest;
    const adapterBytes = new Uint8Array(await (await fetch(`/adapter/${manifest.weightsPath}`)).arrayBuffer());
    const entry = { schema: 'doppler.capsule-adapter/v1', identity: hashCapsuleObservation({ manifest, qualification: reference.policy }),
      baseModel: { modelId: capsule.modelId, semanticRoot: identity.semanticRoot, envelopeDigest: identity.envelopeDigest,
        artifactClosureDigest: identity.artifactClosureDigest }, format: 'peft_safetensors', manifest,
      artifact: { artifactId: manifest.id, role: 'lora-weights', path: manifest.weightsPath,
        hash: `sha256:${manifest.checksum}`, sizeBytes: manifest.weightsSize } };
    let reads = 0, session;
    const store = { async readArtifact(artifact) {
      if (hashCapsuleObservation(artifact) !== hashCapsuleObservation(entry.artifact)) throw new Error('Adapter store cannot supply base-model bytes');
      reads++; return adapterBytes.slice();
    } };
    const options = Object.fromEntries(Object.entries(settings.generation).filter(([key]) => CAPSULE_OPERATIONS.generate.optionFields.includes(key)));
    const request = (prompt, adapterSet) => ({ schema: 'doppler.capsule-operation-request/v1', operation: { name: 'generate', version: 1 },
      input: { prompt }, options, adapterSet, assignment: { jobId: crypto.randomUUID(), attemptNumber: 1 },
      limits: { maxInputBytes: 65536, maxOutputBytes: 1048576, deadlineAt: Date.now() + 120000 } });
    const collect = async (input, control = {}) => {
      const events = [];
      for await (const event of session.executeOperation(input, { adapterArtifactStore: store, ...control })) events.push(event);
      if (events.at(-1)?.status !== 'completed') throw new Error('Missing final completion');
      return { request: input, events, completion: events.at(-1) };
    };
    const checks = [], outputs = [];
    const rejects = async (name, action, pattern) => {
      try { await action(); } catch (error) {
        if (!pattern.test(error.message)) throw error;
        checks.push({ name, passed: true, error: error.message }); return;
      }
      throw new Error(`${name} was not rejected`);
    };
    try {
      const started = performance.now();
      session = await openCapsule(`${location.origin}/capsule/capsule.json`, { ...openOptions, requiredOperation: 'generate', loadTimeoutMs: 180000 });
      await window.retainPhase({ stage: 'opened', elapsedMs: performance.now() - started, identity,
        selectedTargetPlanDigest: session.selectedTargetPlanDigest });
      const invalid = structuredClone(entry); invalid.baseModel.semanticRoot = `sha256:${'0'.repeat(64)}`;
      await rejects('wrong-base', () => collect(request(reference.policy.evaluationPrompts[0], [invalid])), /base model mismatch/);
      const corrupt = adapterBytes.slice(); corrupt[corrupt.length - 1] ^= 1;
      await rejects('corrupt-adapter', () => collect(request(reference.policy.evaluationPrompts[0], [entry]),
        { adapterArtifactStore: { async readArtifact() { return corrupt; } } }), /corruption/);
      for (const mode of ['adapted', 'unloaded']) {
        for (const [index, prompt] of reference.policy.evaluationPrompts.entries()) {
          const start = performance.now();
          const result = await collect(request(prompt, mode === 'adapted' ? [entry] : []));
          const expected = (mode === 'adapted' ? reference.adaptedOutputs : reference.baseOutputs)[index];
          if (JSON.stringify(result.completion.output.tokenIds) !== JSON.stringify(expected.generatedTokenIds)) throw new Error(`${mode} ${index} source token mismatch`);
          if (mode === 'adapted' && result.completion.receipt.adapterReceipts?.[0]?.sourceDigest !== entry.artifact.hash) throw new Error('Adapter receipt does not bind the supplied bytes');
          outputs.push({ mode, index, elapsedMs: performance.now() - start, ...result });
          await window.retainPhase({ stage: 'completed', mode, index, elapsedMs: performance.now() - start, completion: result.completion });
        }
      }
      const controller = new AbortController(), cancelledEvents = [];
      await rejects('cancel-stream', async () => {
        for await (const event of session.executeOperation(request(reference.policy.evaluationPrompts[0], [entry]), { adapterArtifactStore: store, signal: controller.signal })) {
          cancelledEvents.push(event); controller.abort(new Error('qualification cancellation'));
        }
      }, /qualification cancellation/);
      if (cancelledEvents.some(event => event.status === 'completed')) throw new Error('Cancelled operation completed');
      const recovery = await collect(request(reference.policy.evaluationPrompts[0], []));
      if (JSON.stringify(recovery.completion.output.tokenIds) !== JSON.stringify(reference.baseOutputs[0].generatedTokenIds)) throw new Error('Cancellation left an adapter active');
      checks.push({ name: 'post-cancel-base-recovery', passed: true });
      return { identity, entry, outputs, checks, cancelledEvents, recovery, adapterReads: reads,
        gpu: { vendor: adapter.info.vendor, description: adapter.info.description } };
    } finally { await session?.close(); }
  }, { settings, reference, openOptions });
  assert.equal(report.raw.outputs.length, 6); assert.equal(report.raw.checks.length, 4);
  report.passed = true;
} catch (error) { report.error = { name: error.name, message: error.message, stack: error.stack }; }
finally {
  clearTimeout(timer); await browser?.close(); await server?.close();
  await writeFile(`${directory}/operation-report.json`, JSON.stringify(report, null, 2));
}
console.log(JSON.stringify({ passed: report.passed, error: report.error, checks: report.raw?.checks, outputs: report.raw?.outputs.map(row => ({ mode: row.mode, index: row.index, text: row.completion.output.text })) }));
if (!report.passed) process.exitCode = 1;
