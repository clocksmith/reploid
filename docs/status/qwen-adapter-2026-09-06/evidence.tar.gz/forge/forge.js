import fs from 'node:fs/promises';
import path from 'node:path';
import assert from 'node:assert/strict';
import { createHash, generateKeyPairSync } from 'node:crypto';
import { writeProgramBundle } from '/tmp/doppler-peft-runtime-layout/src/tooling/program-bundle.js';
import { forgeModelCapsule } from '/tmp/doppler-peft-runtime-layout/src/tooling/model-capsule-forge.js';
import { buildSourceParity } from '/tmp/doppler-peft-runtime-layout/tools/run-program-bundle-reference.js';
import { assertRerankerObservedShaderClosure } from '/tmp/doppler-peft-runtime-layout/tools/build-reranker-evaluation-capsule.js';
import { computeCanonicalSha256 } from '/tmp/doppler-peft-runtime-layout/src/formats/canonical-hash.js';
import { getCapsuleIdentity } from '/tmp/doppler-peft-runtime-layout/src/config/capsule.js';
import { hashTargetPlan } from '/tmp/doppler-peft-runtime-layout/src/config/target-plan.js';
const root = '/tmp/doppler-peft-runtime-layout';
const evidence = '/tmp/reploid-qwen-adapter-fixed-01';
const directory = `${evidence}/capsule`;
const read = async file => JSON.parse(await fs.readFile(file, 'utf8'));
const hashFile = async file => `sha256:${createHash('sha256').update(await fs.readFile(file)).digest('hex')}`;
const reference = await read(`${evidence}/source-reference.json`);
const diagnosticPath = `${evidence}/browser-report.json`;
const diagnostic = await read(diagnosticPath);
assert.equal(diagnostic.passed, true);
assert.equal(diagnostic.comparison.length, 9);
for (const { mode, rows } of diagnostic.raw.outputs) {
  const expected = mode === 'adapted' ? reference.adaptedOutputs : reference.baseOutputs;
  for (const [index, row] of rows.entries()) {
    assert.deepEqual(row.promptTokenIds, expected[index].promptTokenIds);
    assert.deepEqual(row.result.tokenIds, expected[index].generatedTokenIds);
    assert.equal(row.result.outputText, expected[index].text);
  }
}
await fs.mkdir(directory);
const write = (file, value, options = {}) => fs.writeFile(path.join(directory, file), JSON.stringify(value, null, 2) + '\n', { flag: 'wx', ...options });
const first = diagnostic.raw.outputs[0].rows[0];
const expected = { model: reference.source.repository, revision: reference.source.revision,
  execution: { sampling: 'greedy' }, promptTokenIds: reference.baseOutputs[0].promptTokenIds,
  generatedTokenIds: reference.baseOutputs[0].generatedTokenIds, generatedTokens: reference.baseOutputs[0].generatedTokenIds.length };
await write('source-transcript.json', expected);
const expectedPath = path.join(directory, 'source-transcript.json');
const report = { schema: 'doppler.document-generation-qualification/v1', modelId: diagnostic.raw.manifest.modelId,
  passed: true, output: first.result.outputText, env: { runtime: 'browser-webgpu' },
  initialExecutionIdentity: diagnostic.raw.initialExecutionIdentity,
  evidence: { observation: { path: diagnosticPath, hash: await hashFile(diagnosticPath) },
    sourceReference: { path: `${evidence}/source-reference.json`, hash: await hashFile(`${evidence}/source-reference.json`) },
    comparisons: diagnostic.comparison, physicalGpu: diagnostic.raw.gpu,
    boundary: 'One internal operator and host. Three fixed prompts per mode establish sampled source-token parity, not specialist quality or independent adoption.' },
  results: [{ name: 'generation', passed: true }],
  metrics: { prompt: reference.baseOutputs[0].prompt, tokensGenerated: first.result.tokenIds.length,
    referenceTranscript: { surface: 'browser-webgpu', executionGraphHash: diagnostic.raw.initialExecutionIdentity.executionGraphHash,
      prompt: { ids: first.promptTokenIds }, tokens: { ids: first.result.tokenIds },
      generationConfig: first.result.generationConfig,
      output: { tokensGenerated: first.result.tokenIds.length, stopReason: first.result.stats.stopReason,
        stopTokenId: first.result.stats.stopTokenId } } } };
report.metrics.sourceParity = buildSourceParity(report, { json: expected, path: expectedPath, hash: await hashFile(expectedPath) });
assert.equal(report.metrics.sourceParity.status, 'passed');
await write('qualification.json', report);
const manifestPath = `${diagnostic.config.modelDir}/manifest.json`;
const conversionConfigPath = '/tmp/reploid-qwen-adapter-proof/conversion.json';
const referenceReportPath = path.join(directory, 'qualification.json');
const bundle = await writeProgramBundle({ repoRoot: root, manifestPath, modelDir: path.dirname(manifestPath),
  conversionConfigPath, referenceReportPath, createdAtUtc: new Date().toISOString(), outputPath: path.join(directory, 'build/program-bundle.json') });
const observedShaderClosure = assertRerankerObservedShaderClosure(diagnostic, bundle.bundle.wgslModules);
const manifest = await read(manifestPath);
const targetId = `webgpu-${manifest.inference.session.compute.defaults.activationDtype}-${manifest.inference.session.kvcache.kvDtype}-${bundle.bundle.wgslModules.some(row => row.metadata.requiresSubgroups) ? 'subgroups' : 'portable'}`;
const authorityId = 'reploid-adapter-integration-evaluation-2026-09';
const applicationDigest = await hashFile(`${evidence}/qualify-browser.js`);
const application = { applicationId: 'reploid-adapter-integration-evaluation', applicationRevision: applicationDigest,
  applicationRevisionDigest: applicationDigest, workload: { id: 'frozen-qwen-adapter-integration', digest: computeCanonicalSha256(reference.policy) },
  oracle: { id: 'pinned-hf-peft-source-token-comparison', digest: await hashFile(`${evidence}/source-reference.json`) } };
const revocation = { authorityId, offlineExpirySeconds: 86400, failClosedAfterExpiry: true };
const licensePath = `${reference.policy.sourceDirectory}/LICENSE`;
const release = { schema: 'doppler.capsule-release/v1',
  source: { repository: reference.source.repository, revision: reference.source.revision,
    revisionDigest: computeCanonicalSha256(reference.source.files), provenanceDigest: computeCanonicalSha256(reference.source),
    license: { spdxId: 'Apache-2.0', name: 'Apache License 2.0', sourceUrl: 'https://www.apache.org/licenses/LICENSE-2.0.txt', textDigest: await hashFile(licensePath) } },
  application, exclusions: { rejectionTypes: ['acceptance-failed','application-gate-failed','artifact-invalid','evidence-expired','migration-required','revoked','unsupported-device'],
    known: [{ code: 'unsupported-device', scope: 'outside-observed-chromium-amd', reason: 'One internal source comparison; other hardware and operators are unestablished.', evidenceDigest: await hashFile(referenceReportPath) }] },
  lifecycle: { releaseVersion: '1.0.0', supersedes: null, migration: null, failedUpgrade: { preservePrevious: true, previousCapsuleId: null, previousSemanticRoot: null } },
  revocation: { ...revocation, policyDigest: computeCanonicalSha256(revocation) },
  stateSnapshot: { schema: 'doppler.capsule-state-snapshot/v1', format: 'canonical-json', identityDigest: computeCanonicalSha256({ application, state: 'stateless-generation' }), portableAcrossTargetIds: [targetId] } };
await write('release.json', release);
await fs.mkdir(path.join(directory, 'custody'), { mode: 0o700 });
const keys = generateKeyPairSync('ed25519');
await write('custody/private-key.json', keys.privateKey.export({ format: 'jwk' }), { mode: 0o600 });
const publicKey = keys.publicKey.export({ format: 'jwk' });
await write('custody/public-key.json', publicKey);
const config = { repoRoot: root, manifestPath, modelDir: path.dirname(manifestPath), programBundlePath: bundle.outputPath,
  referenceReportPath, releaseManifestPath: path.join(directory, 'release.json'), initialExecutionIdentityPath: referenceReportPath,
  adapterExecution: diagnostic.config.adapterExecution,
  outputPath: path.join(directory, 'distribution/capsule.json'), signingPrivateKeyPath: path.join(directory, 'custody/private-key.json'),
  signingPublicKeyPath: path.join(directory, 'custody/public-key.json'), signingAuthority: authorityId, allowDevelopmentSigner: false };
await write('forge-config.json', config);
const result = await forgeModelCapsule(config);
const capsule = await read(config.outputPath);
await fs.copyFile(licensePath, path.join(directory, 'distribution/MODEL_LICENSE.txt'));
await write('open-options.json', { trustedSigners: { [authorityId]: publicKey }, acceptedTargetPlanDigests: capsule.targetPlans.map(hashTargetPlan) });
await write('build-receipt.json', { result, capsuleIdentity: getCapsuleIdentity(capsule), application, observedShaderClosure,
  evidenceClass: 'internal-source-token-qualified-capsule-build', physicalCapsuleExecution: false, externalAdoption: false });
console.log(JSON.stringify({ capsuleIdentity: getCapsuleIdentity(capsule), artifacts: capsule.artifacts.length }));
