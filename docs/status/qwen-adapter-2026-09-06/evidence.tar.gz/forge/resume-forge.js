import fs from 'node:fs/promises';
import { forgeModelCapsule } from '/tmp/doppler-peft-runtime-layout/src/tooling/model-capsule-forge.js';
import { getCapsuleIdentity } from '/tmp/doppler-peft-runtime-layout/src/config/capsule.js';
import { hashTargetPlan } from '/tmp/doppler-peft-runtime-layout/src/config/target-plan.js';
import { assertRerankerObservedShaderClosure } from '/tmp/doppler-peft-runtime-layout/tools/build-reranker-evaluation-capsule.js';
const base = '/tmp/reploid-qwen-adapter-fixed-01';
const read = async file => JSON.parse(await fs.readFile(file, 'utf8'));
const config = await read(`${base}/capsule/forge-config.json`);
const result = await forgeModelCapsule(config);
const capsule = await read(config.outputPath);
const reference = await read(`${base}/source-reference.json`);
await fs.copyFile(`${reference.policy.sourceDirectory}/LICENSE`, `${base}/capsule/distribution/MODEL_LICENSE.txt`);
await fs.writeFile(`${base}/capsule/open-options.json`, JSON.stringify({
  trustedSigners: { [config.signingAuthority]: await read(config.signingPublicKeyPath) },
  acceptedTargetPlanDigests: capsule.targetPlans.map(hashTargetPlan) }, null, 2));
await fs.writeFile(`${base}/capsule/build-receipt.json`, JSON.stringify({ result, capsuleIdentity: getCapsuleIdentity(capsule),
  application: capsule.release.application,
  observedShaderClosure: assertRerankerObservedShaderClosure(await read(`${base}/browser-report.json`),
    (await read(config.programBundlePath)).wgslModules),
  evidenceClass: 'internal-source-token-qualified-capsule-build', physicalCapsuleExecution: false, externalAdoption: false }, null, 2));
console.log(JSON.stringify({ capsuleIdentity: getCapsuleIdentity(capsule), artifacts: capsule.artifacts.length }));
