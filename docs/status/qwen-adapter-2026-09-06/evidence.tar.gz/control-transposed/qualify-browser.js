import { chromium } from '/home/x/deco/reploid/node_modules/@playwright/test/index.mjs';
import { readFile, writeFile } from 'node:fs/promises';
import assert from 'node:assert/strict';
const directory = '/tmp/reploid-qwen-adapter-native-control';
const read = async name => JSON.parse(await readFile(`${directory}/${name}`, 'utf8'));
const settings = await read('browser-config.json');
const reference = await read('source-reference.json');
const { createStaticFileServer } = await import(`${settings.runtimeRoot}/src/tooling/node-browser-command-runner.js`);
const report = { schema: 'reploid.adapter-browser-qualification/v1', passed: false,
  boundary: { physicalGpu: true, sourceTokenComparison: true, signedCapsule: false,
    publishedRuntime: false, cleanPackageInstall: true, operatorCount: 1, independentMachines: false, specialistQuality: false },
  config: settings, phases: [], logs: [], requests: [] };
let server, browser, timer;
try {
  server = await createStaticFileServer({ rootDir: settings.runtimeRoot, host: '127.0.0.1', port: 0,
    staticMounts: [{ urlPrefix: '/model', rootDir: settings.modelDir }, { urlPrefix: '/adapter', rootDir: settings.adapterDir }] });
  browser = await chromium.launch({ executablePath: settings.chromium, headless: true, args: settings.launchArgs });
  timer = setTimeout(() => { report.timeout = true; void browser.close(); }, settings.timeoutMs);
  const page = await browser.newPage();
  await page.exposeFunction('retainPhase', async phase => {
    report.phases.push(phase);
    await writeFile(`${directory}/browser-progress.json`, JSON.stringify(report, null, 2));
  });
  page.on('console', message => report.logs.push({ type: message.type(), text: message.text() }));
  await page.route('**/*', route => {
    const url = new URL(route.request().url());
    report.requests.push(url.href);
    if (url.origin !== server.baseUrl || route.request().method() !== 'GET') return route.abort();
    if (url.pathname === '/diagnostic') return route.fulfill({ contentType: 'text/html', body: '<!doctype html><title>Adapter source qualification</title>' });
    return route.continue();
  });
  await page.goto(`${server.baseUrl}/diagnostic`);
  report.raw = await page.evaluate(async ({ settings, reference }) => {
    const adapter = await navigator.gpu.requestAdapter();
    if (adapter.info.vendor !== settings.requiredVendor || (adapter.isFallbackAdapter ?? adapter.info.isFallbackAdapter) !== false) throw new Error('Required physical GPU unavailable');
    const api = await import('/src/client/doppler-api.browser.js');
    const { observeInitialExecutionIdentity } = await import('/src/config/initial-execution-identity.js');
    const started = performance.now();
    let model;
    try {
      model = await api.load({ url: `${location.origin}/model/` }, { runtimeConfig: settings.runtimeConfig });
      const initialExecutionIdentity = observeInitialExecutionIdentity(model.advanced.getResolvedRuntimeSession());
      await window.retainPhase({ stage: 'loaded', elapsedMs: performance.now() - started, initialExecutionIdentity });
      const outputs = [];
      for (const mode of ['base', 'adapted', 'unloaded']) {
        if (mode === 'adapted') {
          const manifest = reference.adapter.manifest;
          const bytes = await (await fetch(`/adapter/${manifest.weightsPath}`)).arrayBuffer();
          const read = async path => { if (path !== manifest.weightsPath) throw new Error('Undeclared adapter bytes'); return bytes; };
          await model.loadLoRA(manifest, { readFile: read, readOPFS: read, fetchUrl: read, skipVerify: false });
          if (!model.activeLoRAIdentity?.digest) throw new Error('Adapter activation identity missing');
        }
        if (mode === 'unloaded') {
          await model.unloadLoRA();
          if (model.activeLoRAIdentity !== null) throw new Error('Adapter did not unload');
        }
        const rows = [];
        for (const [index, prompt] of reference.policy.evaluationPrompts.entries()) {
          await model.resetGenerationState();
          const start = performance.now();
          const result = await model.generateWithEvidence(prompt, settings.generation);
          const row = { index, mode, elapsedMs: performance.now() - start,
            promptTokenIds: model.advanced.tokenizePrompt(prompt, { useChatTemplate: true }), result,
            activeAdapterIdentity: model.activeLoRAIdentity };
          rows.push(row);
          await window.retainPhase({ stage: 'generated', ...row });
        }
        outputs.push({ mode, rows });
      }
      return { outputs, initialExecutionIdentity, manifest: model.manifest,
        gpu: { vendor: adapter.info.vendor, description: adapter.info.description }, elapsedMs: performance.now() - started };
    } finally { await model?.unload(); }
  }, { settings, reference });
  report.comparison = report.raw.outputs.flatMap(({ mode, rows }) => rows.map((row, index) => {
    const expected = (mode === 'adapted' ? reference.adaptedOutputs : reference.baseOutputs)[index];
    return { mode, index, promptEqual: JSON.stringify(row.promptTokenIds) === JSON.stringify(expected.promptTokenIds),
      tokensEqual: JSON.stringify(row.result.tokenIds) === JSON.stringify(expected.generatedTokenIds),
      observedTokens: row.result.tokenIds, expectedTokens: expected.generatedTokenIds,
      text: row.result.outputText, expectedText: expected.text };
  }));
  assert(report.comparison.every(row => row.promptEqual && row.tokensEqual), 'Source token comparison failed');
  report.passed = true;
} catch (error) { report.error = { name: error.name, message: error.message, stack: error.stack }; }
finally {
  clearTimeout(timer);
  await browser?.close(); await server?.close();
  await writeFile(`${directory}/browser-report.json`, JSON.stringify(report, null, 2) + '\n');
}
console.log(JSON.stringify({ passed: report.passed, error: report.error, comparison: report.comparison }));
if (!report.passed) process.exitCode = 1;
