import fs from 'node:fs/promises';
import path from 'node:path';
import assert from 'node:assert/strict';
import { computeCanonicalSha256, hashBytesSha256 } from '/home/x/deco/doppler/src/formats/canonical-hash.js';
const directory = '/tmp/reploid-qwen-adapter-proof';
const source = '/tmp/qwen-generation-f16-candidate-02';
const read = async file => JSON.parse(await fs.readFile(file, 'utf8'));
const write = (file, data) => fs.writeFile(`${directory}/${file}`, JSON.stringify(data, null, 2) + '\n', { flag: 'wx' });
const reference = await read(`${directory}/source-reference.json`);
assert.equal(reference.complete, true);
const recipe = await read('/tmp/reploid-capsule-lora-physical/candidate-recipe.json');
const conversion = await read('/home/x/deco/doppler/reports/document-assistant/qwen-generation-f16-closure-conversion.json');
const manifest = await read(`${source}/manifest.json`);
Object.assign(conversion.execution.kernels, recipe.declaredAdapterKernels);
conversion.execution.mechanismKernels = [...new Set([...(conversion.execution.mechanismKernels ?? []), ...Object.keys(recipe.declaredAdapterKernels)])];
manifest.inference.execution = structuredClone(conversion.execution);
const conversionPath = `${directory}/conversion.json`;
manifest.artifactIdentity.conversionConfigPath = conversionPath;
manifest.artifactIdentity.conversionConfigDigest = computeCanonicalSha256(conversion);
await write('conversion.json', conversion);
await fs.mkdir(`${directory}/model`);
await write('model/manifest.json', manifest);
const weights = [];
for (const entry of await fs.readdir(source, { withFileTypes: true })) {
  if (entry.name === 'manifest.json' || !entry.isFile()) continue;
  const input = path.join(source, entry.name);
  await fs.symlink(input, `${directory}/model/${entry.name}`);
  const bytes = await fs.readFile(input);
  weights.push({ path: entry.name, bytes: bytes.length, sha256: hashBytesSha256(bytes) });
}
await write('unchanged-artifacts.json', { source, files: weights });
const settings = await read('/home/x/deco/doppler/reports/document-assistant/generation-browser-diagnostic-08-config.json');
await write('browser-config.json', { schema: 'reploid.adapter-browser-qualification-config/v1',
  runtimeRoot: '/tmp/reploid-capsule-runtime-release/consumer/node_modules/doppler-gpu',
  modelDir: `${directory}/model`, adapterDir: `${directory}/adapter`,
  chromium: '/home/x/.cache/ms-playwright/chromium-1234/chrome-linux64/chrome',
  requiredVendor: 'amd', timeoutMs: 600000, launchArgs: settings.launchArgs,
  runtimeConfig: settings.runtimeConfig, adapterExecution: recipe.adapterExecution,
  generation: { maxTokens: reference.policy.maxNewTokens, maxSeqLen: 1024, temperature: 0, topP: 1, topK: 1,
    repetitionPenalty: 1, repetitionPenaltyWindow: 64, useChatTemplate: true, seed: 0,
    suppressSpecialTokens: false, suppressSpecialLikeTokens: false, suppressTokenIds: [], stopSequences: [] } });
