"""Independent CPU qualification; never imported by the Doppler runtime."""
import hashlib
import json
import platform
import time
from pathlib import Path
import torch
import transformers
import peft
from transformers import AutoModelForCausalLM, AutoTokenizer
from peft import LoraConfig, PeftModel, get_peft_model
from safetensors.torch import load_file

root = Path(__file__).resolve().parent
policy = json.loads((root / 'policy.json').read_text())
source = Path(policy['sourceDirectory'])
for name in policy['sourceFiles']:
    assert (source / '.cache/huggingface/download' / (name + '.metadata')).read_text().splitlines()[0] == policy['revision'], name
torch.set_num_threads(policy['threads'])
torch.manual_seed(policy['seed'])
torch.use_deterministic_algorithms(True)
assert policy['device'] == 'cpu' and policy['dtype'] == 'float32'
tokenizer = AutoTokenizer.from_pretrained(source, local_files_only=True, trust_remote_code=False)

def base_model():
    return AutoModelForCausalLM.from_pretrained(source, local_files_only=True, trust_remote_code=False,
        dtype=torch.float32, attn_implementation=policy['attention']).eval()

def write(name, data):
    (root / name).write_text(json.dumps(data, indent=2) + '\n')

def formatted(prompt):
    return tokenizer.apply_chat_template([{'role': 'user', 'content': prompt}], tokenize=False,
        add_generation_prompt=True, enable_thinking=policy['thinking'])

def observe(model):
    rows = []
    for prompt in policy['evaluationPrompts']:
        text = formatted(prompt)
        encoded = tokenizer(text, return_tensors='pt', add_special_tokens=False)
        start = time.monotonic()
        with torch.inference_mode():
            logits = model(**encoded).logits[0, -1].float()
            top = torch.topk(logits, 8)
            generated = model.generate(**encoded, do_sample=False, max_new_tokens=policy['maxNewTokens'], use_cache=True)
        ids = generated[0, encoded.input_ids.shape[1]:].tolist()
        rows.append({'prompt': prompt, 'formattedPrompt': text, 'promptTokenIds': encoded.input_ids[0].tolist(),
            'generatedTokenIds': ids, 'text': tokenizer.decode(ids, skip_special_tokens=True),
            'topLogits': {'ids': top.indices.tolist(), 'values': top.values.tolist()}, 'elapsedSeconds': time.monotonic() - start})
        print(json.dumps({'phase': 'reference', 'row': len(rows), 'text': rows[-1]['text']}), flush=True)
    return rows

report = {'schema': 'reploid.adapter-source-reference/v1', 'policy': policy,
    'engine': {'implementation': 'hf-transformers-pytorch-peft', 'torch': torch.__version__,
        'transformers': transformers.__version__, 'peft': peft.__version__, 'python': platform.python_version(),
        'device': 'cpu', 'dtype': 'float32'},
    'source': {'repository': policy['repository'], 'revision': policy['revision'],
        'files': [{'path': name, 'hash': 'sha256:' + hashlib.sha256((source / name).read_bytes()).hexdigest()} for name in policy['sourceFiles']]},
    'training': [], 'complete': False}
model = base_model()
report['baseOutputs'] = observe(model)
model = get_peft_model(model, LoraConfig(r=policy['rank'], lora_alpha=policy['alpha'],
    target_modules=policy['targetModules'], lora_dropout=policy['dropout'], bias=policy['bias'], task_type='CAUSAL_LM'))
model.train()
parameters = [value for value in model.parameters() if value.requires_grad]
settings = policy['optimizer']
assert settings['name'] == 'AdamW'
optimizer = torch.optim.AdamW(parameters, lr=settings['learningRate'], betas=tuple(settings['betas']),
    eps=settings['eps'], weight_decay=settings['weightDecay'])
for epoch in range(policy['epochs']):
    for index, example in enumerate(policy['trainingExamples']):
        prefix = tokenizer(formatted(example['prompt']), add_special_tokens=False)['input_ids']
        answer = tokenizer(example['answer'], add_special_tokens=False)['input_ids'] + [tokenizer.eos_token_id]
        assert len(prefix) + len(answer) <= policy['maxTrainingTokens']
        ids = torch.tensor([prefix + answer])
        labels = ids.clone()
        labels[:, :len(prefix)] = -100
        optimizer.zero_grad(set_to_none=True)
        start = time.monotonic()
        loss = model(input_ids=ids, attention_mask=torch.ones_like(ids), labels=labels, use_cache=False).loss
        assert torch.isfinite(loss)
        loss.backward()
        gradient = torch.nn.utils.clip_grad_norm_(parameters, settings['maxGradientNorm'])
        optimizer.step()
        row = {'epoch': epoch, 'example': index, 'loss': loss.item(), 'gradientNorm': gradient.item(),
            'elapsedSeconds': time.monotonic() - start}
        report['training'].append(row)
        print(json.dumps({'phase': 'training', **row}), flush=True)
        write('source-progress.json', report)
model.save_pretrained(root / 'adapter', safe_serialization=True)
weights_path = root / 'adapter/adapter_model.safetensors'
tensors = load_file(weights_path)
assert tensors and all(torch.isfinite(t).all() for t in tensors.values())
assert any(torch.count_nonzero(t).item() for name, t in tensors.items() if 'lora_B' in name)
weights = weights_path.read_bytes()
manifest = {'id': policy['adapterId'], 'name': 'Public summary integration adapter', 'baseModel': policy['baseModelId'],
    'rank': policy['rank'], 'alpha': policy['alpha'], 'targetModules': policy['targetModules'],
    'weightsFormat': 'safetensors', 'weightsPath': weights_path.name, 'weightsSize': len(weights),
    'checksumAlgorithm': 'sha256', 'checksum': hashlib.sha256(weights).hexdigest()}
write('adapter/runtime-manifest.json', manifest)
report['adapter'] = {'manifest': manifest, 'tensorCount': len(tensors), 'trainableParameters': sum(t.numel() for t in tensors.values())}
del model, optimizer, parameters
model = PeftModel.from_pretrained(base_model(), root / 'adapter', is_trainable=False).eval()
report['adaptedOutputs'] = observe(model)
report['complete'] = True
write('source-reference.json', report)
print(json.dumps({'complete': True, 'adapterBytes': len(weights), 'tensorCount': len(tensors)}), flush=True)
