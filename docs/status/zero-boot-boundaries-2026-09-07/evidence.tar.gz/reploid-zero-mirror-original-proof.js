const { execFileSync } = require('node:child_process');
const { writeFileSync } = require('node:fs');
const { chromium } = require('/home/clocksmith/deco/reploid/node_modules/playwright');
(async () => {
  const original = execFileSync('git', ['show', 'HEAD:self/ui/zero-home/index.js'], {
    cwd: '/home/clocksmith/deco/reploid', encoding: 'utf8'
  });
  const browser = await chromium.launch({ executablePath: '/home/clocksmith/.cache/ms-playwright/chromium-1208/chrome-linux64/chrome' });
  const report = { boundary: 'Original Zero Awaken mirror selection; handoff stubbed, no provider request.', warnings: [] };
  try {
    const page = await browser.newPage();
    page.on('console', message => {
      if (message.text().includes('Mirror source missing:')) report.warnings.push(message.text());
    });
    await page.route('**/ui/zero-home/index.js*', route => route.fulfill({ contentType: 'text/javascript', body: original }));
    await page.goto('http://localhost:8000/zero?instance=zero-original-mirror-proof-' + Date.now());
    await page.waitForFunction(() => typeof window.triggerAwaken === 'function');
    await page.locator('#awaken-btn').waitFor();
    await page.evaluate(() => { window.triggerAwaken = async goal => { window.zeroProofGoal = goal; }; });
    await page.locator('#goal-input').fill('Inspect the selected seed.');
    await page.locator('#awaken-btn').click();
    await page.waitForFunction(() => window.zeroProofGoal?.text === 'Inspect the selected seed.');
    report.originalFailureReproduced = report.warnings.length > 0;
    console.log(JSON.stringify(report, null, 2));
    writeFileSync('/tmp/reploid-zero-mirror-original-proof.json', JSON.stringify(report, null, 2) + '\n');
    if (!report.originalFailureReproduced) process.exitCode = 1;
  } finally { await browser.close(); }
})().catch(error => { console.error(error); process.exitCode = 1; });
