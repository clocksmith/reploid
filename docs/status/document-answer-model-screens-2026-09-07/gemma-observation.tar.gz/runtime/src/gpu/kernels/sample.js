

import { getDevice, getKernelCapabilities } from '../device.js';
import { acquireBuffer, readBufferSlice, releaseBuffer } from '../../memory/buffer-pool.js';
import { WORKGROUP_SIZES } from './constants.js';
import {
  createPipeline,
  getOrCreateBindGroupLayout,
} from './pipeline-cache.js';
import { createUniformBufferWithView } from './uniform-utils.js';
import { allowReadback } from '../perf-guards.js';
import { selectRuleValue as selectKernelRuleValue } from './rule-registry.js';
import { selectRuleValue as selectSharedRuleValue } from '../../rules/rule-registry.js';
import { getKernelThresholds } from '../../config/schema/index.js';
import { recordDispatch } from './dispatch.js';


function getSampleBindGroupLayout(device) {
  return getOrCreateBindGroupLayout(
    'sample_bind_group_layout',
    [
      { binding: 0, visibility: GPUShaderStage.COMPUTE, buffer: { type: 'uniform' } },
      { binding: 1, visibility: GPUShaderStage.COMPUTE, buffer: { type: 'read-only-storage' } },
      { binding: 2, visibility: GPUShaderStage.COMPUTE, buffer: { type: 'storage' } },
      { binding: 3, visibility: GPUShaderStage.COMPUTE, buffer: { type: 'storage' } },
      { binding: 4, visibility: GPUShaderStage.COMPUTE, buffer: { type: 'storage' } },
    ],
    device
  );
}


async function createSamplePipeline(device, entryPoint) {
  return createPipeline('sample', entryPoint, getSampleBindGroupLayout(device));
}

function resolveSampleVariants(logitsDtype) {
  const caps = getKernelCapabilities();
  const useF16 = logitsDtype === 'f16';
  if (useF16 && !caps.hasF16) {
    throw new Error('[Sample] F16 logits requested but shader-f16 is unavailable.');
  }
  const suffix = selectKernelRuleValue('sample', 'suffix', { useF16 });
  return {
    argmax: `argmax${suffix}`,
    argmaxReduce: `argmax_reduce${suffix}`,
    phase1: `find_topk_phase1${suffix}`,
    phase2: `find_topk_phase2${suffix}`,
    phase3: `softmax_and_sample${suffix}`,
    singlePass: `single_pass${suffix}`,
  };
}


function resolveLogitsDtype(logitsDtype) {
  return selectSharedRuleValue('shared', 'dtype', 'logitsDtype', { logitsDtype });
}

function assertArgmaxOptions(options, recordMode = false) {
  const suffix = recordMode ? ' (record)' : '';
  if (options.logitsDtype == null) {
    throw new Error(`[Sample] logitsDtype is required for argmax${suffix}.`);
  }
  if (options.outputIndex == null) {
    throw new Error(`[Sample] outputIndex is required for argmax${suffix}.`);
  }
  if (options.logitSoftcap === undefined) {
    throw new Error(`[Sample] logitSoftcap is required for argmax${suffix}.`);
  }
  if (options.padTokenId === undefined) {
    throw new Error(`[Sample] padTokenId is required for argmax${suffix}.`);
  }
}

function assertSampleOptions(options, recordMode = false) {
  const suffix = recordMode ? ' (record)' : '';
  if (options.temperature == null) {
    throw new Error(`[Sample] temperature is required for sampling${suffix}.`);
  }
  if (options.topK == null) {
    throw new Error(`[Sample] topK is required for sampling${suffix}.`);
  }
  if (options.logitsDtype == null) {
    throw new Error(`[Sample] logitsDtype is required for sampling${suffix}.`);
  }
  if (options.outputIndex == null) {
    throw new Error(`[Sample] outputIndex is required for sampling${suffix}.`);
  }
  if (options.logitSoftcap === undefined) {
    throw new Error(`[Sample] logitSoftcap is required for sampling${suffix}.`);
  }
  if (options.padTokenId === undefined) {
    throw new Error(`[Sample] padTokenId is required for sampling${suffix}.`);
  }
  if (options.greedyThreshold == null) {
    throw new Error(`[Sample] greedyThreshold is required for sampling${suffix}.`);
  }
}

async function resolveArgmaxPipelines(device, vocabSize, variants) {
  const argmaxPipeline = await createSamplePipeline(device, variants.argmax);
  const reduceWorkgroups = Math.min(WORKGROUP_SIZES.DEFAULT, Math.ceil(vocabSize / WORKGROUP_SIZES.DEFAULT));
  const { argmaxReduceVocabThreshold } = getKernelThresholds().sample;
  const useSinglePassArgmax = vocabSize <= argmaxReduceVocabThreshold;
  const numWorkgroups = useSinglePassArgmax ? 1 : reduceWorkgroups;
  const reducePipeline = useSinglePassArgmax
    ? null
    : await createSamplePipeline(device, variants.argmaxReduce);
  const singlePassPipeline = useSinglePassArgmax
    ? await createSamplePipeline(device, variants.singlePass)
    : null;

  return {
    argmaxPipeline,
    reducePipeline,
    singlePassPipeline,
    numWorkgroups,
    useSinglePassArgmax,
  };
}

function createArgmaxUniformBuffer(device, recorder, vocabSize, options) {
  const padTokenValue = options.padTokenId == null ? 0xFFFFFFFF : options.padTokenId;
  return createUniformBufferWithView(
    'argmax_uniforms',
    32,
    (view) => {
      view.setUint32(0, vocabSize, true);
      view.setUint32(4, 1, true);
      view.setFloat32(8, 1.0, true);
      view.setFloat32(12, 0.0, true);
      view.setUint32(16, padTokenValue, true);
      view.setFloat32(20, options.logitSoftcap, true);
      view.setUint32(24, options.outputIndex, true);
    },
    recorder,
    device
  );
}

function createSampleUniformBuffer(device, recorder, vocabSize, topK, temperature, randomValue, padTokenId, logitSoftcap, outputIndex) {
  return createUniformBufferWithView(
    'sample_uniforms',
    32,
    (view) => {
      view.setUint32(0, vocabSize, true);
      view.setUint32(4, topK, true);
      view.setFloat32(8, temperature, true);
      view.setFloat32(12, randomValue, true);
      view.setUint32(16, padTokenId == null ? 0xFFFFFFFF : padTokenId, true);
      view.setFloat32(20, logitSoftcap, true);
      view.setUint32(24, outputIndex, true);
    },
    recorder,
    device
  );
}

function ensureOutputBufferSize(outputBuffer, minBytes, label) {
  if (outputBuffer.size < minBytes) {
    throw new Error(`[Sample] outputBuffer too small for ${label}.`);
  }
}

async function readTokenFromOutput(outputBuffer, outputIndex) {
  return new Uint32Array(await readBufferSlice(outputBuffer, outputIndex * 4, 4))[0];
}

function cleanupRunResources(uniformBuffer, ownedBuffers) {
  if (uniformBuffer) {
    uniformBuffer.destroy();
  }
  for (const buffer of ownedBuffers) {
    if (buffer) {
      releaseBuffer(buffer);
    }
  }
}

async function executeArgmaxRun(logits, vocabSize, options) {
  if (!allowReadback('sample.runArgmax')) {
    throw new Error('[Sample] GPU readback disabled for argmax');
  }

  const device = getDevice();
  if (!device) throw new Error('GPU device not initialized');

  assertArgmaxOptions(options, false);

  const logitsDtype = resolveLogitsDtype(options.logitsDtype);
  const variants = resolveSampleVariants(logitsDtype);
  const {
    argmaxPipeline,
    reducePipeline,
    singlePassPipeline,
    numWorkgroups,
    useSinglePassArgmax,
  } = await resolveArgmaxPipelines(device, vocabSize, variants);

  let tempLogits = null;
  let tempIndices = null;
  let outputBuffer = null;
  let ownsOutputBuffer = false;
  let uniformBuffer = null;
  try {
    tempLogits = acquireBuffer(WORKGROUP_SIZES.DEFAULT * 4, undefined, 'argmax_temp_logits');
    tempIndices = acquireBuffer(WORKGROUP_SIZES.DEFAULT * 4, undefined, 'argmax_temp_indices');
    const outputIndex = options.outputIndex;
    const minOutputBytes = Math.max(4, (outputIndex + 1) * 4);
    outputBuffer = options.outputBuffer ?? acquireBuffer(minOutputBytes, undefined, 'argmax_output');
    ownsOutputBuffer = !options.outputBuffer;
    ensureOutputBufferSize(outputBuffer, minOutputBytes, 'argmax outputIndex');

    uniformBuffer = createArgmaxUniformBuffer(device, null, vocabSize, options);

    const bindGroupLayout = getSampleBindGroupLayout(device);
    const entries = [
      { binding: 0, resource: { buffer: uniformBuffer } },
      { binding: 1, resource: { buffer: logits } },
      { binding: 2, resource: { buffer: outputBuffer } },
      { binding: 3, resource: { buffer: tempIndices } },
      { binding: 4, resource: { buffer: tempLogits } },
    ];
    const argmaxBindGroup = device.createBindGroup({
      label: 'argmax_bind_group',
      layout: bindGroupLayout,
      entries,
    });

    const encoder = device.createCommandEncoder({ label: 'argmax_encoder' });

    const pass1 = encoder.beginComputePass({ label: 'argmax_pass1' });
    pass1.setPipeline(singlePassPipeline ?? argmaxPipeline);
    pass1.setBindGroup(0, argmaxBindGroup);
    pass1.dispatchWorkgroups(useSinglePassArgmax ? 1 : numWorkgroups);
    pass1.end();

    if (reducePipeline) {
      const reduceBindGroup = device.createBindGroup({
        label: 'argmax_reduce_bind_group',
        layout: bindGroupLayout,
        entries,
      });

      const pass2 = encoder.beginComputePass({ label: 'argmax_pass2' });
      pass2.setPipeline(reducePipeline);
      pass2.setBindGroup(0, reduceBindGroup);
      pass2.dispatchWorkgroups(1);
      pass2.end();
    }

    device.queue.submit([encoder.finish()]);
    return await readTokenFromOutput(outputBuffer, outputIndex);
  } finally {
    cleanupRunResources(
      uniformBuffer,
      [tempLogits, tempIndices, ownsOutputBuffer ? outputBuffer : null]
    );
  }
}

async function executeArgmaxRecord(recorder, logits, vocabSize, options) {
  const device = recorder.device;

  assertArgmaxOptions(options, true);

  const logitsDtype = resolveLogitsDtype(options.logitsDtype);
  const variants = resolveSampleVariants(logitsDtype);
  const {
    argmaxPipeline,
    reducePipeline,
    singlePassPipeline,
    numWorkgroups,
    useSinglePassArgmax,
  } = await resolveArgmaxPipelines(device, vocabSize, variants);

  let tempLogits = null;
  let tempIndices = null;
  let outputBuffer = null;
  let ownsOutputBuffer = false;
  let completed = false;
  try {
    tempLogits = acquireBuffer(WORKGROUP_SIZES.DEFAULT * 4, undefined, 'argmax_temp_logits');
    tempIndices = acquireBuffer(WORKGROUP_SIZES.DEFAULT * 4, undefined, 'argmax_temp_indices');
    const outputIndex = options.outputIndex;
    const minOutputBytes = Math.max(4, (outputIndex + 1) * 4);
    outputBuffer = options.outputBuffer ?? acquireBuffer(minOutputBytes, undefined, 'argmax_output');
    ownsOutputBuffer = !options.outputBuffer;
    ensureOutputBufferSize(outputBuffer, minOutputBytes, 'argmax outputIndex');

    const uniformBuffer = createArgmaxUniformBuffer(device, recorder, vocabSize, options);

    const bindGroupLayout = getSampleBindGroupLayout(device);
    const entries = [
      { binding: 0, resource: { buffer: uniformBuffer } },
      { binding: 1, resource: { buffer: logits } },
      { binding: 2, resource: { buffer: outputBuffer } },
      { binding: 3, resource: { buffer: tempIndices } },
      { binding: 4, resource: { buffer: tempLogits } },
    ];
    const bindGroup = device.createBindGroup({
      label: 'argmax_bind_group',
      layout: bindGroupLayout,
      entries,
    });

    recordDispatch(
      recorder,
      singlePassPipeline ?? argmaxPipeline,
      bindGroup,
      useSinglePassArgmax ? 1 : numWorkgroups,
      'argmax_phase1'
    );

    if (reducePipeline) {
      const reduceBindGroup = device.createBindGroup({
        label: 'argmax_reduce_bind_group',
        layout: bindGroupLayout,
        entries,
      });
      recordDispatch(recorder, reducePipeline, reduceBindGroup, 1, 'argmax_phase2');
    }

    recorder.trackTemporaryBuffer(tempLogits);
    recorder.trackTemporaryBuffer(tempIndices);
    completed = true;
    return outputBuffer;
  } finally {
    if (!completed) {
      cleanupRunResources(
        null,
        [tempLogits, tempIndices, ownsOutputBuffer ? outputBuffer : null]
      );
    }
  }
}

export async function runArgmax(
  logits,
  vocabSize,
  options = {}
) {
  return executeArgmaxRun(logits, vocabSize, options);
}


export async function runGPUSample(
  logits,
  vocabSize,
  options = {}
) {
  if (!allowReadback('sample.runGPUSample')) {
    throw new Error('[Sample] GPU readback disabled for sampling');
  }

  assertSampleOptions(options, false);

  const {
    temperature,
    topK,
    randomSeed,
    padTokenId,
    logitSoftcap,
    greedyThreshold,
    outputBuffer: outputBufferOverride,
    outputIndex,
  } = options;
  const logitsDtype = resolveLogitsDtype(options.logitsDtype);

  if (temperature < greedyThreshold || topK <= 1) {
    return runArgmax(logits, vocabSize, {
      padTokenId,
      logitSoftcap,
      logitsDtype,
      outputBuffer: outputBufferOverride,
      outputIndex,
    });
  }

  const device = getDevice();
  if (!device) throw new Error('GPU device not initialized');

  const randomValue = randomSeed !== undefined
    ? seededRandom(randomSeed)
    : unseededRandom();

  const variants = resolveSampleVariants(logitsDtype);
  const phase1Pipeline = await createSamplePipeline(device, variants.phase1);
  const phase2Pipeline = await createSamplePipeline(device, variants.phase2);
  const phase3Pipeline = await createSamplePipeline(device, variants.phase3);

  const numWorkgroups = Math.min(WORKGROUP_SIZES.DEFAULT, Math.ceil(vocabSize / WORKGROUP_SIZES.DEFAULT));

  let topkLogits = null;
  let topkIndices = null;
  let outputBuffer = null;
  let ownsOutputBuffer = false;
  let uniformBuffer = null;
  try {
    topkLogits = acquireBuffer(WORKGROUP_SIZES.DEFAULT * 4, undefined, 'topk_logits');
    topkIndices = acquireBuffer(WORKGROUP_SIZES.DEFAULT * 4, undefined, 'topk_indices');
    const minOutputBytes = Math.max(4, (outputIndex + 1) * 4);
    outputBuffer = outputBufferOverride ?? acquireBuffer(minOutputBytes, undefined, 'sample_output');
    ownsOutputBuffer = !outputBufferOverride;
    ensureOutputBufferSize(outputBuffer, minOutputBytes, 'sample outputIndex');

    uniformBuffer = createSampleUniformBuffer(
      device,
      null,
      vocabSize,
      topK,
      temperature,
      randomValue,
      padTokenId,
      logitSoftcap,
      outputIndex
    );

    const bindGroupLayout = getSampleBindGroupLayout(device);
    const bindGroup = device.createBindGroup({
      label: 'sample_bind_group',
      layout: bindGroupLayout,
      entries: [
        { binding: 0, resource: { buffer: uniformBuffer } },
        { binding: 1, resource: { buffer: logits } },
        { binding: 2, resource: { buffer: outputBuffer } },
        { binding: 3, resource: { buffer: topkIndices } },
        { binding: 4, resource: { buffer: topkLogits } },
      ],
    });

    const encoder = device.createCommandEncoder({ label: 'sample_encoder' });

    const pass1 = encoder.beginComputePass({ label: 'sample_phase1' });
    pass1.setPipeline(phase1Pipeline);
    pass1.setBindGroup(0, bindGroup);
    pass1.dispatchWorkgroups(numWorkgroups);
    pass1.end();

    const pass2 = encoder.beginComputePass({ label: 'sample_phase2' });
    pass2.setPipeline(phase2Pipeline);
    pass2.setBindGroup(0, bindGroup);
    pass2.dispatchWorkgroups(1);
    pass2.end();

    const pass3 = encoder.beginComputePass({ label: 'sample_phase3' });
    pass3.setPipeline(phase3Pipeline);
    pass3.setBindGroup(0, bindGroup);
    pass3.dispatchWorkgroups(1);
    pass3.end();

    device.queue.submit([encoder.finish()]);
    return await readTokenFromOutput(outputBuffer, outputIndex);
  } finally {
    cleanupRunResources(
      uniformBuffer,
      [topkLogits, topkIndices, ownsOutputBuffer ? outputBuffer : null]
    );
  }
}


export async function recordArgmax(
  recorder,
  logits,
  vocabSize,
  options = {}
) {
  return executeArgmaxRecord(recorder, logits, vocabSize, options);
}


export async function recordGPUSample(
  recorder,
  logits,
  vocabSize,
  options = {}
) {
  assertSampleOptions(options, true);

  const {
    temperature,
    topK,
    randomSeed,
    padTokenId,
    logitSoftcap,
    greedyThreshold,
    outputBuffer: outputBufferOverride,
    outputIndex,
  } = options;
  const logitsDtype = resolveLogitsDtype(options.logitsDtype);

  if (temperature < greedyThreshold || topK <= 1) {
    return recordArgmax(recorder, logits, vocabSize, {
      padTokenId,
      logitSoftcap,
      logitsDtype,
      outputBuffer: outputBufferOverride,
      outputIndex,
    });
  }

  const device = recorder.device;

  const randomValue = randomSeed !== undefined
    ? seededRandom(randomSeed)
    : unseededRandom();

  const variants = resolveSampleVariants(logitsDtype);
  const phase1Pipeline = await createSamplePipeline(device, variants.phase1);
  const phase2Pipeline = await createSamplePipeline(device, variants.phase2);
  const phase3Pipeline = await createSamplePipeline(device, variants.phase3);

  const numWorkgroups = Math.min(WORKGROUP_SIZES.DEFAULT, Math.ceil(vocabSize / WORKGROUP_SIZES.DEFAULT));

  let topkLogits = null;
  let topkIndices = null;
  let outputBuffer = null;
  let ownsOutputBuffer = false;
  let completed = false;
  try {
    topkLogits = acquireBuffer(WORKGROUP_SIZES.DEFAULT * 4, undefined, 'topk_logits');
    topkIndices = acquireBuffer(WORKGROUP_SIZES.DEFAULT * 4, undefined, 'topk_indices');
    const minOutputBytes = Math.max(4, (outputIndex + 1) * 4);
    outputBuffer = outputBufferOverride ?? acquireBuffer(minOutputBytes, undefined, 'sample_output');
    ownsOutputBuffer = !outputBufferOverride;
    ensureOutputBufferSize(outputBuffer, minOutputBytes, 'sample outputIndex');

    const uniformBuffer = createSampleUniformBuffer(
      device,
      recorder,
      vocabSize,
      topK,
      temperature,
      randomValue,
      padTokenId,
      logitSoftcap,
      outputIndex
    );

    const bindGroupLayout = getSampleBindGroupLayout(device);
    const bindGroup = device.createBindGroup({
      label: 'sample_bind_group',
      layout: bindGroupLayout,
      entries: [
        { binding: 0, resource: { buffer: uniformBuffer } },
        { binding: 1, resource: { buffer: logits } },
        { binding: 2, resource: { buffer: outputBuffer } },
        { binding: 3, resource: { buffer: topkIndices } },
        { binding: 4, resource: { buffer: topkLogits } },
      ],
    });

    recordDispatch(recorder, phase1Pipeline, bindGroup, numWorkgroups, 'sample_phase1');
    recordDispatch(recorder, phase2Pipeline, bindGroup, 1, 'sample_phase2');
    recordDispatch(recorder, phase3Pipeline, bindGroup, 1, 'sample_phase3');

    recorder.trackTemporaryBuffer(topkLogits);
    recorder.trackTemporaryBuffer(topkIndices);
    completed = true;
    return outputBuffer;
  } finally {
    if (!completed) {
      cleanupRunResources(
        null,
        [topkLogits, topkIndices, ownsOutputBuffer ? outputBuffer : null]
      );
    }
  }
}


function seededRandom(seed) {
  const x = Math.sin(seed) * 10000;
  return x - Math.floor(x);
}

const UNSEEDED_RANDOM_DEFAULT_STATE = 0x6d2b79f5;
let fallbackRandomState = UNSEEDED_RANDOM_DEFAULT_STATE;

function unseededRandom() {
  if (typeof crypto !== 'undefined' && typeof crypto.getRandomValues === 'function') {
    const values = new Uint32Array(1);
    crypto.getRandomValues(values);
    return values[0] / 4294967296;
  }
  fallbackRandomState = (fallbackRandomState + 0x6d2b79f5) >>> 0;
  return fallbackRandomState / 4294967296;
}


export function isGPUSamplingAvailable() {
  return getDevice() !== null;
}
