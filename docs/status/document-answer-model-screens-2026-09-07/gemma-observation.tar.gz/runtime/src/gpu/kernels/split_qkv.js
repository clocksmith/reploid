
import { acquireBuffer, releaseBuffer } from '../../memory/buffer-pool.js';
import { createTensor, dtypeBytes } from '../tensor.js';
import { GPU_LIMITS, WORKGROUP_SIZES } from './constants.js';
import { unifiedKernelWrapper } from './kernel-execution.js';
import { selectRuleValue } from './rule-registry.js';

export function planSplitQKVDispatch(totalElements) {
  if (!Number.isSafeInteger(totalElements) || totalElements <= 0) {
    throw new Error(`split_qkv requires a positive safe integer element count, got ${totalElements}.`);
  }
  const workgroups = Math.ceil(totalElements / WORKGROUP_SIZES.DEFAULT);
  const x = Math.min(workgroups, GPU_LIMITS.MAX_WORKGROUPS);
  const y = Math.ceil(workgroups / x);
  if (y > GPU_LIMITS.MAX_WORKGROUPS) {
    throw new Error(
      `split_qkv requires ${workgroups} workgroups, exceeding the two-axis WebGPU capacity.`
    );
  }
  return [x, y, 1];
}

async function _splitQKV(target, qkvTensor, options) {
  const { numTokens, qSize, kSize, vSize, qTensor = null, kTensor = null, vTensor = null } = options;
  const ownsQ = qTensor == null;
  const ownsK = kTensor == null;
  const ownsV = vTensor == null;

  const outputDtype = qkvTensor.dtype;
  const pipelineVariant = selectRuleValue('splitQkv', 'variant', { outputDtype });
  const bytesPerElement = dtypeBytes(outputDtype);

  const qBuffer = qTensor?.buffer || acquireBuffer(numTokens * qSize * bytesPerElement, undefined, 'Q');
  const kBuffer = kTensor?.buffer || acquireBuffer(numTokens * kSize * bytesPerElement, undefined, 'K');
  const vBuffer = vTensor?.buffer || acquireBuffer(numTokens * vSize * bytesPerElement, undefined, 'V');

  const totalElements = numTokens * (qSize + kSize + vSize);

  try {
    await unifiedKernelWrapper(
      'split_qkv', target, pipelineVariant,
      [qkvTensor, qBuffer, kBuffer, vBuffer],
      { num_tokens: numTokens, q_size: qSize, k_size: kSize, v_size: vSize },
      planSplitQKVDispatch(totalElements)
    );

    const Q = qTensor || createTensor(qBuffer, outputDtype, [numTokens, qSize], 'Q');
    const K = kTensor || createTensor(kBuffer, outputDtype, [numTokens, kSize], 'K');
    const V = vTensor || createTensor(vBuffer, outputDtype, [numTokens, vSize], 'V');

    return { Q, K, V };
  } catch (error) {
    if (ownsQ) releaseBuffer(qBuffer);
    if (ownsK) releaseBuffer(kBuffer);
    if (ownsV) releaseBuffer(vBuffer);
    throw error;
  }
}

export async function runSplitQKV(qkvTensor, options) {
  return _splitQKV(null, qkvTensor, options);
}

export async function recordSplitQKV(recorder, qkvTensor, options) {
  return _splitQKV(recorder, qkvTensor, options);
}
