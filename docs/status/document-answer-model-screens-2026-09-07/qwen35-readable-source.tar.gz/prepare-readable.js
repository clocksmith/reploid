// Development-only serialization candidate. Product code remains unchanged.
import assert from 'node:assert/strict';
import { readFile, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { formatChatMessages } from '/home/clocksmith/deco/reploid/node_modules/doppler-gpu/src/inference/pipelines/text/chat-format.js';
import { Tokenizer } from '/home/clocksmith/deco/reploid/node_modules/doppler-gpu/src/inference/tokenizer.js';
const root = dirname(fileURLToPath(import.meta.url));
const sha = bytes => 'sha256:' + createHash('sha256').update(bytes).digest('hex');
const previousBytes = await readFile(root + '/source-reference-01/reference.json');
const previous = JSON.parse(previousBytes);
const originalInputs = JSON.parse(await readFile(root + '/source-inputs.json'));
const corpus = JSON.parse(await readFile(root + '/screen-01/corpus.json'));
const manifest = JSON.parse(await readFile(root + '/model/manifest.json'));
const tokenizer = new Tokenizer();
await tokenizer.initialize(manifest, { loadTokenizerJson: async () => JSON.parse(await readFile(root + '/model/tokenizer.json')) });
const rows = originalInputs.rows.map((row, index) => {
  const entry = corpus.cases[index];
  assert.equal(entry.id, row.id);
  const payload = JSON.stringify({ question: entry.question,
    passages: entry.passages.map((passage, index) => ({ citation: index + 1, text: passage.text })) });
  assert(row.prompt.endsWith(payload));
  const prefix = row.prompt.slice(0, -payload.length);
  const prompt = prefix + '\nQuestion:\n' + JSON.stringify(entry.question) + '\n\nSupplied passages:\n'
    + entry.passages.map((passage, index) => `[${index + 1}] ${JSON.stringify(passage.text)}`).join('\n')
    + '\n\nAnswer:';
  const formatted = formatChatMessages([{ role: 'user', content: prompt }], manifest.inference.chatTemplate.type);
  return { ...row, prompt, formatted, tokenIds: tokenizer.encode(formatted),
    originalPromptDigest: sha(row.prompt), unchangedInstructionsDigest: sha(prefix),
    observedTokenIds: previous.cases[index].rawGeneratedTokenIds,
    observedOutput: previous.cases[index].output };
});
const experiment = {
  schema: 'reploid.document-answer-prompt-development/v1', frozenAt: new Date().toISOString(),
  outputDirectory: 'readable-source-02', executionDigest: sha(previousBytes),
  priorPreflightFailureDigest: sha(await readFile(root + '/readable-source-01/reference.json')),
  preflightCorrection: 'Remove trailing newline from the candidate prompt. The source template trims it; Doppler preserves it. No question, passage, instruction or acceptance change.',
  hypothesis: 'Labeled quoted passages improve complete supported answers compared with the JSON data block, with identical instructions and source execution.',
  selectionRule: 'Every case must satisfy the frozen review requirements. Zero unsupported facts, correct citations and unknowns, preserve conflicts or permitted exact abstention. Development success does not authorize promotion.',
  boundary: 'Source-only serialization development candidate compared with the prior source baseline. Not browser/source parity, not held out, not independent review, not semantic qualification.',
  corpusDigest: sha(await readFile(root + '/screen-01/corpus.json')), rows,
};
await writeFile(root + '/readable-inputs-02.json', JSON.stringify(experiment, null, 2) + '\n', { flag: 'wx' });
console.log(JSON.stringify({ cases: rows.length, baselineDigest: experiment.executionDigest,
  frozenDigest: sha(await readFile(root + '/readable-inputs-02.json')) }));
