import { readFile, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { formatChatMessages } from '/home/clocksmith/deco/reploid/node_modules/doppler-gpu/src/inference/pipelines/text/chat-format.js';
import { Tokenizer } from '/home/clocksmith/deco/reploid/node_modules/doppler-gpu/src/inference/tokenizer.js';
const root = dirname(fileURLToPath(import.meta.url));
const bytes = await readFile(root + '/screen-01/execution.json');
const report = JSON.parse(bytes);
const manifest = JSON.parse(await readFile(root + '/model/manifest.json'));
const tokenizer = new Tokenizer();
await tokenizer.initialize(manifest, { loadTokenizerJson: async () => JSON.parse(await readFile(root + '/model/tokenizer.json')) });
const rows = report.cases.map(row => {
  const formatted = formatChatMessages([{ role: 'user', content: row.prompt }], manifest.inference.chatTemplate.type);
  return { id: row.id, prompt: row.prompt, formatted, tokenIds: tokenizer.encode(formatted),
    observedTokenIds: row.evidence.tokenIds, observedOutput: row.evidence.outputText, options: row.options };
});
await writeFile(root + '/source-inputs.json', JSON.stringify({
  executionDigest: 'sha256:' + createHash('sha256').update(bytes).digest('hex'),
  runtimeVersion: report.package.version, rows,
}, null, 2) + '\n', { flag: 'wx' });
console.log(JSON.stringify({ cases: rows.length, promptTokens: rows.map(row => row.tokenIds.length) }));
