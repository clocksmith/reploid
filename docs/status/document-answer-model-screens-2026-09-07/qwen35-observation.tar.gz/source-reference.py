"""Pinned source-precision control for the failed Qwen3.5 browser configuration."""
import copy
import hashlib
import json
import platform
import time
from pathlib import Path
import torch
import transformers
from transformers import AutoTokenizer, Qwen3_5ForConditionalGeneration

root = Path(__file__).resolve().parent
source = root / 'source'
inputs_bytes = (root / 'source-inputs.json').read_bytes()
inputs = json.loads(inputs_bytes)
acquisition = json.loads((root / 'source-acquisition.json').read_text())
assert acquisition['complete'] is True
assert acquisition['revision'] == '15852e8c16360a2fea060d615a32b45270f8a8fc'
assert torch.__version__ == '2.11.0+cpu' and transformers.__version__ == '5.6.2'
output = root / 'source-reference-01'
output.mkdir()
sha = lambda value: 'sha256:' + hashlib.sha256(value).hexdigest()
report = {
    'schema': 'reploid.document-answer-source-diagnostic/v1',
    'hypothesis': 'The source-precision model reproduces the failed ticket answer and unsupported carton mass at identical input tokens.',
    'inputDigest': sha(inputs_bytes), 'executionDigest': inputs['executionDigest'],
    'sourceRevision': acquisition['revision'], 'sourceFiles': [], 'cases': [],
    'complete': False, 'semanticSupportQualified': False,
    'engine': {'torch': torch.__version__, 'transformers': transformers.__version__,
               'python': platform.python_version(), 'device': 'cpu', 'dtype': 'float32',
               'attention': 'eager', 'threads': 4, 'seed': 0},
    'boundary': 'Same operator, exposed development cases; source precision differs from browser Q4K/F16. No universal numerical-equivalence claim.',
}
def retain():
    (output / 'reference.json').write_text(json.dumps(report, indent=2) + '\n')
try:
    for expected in acquisition['files']:
        path = source / expected['filename']
        with path.open('rb') as stream:
            digest = hashlib.file_digest(stream, 'sha256').hexdigest()
        assert digest == expected['sha256'] and path.stat().st_size == expected['bytes']
        report['sourceFiles'].append(expected)
    torch.set_num_threads(4)
    torch.manual_seed(0)
    torch.use_deterministic_algorithms(True)
    tokenizer = AutoTokenizer.from_pretrained(source, local_files_only=True, trust_remote_code=False)
    for row in inputs['rows']:
        formatted = tokenizer.apply_chat_template([{'role': 'user', 'content': row['prompt']}],
            tokenize=False, add_generation_prompt=True, enable_thinking=False)
        token_ids = tokenizer(formatted, add_special_tokens=False)['input_ids']
        if formatted != row['formatted'] or token_ids != row['tokenIds']:
            report['tokenizationMismatch'] = {'id': row['id'], 'sourceFormatted': formatted,
                'dopplerFormatted': row['formatted'], 'sourceIds': token_ids, 'dopplerIds': row['tokenIds']}
            raise ValueError('Source and Doppler input tokens differ; stop before numerical comparison')
    report['tokenizationMatchedCases'] = len(inputs['rows'])
    retain()
    print(json.dumps({'phase': 'tokenization', 'matchedCases': len(inputs['rows'])}), flush=True)
    model = Qwen3_5ForConditionalGeneration.from_pretrained(source, local_files_only=True,
        trust_remote_code=False, dtype=torch.float32, attn_implementation='eager').eval()
    report['sourceGenerationConfig'] = model.generation_config.to_dict()
    for row in inputs['rows']:
        began = time.monotonic()
        token_ids = torch.tensor([row['tokenIds']], dtype=torch.long)
        observation = {'id': row['id'], 'promptTokenIds': row['tokenIds'], 'boundaries': {}}
        def capture(module, args, result):
            if observation['boundaries']:
                return
            value = result.detach().float().cpu().contiguous()
            last = value[0, -1].reshape(-1)
            observation['boundaries']['embeddings'] = {'shape': list(value.shape),
                'lastTokenSamples': last[:16].tolist(), 'lastTokenDigest': sha(last.numpy().tobytes()),
                'finite': bool(torch.isfinite(value).all())}
        hook = model.get_input_embeddings().register_forward_hook(capture)
        try:
            with torch.inference_mode():
                first = model(input_ids=token_ids, attention_mask=torch.ones_like(token_ids),
                    use_cache=False, logits_to_keep=1).logits[0, -1].float()
                values, indices = torch.topk(first, 8)
                observation['firstLogits'] = {'ids': indices.tolist(), 'values': values.tolist(),
                    'digest': sha(first.numpy().tobytes()), 'finite': bool(torch.isfinite(first).all())}
                config = copy.deepcopy(model.generation_config)
                config.do_sample = False
                config.max_new_tokens = row['options']['maxTokens']
                config.repetition_penalty = row['options']['repetitionPenalty']
                config.use_cache = True
                generated = model.generate(input_ids=token_ids, attention_mask=torch.ones_like(token_ids),
                    generation_config=config)[0, token_ids.shape[1]:].tolist()
            text = tokenizer.decode(generated, skip_special_tokens=True)
            observation.update({'rawGeneratedTokenIds': generated, 'output': text,
                'exactTokens': generated == row['observedTokenIds'], 'exactText': text == row['observedOutput'],
                'elapsedSeconds': time.monotonic() - began})
            report['cases'].append(observation)
            retain()
            print(json.dumps({key: observation[key] for key in ['id', 'output', 'exactTokens', 'exactText', 'elapsedSeconds']}), flush=True)
        finally:
            hook.remove()
    report['complete'] = True
except Exception as error:
    report['error'] = {'type': type(error).__name__, 'message': str(error)}
    raise
finally:
    retain()
