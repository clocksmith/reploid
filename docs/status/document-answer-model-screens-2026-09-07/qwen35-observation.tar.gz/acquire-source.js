// Immutable upstream reference acquisition. No model or runtime promotion.
import assert from 'node:assert/strict';
import { mkdir, writeFile, rename } from 'node:fs/promises';
import { createWriteStream } from 'node:fs';
import { Readable, Transform } from 'node:stream';
import { pipeline } from 'node:stream/promises';
import { createHash } from 'node:crypto';
import { dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
const root = dirname(fileURLToPath(import.meta.url));
const sourceRoot = root + '/source';
const revision = '15852e8c16360a2fea060d615a32b45270f8a8fc';
const repository = 'Qwen/Qwen3.5-2B';
await mkdir(sourceRoot);
const metadataResponse = await fetch(`https://huggingface.co/api/models/${repository}/revision/${revision}?blobs=true`);
assert(metadataResponse.ok, `Metadata HTTP ${metadataResponse.status}`);
const metadata = await metadataResponse.json();
assert.equal(metadata.sha, revision);
assert.equal(metadata.gated, false);
await writeFile(root + '/source-metadata.json', JSON.stringify(metadata, null, 2) + '\n', { flag: 'wx' });
const report = { repository, revision, files: [], complete: false, startedAt: new Date().toISOString() };
try {
  for (const entry of metadata.siblings.filter(row => row.rfilename !== '.gitattributes')) {
    const filename = entry.rfilename;
    assert(/^[a-zA-Z0-9_.-]+$/.test(filename) && !filename.includes('..'));
    const url = `https://huggingface.co/${repository}/resolve/${revision}/${filename}`;
    const response = await fetch(url, { signal: AbortSignal.timeout(1200000) });
    assert(response.ok, `${filename}: HTTP ${response.status}`);
    const sha256 = createHash('sha256');
    const gitBlob = createHash('sha1').update(`blob ${entry.size}\0`);
    let bytes = 0, loggedAt = 0;
    const stream = new Transform({ transform(chunk, encoding, done) {
      bytes += chunk.length; sha256.update(chunk); gitBlob.update(chunk);
      if (bytes - loggedAt >= 268435456) { loggedAt = bytes; console.log(JSON.stringify({ filename, received: bytes, expected: entry.size })); }
      done(null, chunk);
    } });
    await pipeline(Readable.fromWeb(response.body), stream, createWriteStream(sourceRoot + '/' + filename + '.partial', { flags: 'wx' }));
    const digest = sha256.digest('hex');
    assert.equal(bytes, entry.size, filename);
    if (entry.lfs) assert.equal(digest, entry.lfs.sha256, filename);
    else assert.equal(gitBlob.digest('hex'), entry.blobId, filename);
    await rename(sourceRoot + '/' + filename + '.partial', sourceRoot + '/' + filename);
    report.files.push({ filename, bytes, sha256: digest, gitBlobId: entry.blobId, expectedLfsSha256: entry.lfs?.sha256 ?? null, url });
    await writeFile(root + '/source-acquisition.json', JSON.stringify(report, null, 2) + '\n');
    console.log(JSON.stringify({ filename, bytes, sha256: digest, verified: true }));
  }
  report.complete = true;
} catch (error) { report.error = { name: error.name, message: error.message }; process.exitCode = 1; }
finally { await writeFile(root + '/source-acquisition.json', JSON.stringify(report, null, 2) + '\n'); }
