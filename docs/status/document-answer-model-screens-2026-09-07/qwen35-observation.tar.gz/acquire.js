// Restore one pinned catalog artifact into a fresh local diagnostic directory.
import assert from 'node:assert/strict';
import { readFile, writeFile, mkdir, rename } from 'node:fs/promises';
import { createWriteStream } from 'node:fs';
import { pipeline } from 'node:stream/promises';
import { Readable } from 'node:stream';
import { createHash } from 'node:crypto';
import { dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { hash as blake3 } from '/home/clocksmith/deco/reploid/node_modules/doppler-gpu/src/storage/blake3.js';
const root = dirname(fileURLToPath(import.meta.url));
const modelId = 'qwen-3-5-2b-q4k-ehaf16';
const catalog = JSON.parse(await readFile('/home/clocksmith/deco/doppler/models/catalog.json', 'utf8'));
const entry = catalog.models.find(row => row.modelId === modelId);
assert.equal(entry.hf.revision, '977d145bf2478a7fb542e6aca65030585620ca60');
const baseUrl = `https://huggingface.co/${entry.hf.repoId}/resolve/${entry.hf.revision}/${entry.hf.path}/`;
const modelRoot = root + '/model';
await mkdir(modelRoot);
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const report = { schema: 'reploid.pinned-model-acquisition/v1', modelId, catalogEntry: entry,
  baseUrl, startedAt: new Date().toISOString(), files: [], failures: [], complete: false };
const retain = () => writeFile(root + '/acquisition.json', JSON.stringify(report, null, 2) + '\n');
async function acquire(filename, expected = null) {
  assert(/^[a-zA-Z0-9_.-]+$/.test(filename) && !filename.includes('..'));
  const url = new URL(filename, baseUrl).href;
  const path = modelRoot + '/' + filename;
  for (let attempt = 1; attempt <= 3; attempt++) {
    const partial = path + `.attempt-${attempt}.partial`;
    try {
      const response = await fetch(url, { signal: AbortSignal.timeout(180000) });
      assert(response.ok, `${filename}: HTTP ${response.status}`);
      await pipeline(Readable.fromWeb(response.body), createWriteStream(partial, { flags: 'wx' }));
      const bytes = await readFile(partial);
      let commitment = null;
      if (expected) {
        assert.equal(bytes.length, expected.size, filename);
        commitment = Buffer.from(await blake3(bytes)).toString('hex');
        assert.equal(commitment, expected.blake3, filename);
      }
      const row = { filename, bytes: bytes.length, sha256: sha(bytes), blake3: commitment, url, attempt };
      await rename(partial, path);
      report.files.push(row);
      await retain();
      console.log(JSON.stringify(row));
      return bytes;
    } catch (error) {
      report.failures.push({ filename, attempt, message: error.message });
      await retain();
      if (attempt === 3) throw error;
    }
  }
}
try {
  const bytes = await acquire('manifest.json');
  report.manifest = report.files.pop();
  const manifest = JSON.parse(bytes);
  assert.equal(manifest.modelId, modelId);
  const queue = [...manifest.shards];
  await Promise.all(Array.from({ length: 3 }, async () => {
    while (queue.length) { const shard = queue.shift(); await acquire(shard.filename, shard); }
  }));
  await acquire('tokenizer.json');
  await acquire('origin.json');
  report.complete = true;
} catch (error) { report.error = { name: error.name, message: error.message }; process.exitCode = 1; }
finally { await retain(); }
