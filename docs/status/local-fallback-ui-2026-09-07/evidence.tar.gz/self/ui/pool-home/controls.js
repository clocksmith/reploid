/**
 * @fileoverview Route control bindings for the Reploid product home.
 */

import { createDopplerRuntime } from '../../pool/doppler-runtime.js';
import { createLocalPackExecutor } from '../../pool/local-pack-executor.js';
import { createPackOperationRegistry } from '../../pool/pack-operation-adapters.js';
import { hashDopplerEvidence } from '../../pool/executable-pack.js';
import { createProviderClient } from '../../pool/provider-client.js';
import { adapterRequirementFromPublication } from '../../pool/adapter-publication.js';
import {
  createPublishedAdapterOriginFetcher,
  listFetchableAdapterPublications,
  resolveFetchableAdapterPublication
} from '../../pool/adapter-registry.js';
import { buildModelArtifactUrls, verifyModelArtifactManifest } from '../../pool/model-artifacts.js';
import { createRequesterClient } from '../../pool/requester-client.js';
import {
  LAUNCH_MODEL,
  POOLDAY_MODEL_WORKLOADS,
  buildLaunchProviderModel,
  getEnabledPoolModelContract,
  getPoolModelWorkload,
  listPoolModels,
  validateModelRuntimeCapabilities
} from '../../pool/model-contract.js';
import { createPoolIdentity } from '../../pool/identity.js';
import {
  PARTICIPATION_MODES,
  readParticipationPreferences,
  writeParticipationPreferences
} from '../../pool/participation-profile.js';
import { FASTEST_RECEIPT_POLICY_ID, listPolicies } from '../../pool/policy-router.js';
import { createPeerProviderNode, runPeerJob } from '../../pool/peer-room.js';
import { createPoolSdk, verifyReceiptRecord } from '../../pool/sdk.js';
import { getPoolRtcConfig } from '../../pool/rtc-config.js';
import {
  SEQUENCE_ALPHABETS,
  SEQUENCE_PUBLIC_SENSITIVITY,
  getMaxPublicSequenceLength,
  normalizeSequenceInput,
  isSequenceWorkload
} from '../../pool/sequence-workload.js';
import {
  createSignedResearchResult,
  createSignedResearchSubmission
} from '../../pool/evidence-network.js';
import {
  addReceiptLedgerRow,
  clearPoolRoomDraft,
  describeSelectedRun,
  findReceiptLedgerRecord,
  getPeerDiscoveryWindowMs,
  getPeerGenerationConfig,
  getPeerInviteUrl,
  getPeerQueueWindowMs,
  getPeerReceiptWindowMs,
  getPeerRelayMode,
  getPeerRoomBusFactory,
  getPeerRoomId,
  getPeerSessionAcceptWindowMs,
  getPeerTransportConnectWindowMs,
  refreshContributionStatusBar,
  refreshProviderStorageHealth,
  refreshRecordTimelineState,
  refreshRoomActivityState,
  recordPeerLedgerEvents,
  restorePoolRecordDisclosures,
  renderReceiptLedger,
  setPoolRecordDisclosureOpen,
  setPoolRecordFacet,
  setPoolRunVisualState,
  setResearchPublicationStatus,
  setResult,
  updateProviderHealth,
  updateProviderNotice,
  updateProviderStatus
} from './view.js';
import {
  recordContributionReceipt,
  updateContributionState
} from './contribution-state.js';
import { choosePooldayAskPlaceholderForLane } from './constants.js';
import { publishResearchRecord } from './research-store.js';

const errorString = (error) => String(error?.message || error?.error || error || 'Unknown error');
const POOL_ROOM_ACTIVITY_POLL_MS = 5000;
const POOL_ADAPTER_DISCOVERY_TIMEOUT_MS = 5000;
const POOL_SEQUENCE_PUBLIC_CONSENT_KEY = 'reploid.pool.sequence-public-consent.v1';
export const POOL_CONTRIBUTION_RESUME_STORAGE_KEY = 'reploid.pool.contribution-resume.v1';
export const POOL_PENDING_REQUEST_STORAGE_KEY = 'reploid.pool.pending-request.v1';
const POOL_PENDING_REQUEST_VERSION = 1;
const POOL_PENDING_REQUEST_TTL_MS = 15 * 60 * 1000;
const POOL_PROVIDER_ACTIVITY_HISTORY_LIMIT = 64;
const policyGuaranteesIndependentExecution = (policy = {}) => (
  Number(policy.redundancy || 0) >= 2
  || Number(policy.minRingSize || 0) >= 2
);

const readContributionResumeIntent = () => {
  try {
    const parsed = JSON.parse(window.sessionStorage?.getItem(POOL_CONTRIBUTION_RESUME_STORAGE_KEY) || 'null');
    return parsed?.active === true ? parsed : null;
  } catch {
    try {
      window.sessionStorage?.removeItem(POOL_CONTRIBUTION_RESUME_STORAGE_KEY);
    } catch {
      // A malformed recovery record must not prevent the current page from loading.
    }
    return null;
  }
};

const writeContributionResumeIntent = ({ modelId } = {}) => {
  const intent = {
    active: true,
    modelId: modelId || LAUNCH_MODEL.modelId,
    roomId: getPeerRoomId(),
    relay: getPeerRelayMode(),
    updatedAt: new Date().toISOString()
  };
  try {
    window.sessionStorage?.setItem(POOL_CONTRIBUTION_RESUME_STORAGE_KEY, JSON.stringify(intent));
  } catch {
    // The current provider session remains active when persistence is unavailable.
  }
  return intent;
};

const clearContributionResumeIntent = () => {
  try {
    window.sessionStorage?.removeItem(POOL_CONTRIBUTION_RESUME_STORAGE_KEY);
  } catch {
    // The current provider session still stops when persistence is unavailable.
  }
};

const pendingRequestIsRecoverable = (record, { navigationType = pageIdentityNavigationType() } = {}) => {
  if (!record || typeof record !== 'object') return false;
  if (navigationType !== 'reload' && navigationType !== 'back_forward') return false;
  if (record.version !== POOL_PENDING_REQUEST_VERSION || record.lane !== 'sequence') return false;
  if (record.sensitivity !== SEQUENCE_PUBLIC_SENSITIVITY || typeof record.sequence !== 'string' || !record.sequence.trim()) return false;
  if (record.roomId !== getPeerRoomId() || record.relay !== getPeerRelayMode()) return false;
  const startedAt = Date.parse(record.startedAt || '');
  return Number.isFinite(startedAt) && Date.now() - startedAt >= 0 && Date.now() - startedAt <= POOL_PENDING_REQUEST_TTL_MS;
};

const readPendingRequestRecovery = () => {
  try {
    const record = JSON.parse(window.sessionStorage?.getItem(POOL_PENDING_REQUEST_STORAGE_KEY) || 'null');
    if (pendingRequestIsRecoverable(record)) return record;
    window.sessionStorage?.removeItem(POOL_PENDING_REQUEST_STORAGE_KEY);
  } catch {
    try {
      window.sessionStorage?.removeItem(POOL_PENDING_REQUEST_STORAGE_KEY);
    } catch {
      // A malformed recovery record must not prevent the current page from loading.
    }
  }
  return null;
};

const writePendingRequestRecovery = (request) => {
  if (
    request?.lane !== 'sequence'
    || request?.sequenceRequest?.sensitivity !== SEQUENCE_PUBLIC_SENSITIVITY
    || typeof request.sequence !== 'string'
    || !request.sequence.trim()
  ) return;
  const record = {
    version: POOL_PENDING_REQUEST_VERSION,
    lane: 'sequence',
    sequence: request.sequence,
    selectedModelId: request.selectedModel?.modelId || null,
    policyId: request.policyId || FASTEST_RECEIPT_POLICY_ID,
    researchSubmission: request.researchSubmission || null,
    roomId: getPeerRoomId(),
    relay: getPeerRelayMode(),
    sensitivity: SEQUENCE_PUBLIC_SENSITIVITY,
    startedAt: new Date().toISOString()
  };
  try {
    window.sessionStorage?.setItem(POOL_PENDING_REQUEST_STORAGE_KEY, JSON.stringify(record));
  } catch {
    // The current run continues, but a reload cannot offer restoration.
  }
};

const clearPendingRequestRecovery = () => {
  try {
    window.sessionStorage?.removeItem(POOL_PENDING_REQUEST_STORAGE_KEY);
  } catch {
    // The in-memory request state remains valid for the current page.
  }
};

const readSequencePublicConsent = () => {
  try {
    return window.localStorage?.getItem(POOL_SEQUENCE_PUBLIC_CONSENT_KEY) === 'true';
  } catch {
    return false;
  }
};

const writeSequencePublicConsent = () => {
  try {
    window.localStorage?.setItem(POOL_SEQUENCE_PUBLIC_CONSENT_KEY, 'true');
  } catch {
    // Consent still applies to the current page when storage is unavailable.
  }
};

const syncSequencePublicConsent = (control) => {
  if (!control) return;
  if (readSequencePublicConsent()) control.checked = true;
  const acknowledged = control.checked === true;
  const row = control.closest('[data-pool-sequence-consent-row]');
  const saved = document.querySelector('[data-pool-sequence-consent-saved]');
  if (row) row.hidden = acknowledged;
  if (saved) saved.hidden = !acknowledged;
};

const withTimeout = (promise, timeoutMs, message) => new Promise((resolve, reject) => {
  const timer = setTimeout(() => reject(new Error(message)), timeoutMs);
  Promise.resolve(promise).then(
    (value) => {
      clearTimeout(timer);
      resolve(value);
    },
    (error) => {
      clearTimeout(timer);
      reject(error);
    }
  );
});

const displayPoolError = (error, {
  title = 'Request failed',
  action = 'Check the details below, then try the operation again.',
  context = {}
} = {}) => ({
  status: 'error',
  error: title,
  reason: errorString(error),
  code: error?.code || error?.payload?.code || null,
  retryable: error?.retryable ?? error?.payload?.retryable ?? null,
  action: error?.payload?.action || error?.action || action,
  transportDiagnostics: error?.diagnostics || error?.payload?.diagnostics || null,
  ...context,
  payload: error?.payload || null
});

const artifactPreflightFailureAction = (model) => (
  `Deploy ${model?.modelId || 'the selected model'} artifacts at the configured model base, or attach a compatible Doppler runtime handle before contributing.`
);

const usesRegistryBackedDopplerLoad = (model = {}) => (
  Boolean(model.dopplerLoadRef || model.registryId || model.loadRef)
);

const supportsAdapterPublications = () => false;

const formatDeviceLabel = (deviceInfo = {}) => {
  const adapter = deviceInfo.adapterInfo || {};
  return [
    adapter.vendor,
    adapter.architecture,
    adapter.device
  ].filter(Boolean).join(' / ') || deviceInfo.probeStatus || 'unknown';
};

const pageIdentityNavigationType = (performanceRef = globalThis.performance) => {
  try {
    return performanceRef?.getEntriesByType?.('navigation')?.[0]?.type || null;
  } catch {
    return null;
  }
};

export const getPageIdentityNamespace = (globalKey, {
  windowRef = window,
  navigationType = pageIdentityNavigationType()
} = {}) => {
  if (windowRef[globalKey]) return windowRef[globalKey];
  const storageKey = `reploid.pool.page-identity.${globalKey}`;
  try {
    const stored = windowRef.sessionStorage?.getItem(storageKey);
    // sessionStorage is copied when a tab is duplicated or opened by an
    // opener. Restore only after a reload/history traversal so a copied tab
    // cannot impersonate the source tab's ephemeral role namespace.
    if (stored && (navigationType === 'reload' || navigationType === 'back_forward')) {
      windowRef[globalKey] = stored;
      return stored;
    }
  } catch {
    // A memory-only identity namespace remains valid for the current page.
  }
  const id = windowRef.crypto?.randomUUID
    ? windowRef.crypto.randomUUID()
    : `${Date.now().toString(36)}_${Math.random().toString(36).slice(2)}`;
  windowRef[globalKey] = `page_${id}`;
  try {
    windowRef.sessionStorage?.setItem(storageKey, windowRef[globalKey]);
  } catch {
    // A memory-only identity namespace remains valid for the current page.
  }
  return windowRef[globalKey];
};

const getProviderIdentityNamespace = () => getPageIdentityNamespace('REPLOID_POOL_PROVIDER_NAMESPACE');
const getRequesterIdentityNamespace = () => getPageIdentityNamespace('REPLOID_POOL_REQUESTER_NAMESPACE');
const participationIdentity = createPoolIdentity('requester', {
  localOnly: true,
  namespace: 'network_participation'
});

const canRequestWith = (preferences) => (
  preferences.mode === PARTICIPATION_MODES.request || preferences.mode === PARTICIPATION_MODES.both
);
const canContributeWith = (preferences) => (
  preferences.mode === PARTICIPATION_MODES.contribute || preferences.mode === PARTICIPATION_MODES.both
);

const requestControlAvailability = new WeakMap();

const setRequestControlParticipation = (control, canRequest) => {
  if (!canRequest) {
    if (!requestControlAvailability.has(control)) {
      requestControlAvailability.set(control, control.disabled);
    }
    control.disabled = true;
    return;
  }
  if (!requestControlAvailability.has(control)) return;
  control.disabled = requestControlAvailability.get(control);
  requestControlAvailability.delete(control);
};

const shortIdentity = (identity = {}) => {
  const value = String(identity.identityRootId || identity.deviceId || '');
  const fingerprint = value.replace(/^[^_]+_/, '');
  return fingerprint ? `ID ${fingerprint.slice(0, 6)}…${fingerprint.slice(-4)}` : 'Identity unavailable';
};

export const refreshParticipationControls = async (preferences = readParticipationPreferences()) => {
  const canRequest = canRequestWith(preferences);
  const canContribute = canContributeWith(preferences);
  document.documentElement.dataset.poolParticipationMode = preferences.mode;
  document.body.dataset.poolParticipationMode = preferences.mode;
  document.querySelectorAll('[data-pool-participation]').forEach((surface) => {
    surface.dataset.participationMode = preferences.mode;
  });
  document.querySelectorAll('[data-pool-participation-mode]').forEach((button) => {
    const active = button.dataset.poolParticipationMode === preferences.mode;
    button.classList.toggle('is-active', active);
    button.setAttribute('aria-pressed', String(active));
  });
  document.querySelectorAll('[data-pool-request-control], [data-pool-run-surface="run"] input, [data-pool-run-surface="run"] textarea, [data-pool-run-surface="run"] select, [data-pool-run-surface="run"] button').forEach((control) => {
    if (control.closest('[data-pool-participation]')) return;
    setRequestControlParticipation(control, canRequest);
  });
  document.querySelectorAll('.pool-home-ask-dock').forEach((form) => {
    form.hidden = Boolean(form.closest('.pool-home-task')?.querySelector('[data-pool-workflow="documents"][aria-pressed="true"]'));
  });
  document.querySelectorAll('.pool-home-share-toggle').forEach((button) => {
    button.hidden = !canContribute;
  });
  const connectionSummary = document.querySelector('[data-pool-drawer-summary="network-connection"]');
  if (connectionSummary) {
    const modeLabel = preferences.mode === PARTICIPATION_MODES.both
      ? 'Both'
      : preferences.mode === PARTICIPATION_MODES.contribute
        ? 'Contribute'
        : 'Request';
    connectionSummary.textContent = `${getPeerRoomId()} · ${modeLabel}`;
  }
  try {
    const identity = await participationIdentity.getDeviceIdentity();
    document.querySelectorAll('[data-pool-device-identity]').forEach((element) => {
      element.textContent = shortIdentity(identity);
      element.dataset.identityProtection = identity.keyProtection;
      element.title = identity.keyProtection === 'passkey'
        ? 'Passkey-bound device identity'
        : identity.keyProtection === 'browser_non_exportable'
          ? 'Non-exportable browser device key'
          : 'Browser identity fallback; use a passkey for stronger protection';
    });
    document.querySelectorAll('[data-pool-passkey]').forEach((button) => {
      button.disabled = identity.keyProtection === 'passkey';
      button.textContent = identity.keyProtection === 'passkey'
        ? 'Passkey protected'
        : 'Protect identity with passkey';
    });
  } catch (error) {
    document.querySelectorAll('[data-pool-device-identity]').forEach((element) => {
      element.textContent = 'Identity unavailable';
      element.title = errorString(error);
    });
  }
  return preferences;
};

const updateParticipationPreference = async (nextPreferences) => {
  const previous = readParticipationPreferences();
  const next = writeParticipationPreferences(nextPreferences);
  await getProviderContributionController().applyParticipationPreferences(previous, next);
  await refreshParticipationControls(next);
  return next;
};

export const bindParticipationControls = () => {
  document.querySelectorAll('[data-pool-participation-mode]').forEach((button) => {
    if (button.dataset.poolParticipationBound === 'true') return;
    button.dataset.poolParticipationBound = 'true';
    button.addEventListener('click', () => {
      void updateParticipationPreference({
        ...readParticipationPreferences(),
        mode: button.dataset.poolParticipationMode
      });
    });
  });
  document.querySelectorAll('[data-pool-permission], [data-pool-limit]').forEach((control) => {
    if (control.dataset.poolParticipationBound === 'true') return;
    control.dataset.poolParticipationBound = 'true';
    control.addEventListener('change', () => {
      const current = readParticipationPreferences();
      const permissions = { ...current.permissions };
      const limits = { ...current.limits };
      if (control.dataset.poolPermission) permissions[control.dataset.poolPermission] = control.checked;
      if (control.dataset.poolLimit) {
        limits[control.dataset.poolLimit] = control.type === 'checkbox'
          ? control.checked
          : Number(control.value);
      }
      void updateParticipationPreference({ ...current, permissions, limits });
    });
  });
  document.querySelectorAll('[data-pool-passkey]').forEach((button) => {
    if (button.dataset.poolPasskeyBound === 'true') return;
    button.dataset.poolPasskeyBound = 'true';
    button.addEventListener('click', async () => {
      const status = button.closest('[data-pool-participation]')?.querySelector('[data-pool-passkey-status]');
      button.disabled = true;
      if (status) status.textContent = 'Waiting for passkey';
      try {
        await participationIdentity.enrollPasskey();
        if (status) status.textContent = 'Passkey bound to this device identity.';
      } catch (error) {
        if (status) status.textContent = errorString(error);
      } finally {
        await refreshParticipationControls();
      }
    });
  });
  void refreshParticipationControls();
};

export const POOL_DEVICE_CAPABILITY_TIERS = Object.freeze({
  basic: Object.freeze({ id: 'basic', label: 'Basic', minScore: 1, maxConcurrentJobs: 1, maxTokensPerJob: 64 }),
  standard: Object.freeze({ id: 'standard', label: 'Standard', minScore: 40, maxConcurrentJobs: 1, maxTokensPerJob: 128 }),
  advanced: Object.freeze({ id: 'advanced', label: 'Advanced', minScore: 65, maxConcurrentJobs: 2, maxTokensPerJob: 256 }),
  high: Object.freeze({ id: 'high', label: 'High capacity', minScore: 85, maxConcurrentJobs: 3, maxTokensPerJob: 512 })
});

const bytesToMiB = (value) => Number(value || 0) / (1024 * 1024);
const median = (values = []) => {
  const sorted = values.filter(Number.isFinite).sort((left, right) => left - right);
  if (!sorted.length) return null;
  const middle = Math.floor(sorted.length / 2);
  return sorted.length % 2 ? sorted[middle] : (sorted[middle - 1] + sorted[middle]) / 2;
};

const capabilityTierForScore = (score, measured) => {
  if (!measured || score < POOL_DEVICE_CAPABILITY_TIERS.standard.minScore) {
    return POOL_DEVICE_CAPABILITY_TIERS.basic;
  }
  if (score >= POOL_DEVICE_CAPABILITY_TIERS.high.minScore) return POOL_DEVICE_CAPABILITY_TIERS.high;
  if (score >= POOL_DEVICE_CAPABILITY_TIERS.advanced.minScore) return POOL_DEVICE_CAPABILITY_TIERS.advanced;
  return POOL_DEVICE_CAPABILITY_TIERS.standard;
};

export const scorePoolDeviceCapability = ({ deviceInfo = {}, benchmark = {} } = {}) => {
  if (deviceInfo.hasWebGPU !== true) {
    return Object.freeze({
      supported: false,
      score: 0,
      tier: Object.freeze({ id: 'unsupported', label: 'Request only', maxConcurrentJobs: 0, maxTokensPerJob: 0 }),
      measured: false,
      summary: 'WebGPU is unavailable. This browser can request work but cannot advertise local model execution.'
    });
  }
  const limits = deviceInfo.limits || {};
  const maxBufferMiB = bytesToMiB(deviceInfo.maxBufferSize || limits.maxBufferSize);
  const storageMiB = bytesToMiB(limits.maxStorageBufferBindingSize);
  const workgroupSize = Number(limits.maxComputeInvocationsPerWorkgroup || limits.maxComputeWorkgroupSizeX || 0);
  const gigaOpsPerSecond = Number(benchmark.gigaOpsPerSecond || 0);
  const stability = Number(benchmark.stability || 0);
  const measured = benchmark.status === 'measured' && gigaOpsPerSecond > 0;
  let score = 20;
  score += maxBufferMiB >= 512 ? 20 : maxBufferMiB >= 256 ? 16 : maxBufferMiB >= 128 ? 12 : maxBufferMiB >= 64 ? 8 : 3;
  score += storageMiB >= 256 ? 15 : storageMiB >= 128 ? 12 : storageMiB >= 64 ? 8 : storageMiB >= 32 ? 5 : 2;
  score += workgroupSize >= 256 ? 5 : workgroupSize >= 128 ? 3 : 1;
  score += deviceInfo.hasF16 || deviceInfo.features?.includes?.('shader-f16') ? 10 : 0;
  score += deviceInfo.hasSubgroups || deviceInfo.features?.includes?.('subgroups') ? 5 : 0;
  score += gigaOpsPerSecond >= 100 ? 20 : gigaOpsPerSecond >= 40 ? 16 : gigaOpsPerSecond >= 12 ? 11 : gigaOpsPerSecond > 0 ? 6 : 0;
  score += stability >= 0.85 ? 5 : stability >= 0.65 ? 3 : stability > 0 ? 1 : 0;
  score = Math.min(100, Math.round(measured ? score : Math.min(score, 39)));
  const tier = capabilityTierForScore(score, measured);
  return Object.freeze({
    supported: true,
    measured,
    score,
    tier,
    maxBufferMiB,
    storageMiB,
    workgroupSize,
    gigaOpsPerSecond,
    stability,
    summary: measured
      ? `${tier.label} browser compute based on observed WebGPU limits and a bounded local kernel.`
      : 'WebGPU is present, but the bounded kernel did not produce a stable measurement. Contribution stays conservative.'
  });
};

export const resolveCapabilityAvailabilityLimits = (participation = {}, capabilityProfile = {}) => ({
  maxConcurrentJobs: Math.min(
    Math.max(1, Number(participation.limits?.maxConcurrentJobs || 1)),
    Math.max(0, Number(capabilityProfile.tier?.maxConcurrentJobs || 0))
  ),
  maxTokensPerJob: Math.min(
    Math.max(16, Number(participation.limits?.maxTokensPerJob || 16)),
    Math.max(0, Number(capabilityProfile.tier?.maxTokensPerJob || 0))
  )
});

const runBoundedWebGpuProbe = async () => {
  const gpu = globalThis.navigator?.gpu;
  if (!gpu?.requestAdapter) return { status: 'unavailable', samplesMs: [] };
  const usage = globalThis.GPUBufferUsage;
  if (!usage) return { status: 'unavailable', samplesMs: [] };
  let device = null;
  try {
    const adapter = await gpu.requestAdapter({ powerPreference: 'high-performance' });
    if (!adapter) return { status: 'adapter_unavailable', samplesMs: [] };
    device = await adapter.requestDevice();
    const elementCount = 65_536;
    const iterations = 64;
    const buffer = device.createBuffer({
      size: elementCount * 4,
      usage: usage.STORAGE
    });
    const shader = device.createShaderModule({ code: `
      @group(0) @binding(0) var<storage, read_write> values: array<f32>;
      @compute @workgroup_size(256)
      fn main(@builtin(global_invocation_id) id: vec3<u32>) {
        if (id.x >= ${elementCount}u) { return; }
        var value = f32(id.x % 251u) * 0.001;
        for (var index = 0u; index < ${iterations}u; index = index + 1u) {
          value = value * 1.000001 + f32(index & 7u) * 0.000001;
        }
        values[id.x] = value;
      }
    ` });
    const pipeline = device.createComputePipeline({
      layout: 'auto',
      compute: { module: shader, entryPoint: 'main' }
    });
    const bindGroup = device.createBindGroup({
      layout: pipeline.getBindGroupLayout(0),
      entries: [{ binding: 0, resource: { buffer } }]
    });
    const submit = async () => {
      const encoder = device.createCommandEncoder();
      const pass = encoder.beginComputePass();
      pass.setPipeline(pipeline);
      pass.setBindGroup(0, bindGroup);
      pass.dispatchWorkgroups(Math.ceil(elementCount / 256));
      pass.end();
      const started = performance.now();
      device.queue.submit([encoder.finish()]);
      await device.queue.onSubmittedWorkDone();
      return performance.now() - started;
    };
    await submit();
    const samplesMs = [];
    for (let index = 0; index < 5; index += 1) samplesMs.push(await submit());
    const medianMs = median(samplesMs);
    const operations = elementCount * iterations * 2;
    const gigaOpsPerSecond = medianMs > 0 ? operations / (medianMs / 1000) / 1e9 : 0;
    const stability = samplesMs.length > 1
      ? Math.min(...samplesMs) / Math.max(...samplesMs)
      : 1;
    buffer.destroy?.();
    return { status: 'measured', samplesMs, medianMs, gigaOpsPerSecond, stability };
  } catch (error) {
    return { status: 'failed', samplesMs: [], error: errorString(error) };
  } finally {
    device?.destroy?.();
  }
};

let capabilityAssessmentPromise = null;

export const resetPoolDeviceCapabilityForTests = () => {
  capabilityAssessmentPromise = null;
  delete window.REPLOID_POOL_DEVICE_CAPABILITY;
};

export const assessPoolDeviceCapability = async ({ runtime = null, force = false } = {}) => {
  if (capabilityAssessmentPromise && !force) return capabilityAssessmentPromise;
  capabilityAssessmentPromise = (async () => {
    const activeRuntime = runtime || window.REPLOID_DOPPLER_RUNTIME || createDopplerRuntime();
    const deviceInfo = typeof activeRuntime?.getDeviceInfo === 'function'
      ? await activeRuntime.getDeviceInfo()
      : { hasWebGPU: !!navigator.gpu, features: [], limits: {} };
    const benchmark = deviceInfo.capabilityBenchmark && typeof deviceInfo.capabilityBenchmark === 'object'
      ? deviceInfo.capabilityBenchmark
      : deviceInfo.hasWebGPU
        ? await runBoundedWebGpuProbe()
        : { status: 'unavailable', samplesMs: [] };
    const scored = scorePoolDeviceCapability({ deviceInfo, benchmark });
    const modelEligibility = listPoolModels({ enabledOnly: true }).map((model) => {
      const qualification = validateModelRuntimeCapabilities(model, deviceInfo);
      const minimumScore = Number(model.browserCapability?.minimumScore ?? 40);
      const scoreQualified = scored.score >= minimumScore;
      return {
        modelId: model.modelId,
        label: model.label || model.modelId,
        eligible: scored.supported && qualification.ok && scoreQualified,
        minimumScore,
        minimumTier: model.browserCapability?.minimumTier || 'standard',
        reasons: [
          ...qualification.reasons,
          ...(!scoreQualified ? [`device capability score ${scored.score} is below required score ${minimumScore}`] : [])
        ]
      };
    });
    const profile = Object.freeze({
      schema: 'reploid.pool.device-capability/v1',
      measuredAt: new Date().toISOString(),
      deviceInfo,
      benchmark,
      ...scored,
      modelEligibility
    });
    window.REPLOID_POOL_DEVICE_CAPABILITY = profile;
    window.dispatchEvent(new CustomEvent('reploid:pool-device-capability', { detail: profile }));
    return profile;
  })();
  return capabilityAssessmentPromise;
};

const formatMetric = (value, suffix, digits = 0) => (
  Number.isFinite(Number(value)) ? `${Number(value).toFixed(digits)}${suffix}` : '--'
);

const renderCapabilityProfileState = (root, profile) => {
  if (!root || !profile) return;
  root.dataset.capabilityState = profile.supported ? 'ready' : 'unsupported';
  const setText = (selector, value) => {
    const element = root.querySelector(selector);
    if (element) element.textContent = value;
  };
  setText('[data-pool-capability-tier]', profile.tier.label);
  setText('[data-pool-capability-score]', profile.supported ? `${profile.score}/100` : 'N/A');
  setText('[data-pool-capability-summary]', profile.summary);
  setText('[data-pool-capability-webgpu]', profile.supported ? 'Available' : 'Unavailable');
  setText('[data-pool-capability-buffer]', formatMetric(profile.maxBufferMiB, ' MiB'));
  setText('[data-pool-capability-kernel]', profile.measured ? formatMetric(profile.gigaOpsPerSecond, ' GOPS', 1) : 'Not measured');
  setText('[data-pool-capability-stability]', profile.measured ? `${Math.round(profile.stability * 100)}%` : '--');
  const meter = root.querySelector('[data-pool-capability-meter]');
  if (meter) meter.style.width = `${profile.score}%`;
  const models = root.querySelector('[data-pool-capability-models]');
  if (models) {
    models.replaceChildren();
    const eligible = profile.modelEligibility.filter((model) => model.eligible);
    const rows = eligible.length ? eligible : [{ label: 'Request from another contributor', eligible: false }];
    for (const model of rows) {
      const item = document.createElement('span');
      item.dataset.eligible = String(Boolean(model.eligible));
      item.textContent = model.label;
      models.append(item);
    }
  }
  const providerModel = document.getElementById('pool-provider-model');
  if (providerModel) {
    const previousModelId = providerModel.value;
    for (const option of providerModel.options) {
      const eligibility = profile.modelEligibility.find((entry) => entry.modelId === option.value);
      option.disabled = eligibility ? !eligibility.eligible : true;
      option.title = eligibility?.eligible
        ? `Qualified at ${profile.tier.label}`
        : eligibility?.reasons?.join('; ') || 'Not qualified by this device profile';
    }
    if (providerModel.selectedOptions[0]?.disabled) {
      const eligibleOption = [...providerModel.options].find((option) => !option.disabled);
      if (eligibleOption) providerModel.value = eligibleOption.value;
    }
    if (providerModel.value !== previousModelId) {
      providerModel.dispatchEvent(new Event('change', { bubbles: true }));
    }
  }
};

export const bindCapabilityAssessmentControls = () => {
  const roots = [...document.querySelectorAll('[data-pool-capability-profile]')];
  if (!roots.length) return;
  const run = async (force = false) => {
    roots.forEach((root) => { root.dataset.capabilityState = 'checking'; });
    const profile = await assessPoolDeviceCapability({ force });
    roots.forEach((root) => renderCapabilityProfileState(root, profile));
  };
  roots.forEach((root) => {
    const rerun = root.querySelector('[data-pool-capability-rerun]');
    if (!rerun || rerun.dataset.poolCapabilityBound === 'true') return;
    rerun.dataset.poolCapabilityBound = 'true';
    rerun.addEventListener('click', () => void run(true));
  });
  void run(false);
};

const setControlDrawerOpen = (open) => {
  const rail = document.querySelector('.pool-control-drawer');
  const toggle = rail?.querySelector('.pool-nav-toggle');
  if (!rail || !toggle) return;
  if (rail.classList.contains('is-open') !== open) {
    toggle.click();
  }
};

const POOL_DRAWER_SECTION_STATE_KEY = 'reploid.pool.drawerSections.v1';

const readDrawerSectionState = () => {
  try {
    const parsed = JSON.parse(globalThis.localStorage?.getItem(POOL_DRAWER_SECTION_STATE_KEY) || '{}');
    return parsed && typeof parsed === 'object' ? parsed : {};
  } catch {
    return {};
  }
};

const writeDrawerSectionState = (state) => {
  try {
    globalThis.localStorage?.setItem(POOL_DRAWER_SECTION_STATE_KEY, JSON.stringify(state));
  } catch {
    // Disclosure remains usable when browser storage is unavailable.
  }
};

const bindDrawerSections = () => {
  const state = readDrawerSectionState();
  document.querySelectorAll('details[data-pool-drawer-section]').forEach((section) => {
    const id = section.dataset.poolDrawerSection;
    if (typeof state[id] === 'boolean') section.open = state[id];
    if (section.dataset.poolDrawerSectionBound === 'true') return;
    section.dataset.poolDrawerSectionBound = 'true';
    section.querySelector(':scope > summary')?.addEventListener('click', (event) => {
      // Clicking a collapsed section expands the single control rail and opens it.
      const rail = section.closest('.pool-nav-rail');
      if (rail && !rail.classList.contains('is-open')) {
        const toggle = rail.querySelector('.pool-nav-toggle');
        toggle?.click();
        section.open = true;
        event.preventDefault();
        return;
      }
      const next = readDrawerSectionState();
      next[id] = !section.open;
      writeDrawerSectionState(next);
    });
    section.addEventListener('toggle', () => {
      const next = readDrawerSectionState();
      next[id] = section.open;
      writeDrawerSectionState(next);
    });
  });
};

export const applyPoolDashboardView = (view = 'home', { updateHistory = true } = {}) => {
  const normalized = ['home', 'ask', 'compute', 'records'].includes(view) ? view : 'home';
  const stage = document.querySelector('.pool-home-stage');
  if (!stage) return normalized;
  stage.dataset.poolDashboardView = normalized;
  document.querySelectorAll('.pool-nav-link[data-pool-dashboard-view]').forEach((control) => {
    const active = control.dataset.poolDashboardView === normalized;
    control.classList.toggle('is-active', active);
    if (active) control.setAttribute('aria-current', 'page');
    else control.removeAttribute('aria-current');
  });
  if (normalized === 'ask') document.getElementById('pool-home-ask-prompt')?.focus();
  if (normalized === 'compute' || normalized === 'records') setControlDrawerOpen(true);
  if (updateHistory) {
    const url = new URL(window.location.href);
    if (normalized === 'home') url.searchParams.delete('view');
    else url.searchParams.set('view', normalized);
    window.history.pushState({ reploidPoolDashboardView: normalized }, '', `${url.pathname}${url.search}`);
  }
  return normalized;
};

export const bindPoolDashboardControls = () => {
  bindDrawerSections();
  document.querySelectorAll('.pool-nav-link[data-pool-dashboard-view], [data-pool-dashboard-view-target]').forEach((control) => {
    if (control.dataset.poolDashboardBound === 'true') return;
    control.dataset.poolDashboardBound = 'true';
    control.addEventListener('click', (event) => {
      event.preventDefault();
      applyPoolDashboardView(control.dataset.poolDashboardView || control.dataset.poolDashboardViewTarget || 'home');
    });
  });
  if (window.REPLOID_POOL_INSPECTOR_ESCAPE_HANDLER) {
    window.removeEventListener('keydown', window.REPLOID_POOL_INSPECTOR_ESCAPE_HANDLER);
    window.REPLOID_POOL_INSPECTOR_ESCAPE_HANDLER = null;
  }
};

const bindSuggestedPromptEditing = (input) => {
  if (!input || input.dataset.poolSuggestedPromptBound === 'true') return;
  input.dataset.poolSuggestedPromptBound = 'true';
  const intervalId = setInterval(() => {
    if (!document.body.contains(input)) {
      clearInterval(intervalId);
      return;
    }
    if (document.activeElement !== input && !input.value.trim()) {
      const lane = document.querySelector('.pool-home-stage')?.dataset.poolLane || 'sequence';
      const nextPrompt = choosePooldayAskPlaceholderForLane(lane);
      input.placeholder = nextPrompt;
      input.dataset.poolSuggestedPrompt = nextPrompt;
    }
  }, 4000);
};

const refreshServerRoomActivity = async (isActive = () => true) => {
  const activity = document.getElementById('pool-room-activity');
  const networkState = document.querySelector('[data-pool-network-state]');
  if (!activity && !networkState) return null;
  if (getPeerRelayMode() === 'local') {
    if (isActive()) refreshRoomActivityState();
    return null;
  }
  try {
    const summary = await createPoolSdk({ authTokenProvider: null }).peerRoomSummary(getPeerRoomId(), { limit: 100 });
    if (isActive()) refreshRoomActivityState(summary);
    return summary;
  } catch (error) {
    if (isActive()) refreshRoomActivityState({ error: errorString(error) });
    return null;
  }
};

export const bindRoomActivityControls = () => {
  window.REPLOID_POOL_ROOM_ACTIVITY_STOP?.();
  if (!document.getElementById('pool-room-activity') && !document.querySelector('[data-pool-network-state]')) return;
  let active = true;
  let refreshing = false;
  const refresh = async () => {
    if (!active || refreshing || document.visibilityState === 'hidden') return;
    refreshing = true;
    try {
      await refreshServerRoomActivity(() => active);
    } finally {
      refreshing = false;
    }
  };
  const intervalId = window.setInterval(() => void refresh(), POOL_ROOM_ACTIVITY_POLL_MS);
  window.REPLOID_POOL_ROOM_ACTIVITY_STOP = () => {
    active = false;
    window.clearInterval(intervalId);
    if (window.REPLOID_POOL_ROOM_ACTIVITY_STOP) window.REPLOID_POOL_ROOM_ACTIVITY_STOP = null;
  };
  void refresh();
};

const probeModelArtifacts = async (model) => {
  if (model.executablePack && window.REPLOID_POOL_STRICT_ARTIFACT_PREFLIGHT !== true) {
    return { ok: true, status: 'capsule_verification_pending', runtime: model.runtime,
      action: 'Doppler verifies the signed Capsule and complete artifact closure during model load.' };
  }
  if (window.REPLOID_POOL_STRICT_ARTIFACT_PREFLIGHT !== true && usesRegistryBackedDopplerLoad(model)) {
    return {
      ok: true,
      status: 'doppler_registry',
      runtime: model.runtime || 'doppler',
      loadRef: model.dopplerLoadRef || model.registryId || model.loadRef,
      action: 'Doppler runtime identity is checked after model load.'
    };
  }
  try {
    return {
      status: 'verified_manifest',
      ...(await verifyModelArtifactManifest({ model }))
    };
  } catch (error) {
    let urls = error.urls || null;
    try {
      urls = urls || buildModelArtifactUrls(model);
    } catch {
      urls = null;
    }
    return {
      ok: false,
      status: 'manifest_unavailable',
      error: errorString(error),
      statusCode: error.status || null,
      retryable: error.retryable === true,
      urls,
      action: artifactPreflightFailureAction(model)
    };
  }
};

const RUN_ACTIVITY_COPY = Object.freeze({
  peer_run_intent_created: 'Request signed',
  peer_provider_discovery_started: 'Finding compatible contributor tabs',
  peer_assignment_planned: 'Contributor tabs matched',
  'relay-publish-retrying': 'Retrying relay publish',
  'relay-poll-failed': 'Relay delayed — retrying',
  'relay-dispatch-retrying': 'Retrying local message delivery',
  'relay-dispatch-recovered': 'Message delivery recovered',
  'relay-circuit-open': 'Relay unavailable — retrying shortly',
  'relay-circuit-half-open': 'Checking relay recovery',
  'relay-circuit-closed': 'Relay connection recovered',
  peer_inference_started: 'Contributor tabs are answering',
  peer_provider_queued: 'Request queued behind existing contributor work',
  peer_provider_execution_started: 'Contributor started this request',
  peer_transport_retrying: 'Retrying through relay transport',
  peer_receipts_received: 'Checking returned receipts',
  peer_agreement_verified: 'Agreement verified',
  peer_run_completed: 'Answer verified',
  peer_run_failed: 'Run needs attention'
});

const adapterOptionLabel = (publication = {}) => String(
  publication.pack?.label
  || publication.pack?.runtimeManifest?.name
  || publication.pack?.packId
  || publication.packHash
  || 'Adapter pack'
);

const createSelectOption = (label, value = '') => {
  const option = document.createElement('option');
  option.value = value;
  option.textContent = label;
  return option;
};

const updateAdapterPickerStatus = (adapterSelect, message, status) => {
  const statusElement = adapterSelect
    ?.closest('[data-pool-home-adapter-picker]')
    ?.querySelector('small[data-pool-adapter-status]');
  if (!statusElement) return;
  statusElement.textContent = String(message || '');
  statusElement.hidden = !message;
  statusElement.dataset.poolAdapterStatus = status || '';
};

const syncComposerAdapterAvailability = (available) => {
  document.querySelectorAll('[data-pool-composer-adapter-lane]').forEach((control) => {
    control.hidden = !available;
  });
};

const leaveUnavailableAdapterLane = () => {
  const stage = document.querySelector('.pool-home-stage');
  if (stage?.dataset.poolLane !== 'adapters') return;
  const textLane = document.querySelector('.pool-lane-chip[data-pool-lane="text"]');
  if (textLane) {
    textLane.click();
    return;
  }
  stage.dataset.poolLane = 'text';
  const adapterPicker = document.querySelector('[data-pool-home-adapter-picker]');
  if (adapterPicker) adapterPicker.hidden = true;
};

const refreshAdapterOptions = async (adapterSelect, model, { allowBaseModel = true } = {}) => {
  if (!adapterSelect || !model) return [];
  const previousValue = adapterSelect.value;
  const requestId = String(Number(adapterSelect.dataset.poolAdapterRequestId || 0) + 1);
  adapterSelect.dataset.poolAdapterRequestId = requestId;
  adapterSelect.disabled = true;
  adapterSelect.replaceChildren(createSelectOption('Loading published packs…'));
  updateAdapterPickerStatus(adapterSelect, 'Checking published model adapters.', 'loading');
  try {
    const publications = await listFetchableAdapterPublications({
      sdk: createPoolSdk(),
      model
    });
    if (adapterSelect.dataset.poolAdapterRequestId !== requestId) return publications;
    adapterSelect.replaceChildren();
    if (allowBaseModel) adapterSelect.append(createSelectOption('Base model only'));
    else adapterSelect.append(createSelectOption('Choose a published adapter pack'));
    for (const publication of publications) {
      adapterSelect.append(createSelectOption(adapterOptionLabel(publication), publication.packHash));
    }
    const previousStillExists = [...adapterSelect.options].some((option) => option.value === previousValue);
    adapterSelect.value = previousStillExists ? previousValue : '';
    adapterSelect.disabled = publications.length === 0 && !allowBaseModel;
    adapterSelect.dataset.poolAdapterStatus = publications.length > 0 ? 'available' : 'empty';
    if (publications.length === 0) {
      leaveUnavailableAdapterLane();
      syncComposerAdapterAvailability(false);
      adapterSelect.options[adapterSelect.options.length - 1].textContent = allowBaseModel
        ? 'Base model only — no published packs for this model'
        : 'No published packs for this model';
      updateAdapterPickerStatus(
        adapterSelect,
        `Adapter execution is supported, but no promoted public pack matches ${model.label || model.modelId}.`,
        'empty'
      );
    } else {
      syncComposerAdapterAvailability(true);
      updateAdapterPickerStatus(
        adapterSelect,
        `${publications.length} promoted pack${publications.length === 1 ? '' : 's'} available for ${model.label || model.modelId}.`,
        'available'
      );
    }
    return publications;
  } catch (error) {
    if (adapterSelect.dataset.poolAdapterRequestId !== requestId) return [];
    adapterSelect.replaceChildren(createSelectOption(
      allowBaseModel ? 'Base model only — adapter registry unavailable' : 'Adapter registry unavailable',
      ''
    ));
    adapterSelect.disabled = !allowBaseModel;
    adapterSelect.dataset.poolAdapterStatus = 'error';
    adapterSelect.dataset.poolAdapterError = errorString(error);
    leaveUnavailableAdapterLane();
    syncComposerAdapterAvailability(false);
    updateAdapterPickerStatus(
      adapterSelect,
      `The adapter publication registry is unavailable: ${errorString(error)}`,
      'error'
    );
    return [];
  }
};

const resolveSelectedAdapter = async (adapterSelect, model, { required = false } = {}) => {
  const packHash = String(adapterSelect?.value || '').trim();
  if (!packHash) {
    if (required) throw new Error('Select a published adapter pack before running the adapter lane');
    return null;
  }
  const publication = await resolveFetchableAdapterPublication({
    sdk: createPoolSdk(),
    packHash,
    model
  });
  return adapterRequirementFromPublication(publication, { state: 'fetchable' });
};

const bindPeerRunSurface = ({
  button,
  prompt,
  form = null,
  policySelect = null,
  modelSelect = null,
  adapterSelect = null,
  adapterRequired = () => false,
  sequencePublicControl = null,
  researchPublicControl = null,
  intentKindControl = null,
  intentLabelControl = null,
  intentTextControl = null,
  intentConditionsControl = null,
  intentObservationControl = null,
  intentDecisionControl = null,
  intentScopeControl = null,
  intentExclusionsControl = null,
  intentUnknownsControl = null,
  resultId
} = {}) => {
  if (!button || !prompt || !resultId || button.dataset.poolRunBound === 'true') return;
  button.dataset.poolRunBound = 'true';
  const requesterIdentity = createPoolIdentity('requester', {
    localOnly: true,
    namespace: getRequesterIdentityNamespace()
  });
  const researchIdentity = createPoolIdentity('requester');
  const requesterClient = createRequesterClient({
    sdk: null,
    identity: requesterIdentity
  });
  const rtcSdk = createPoolSdk();
  const recoveryElement = document.getElementById(`${resultId}-recovery`);
  let pendingRequest = null;
  let pendingErrorResult = null;
  let requestInFlight = false;
  let disposed = false;
  let localExecutor = null;
  let runActivityGeneration = 0;
  const updateRunState = (state, phase = '', message = '') => {
    setPoolRunVisualState({ state, phase, message });
  };
  const handleRunActivity = (activity = {}) => {
    updateRunState(
      'running',
      activity.phase || '',
      RUN_ACTIVITY_COPY[activity.status] || 'Running on the network'
    );
  };

  const recoveryCodeOf = (error) => error?.code || error?.payload?.code || null;
  const canOfferLocalFallback = (error) => [
    'peer_provider_not_found',
    'peer_provider_model_mismatch',
    'peer_provider_unresponsive'
  ].includes(recoveryCodeOf(error));
  const modelLabelOf = (model = {}) => model.label || model.name || model.modelId || 'the selected model';
  const supportsLocalRequest = (request) => request?.policyId === FASTEST_RECEIPT_POLICY_ID
    && !request.researchSubmission && !request.adapterPackHash
    && request.selectedModel?.executablePack?.requiredOperation === 'encodeSequence';
  const buildMissingProviderRecovery = (request) => ({
    kind: 'provider_missing',
    title: 'No matching browser is ready',
    message: `No contributor in "${getPeerRoomId()}" is currently advertising ${modelLabelOf(request.selectedModel)}.${supportsLocalRequest(request) ? ' Run here without sharing compute, or keep searching.' : ' The selected checks require a matching contributor; local execution cannot replace them.'}`,
    actions: [
      {
        id: 'retry_network',
        label: 'Keep searching',
        primary: true
      },
      ...(supportsLocalRequest(request) ? [{
        id: 'offer_local_provider',
        label: 'Run on this device'
      }] : []),
      {
        id: 'invite_contributor',
        label: 'Invite a contributor',
        href: getPeerInviteUrl()
      }
    ]
  });
  const buildLocalConsentRecovery = (request) => ({
    kind: 'local_provider_consent',
    title: 'Run on this device?',
    message: `${modelLabelOf(request.selectedModel)} may need to download before this browser can answer the preserved request.`,
    details: [
      'Uses WebGPU and browser storage after a capability check.',
      'Runs only your request. Does not advertise this tab or change Share compute.',
      'Verifies the signed model and local execution receipt; does not claim independent peer agreement.'
    ],
    actions: [
      {
        id: 'confirm_local_provider',
        label: 'Download and run here',
        primary: true
      },
      {
        id: 'back_to_network',
        label: 'Back'
      },
      {
        id: 'invite_contributor',
        label: 'Invite a contributor',
        href: getPeerInviteUrl()
      }
    ]
  });
  const requestFromPendingRecovery = (record) => {
    const selectedModel = getEnabledPoolModelContract(record?.selectedModelId);
    if (!selectedModel || !isSequenceWorkload(getPoolModelWorkload(selectedModel))) return null;
    return {
      lane: 'sequence',
      promptText: null,
      sequence: record.sequence.trim(),
      sequenceRequest: {
        workload: getPoolModelWorkload(selectedModel),
        alphabet: selectedModel.sequence?.alphabet || SEQUENCE_ALPHABETS.aminoAcid,
        sensitivity: SEQUENCE_PUBLIC_SENSITIVITY,
        includeTokenEmbeddings: false,
        includeLogits: false
      },
      selectedModel,
      modelRequirements: selectedModel,
      adapterPackHash: null,
      policyId: record.policyId || FASTEST_RECEIPT_POLICY_ID,
      researchSubmission: record.researchSubmission || null
    };
  };

  const runOnThisDevice = async (request) => {
    if (disposed) throw new Error('Run view was closed');
    if (!supportsLocalRequest(request)) throw new Error('The selected checks cannot be replaced by local execution');
    updateRunState('running', 'infer', 'Preparing this device: verifying and loading the selected model');
    const executor = createLocalPackExecutor();
    localExecutor = executor;
    const cancel = () => executor.cancel();
    window.addEventListener('pagehide', cancel, { once: true });
    try {
      const definition = createPackOperationRegistry().encodeSequence.definition;
      const execution = await executor.run({
        model: request.selectedModel,
        input: { sequence: normalizeSequenceInput(request.sequence, request.sequenceRequest.alphabet) },
        options: { includeTokenEmbeddings: false, includeLogits: false },
        limits: {
          maxInputBytes: definition.maximumLimits.maxInputBytes,
          maxOutputBytes: definition.maximumLimits.maxOutputBytes,
          deadlineAt: Date.now() + Math.min(getPeerReceiptWindowMs(), definition.maximumLimits.maxJobMs)
        }
      });
      const sequenceResultHash = await hashDopplerEvidence(execution.output);
      return {
        status: 'completed', statusLabel: 'Completed locally', transport: 'local_capsule',
        policyId: 'local_capsule_execution', requestedPolicyId: request.policyId,
        model: request.selectedModel, outputKind: request.selectedModel.workload,
        sequenceOutput: execution.output, sequenceResultHash,
        embeddingDimensions: execution.output.embeddingDim,
        receiptHash: execution.receipt.receiptDigest,
        localExecution: execution,
        claimBoundary: 'Verified Capsule execution on this device; no independent contributor comparison.'
      };
    } finally {
      window.removeEventListener('pagehide', cancel);
      await executor.close();
      localExecutor = null;
    }
  };
  const buildInterruptedRequestRecovery = (request) => ({
    kind: 'request_interrupted',
    title: 'Previous request was interrupted',
    message: `This tab reloaded before a verified result arrived from "${getPeerRoomId()}". The request has not been resumed or sent again.`,
    details: [
      `The explicitly public protein sequence remains in this browser tab for ${Math.round(POOL_PENDING_REQUEST_TTL_MS / 60000)} minutes.`,
      'Retry creates a new peer request and a new receipt path.',
      `Selected model: ${modelLabelOf(request.selectedModel)}.`
    ],
    actions: [
      {
        id: 'retry_interrupted_request',
        label: 'Retry request',
        primary: true
      },
      {
        id: 'discard_interrupted_request',
        label: 'Discard'
      }
    ]
  });
  const restoreInterruptedRequest = () => {
    const persisted = readPendingRequestRecovery();
    if (!persisted) return false;
    const restoredRequest = requestFromPendingRecovery(persisted);
    if (!restoredRequest) {
      clearPendingRequestRecovery();
      return false;
    }
    pendingRequest = restoredRequest;
    if (prompt) prompt.value = restoredRequest.sequence;
    if (modelSelect) modelSelect.value = restoredRequest.selectedModel.modelId;
    if (sequencePublicControl) {
      sequencePublicControl.checked = true;
      syncSequencePublicConsent(sequencePublicControl);
    }
    if (researchPublicControl && restoredRequest.researchSubmission) researchPublicControl.checked = true;
    if (intentKindControl && restoredRequest.researchSubmission) intentKindControl.value = restoredRequest.researchSubmission.requesterIntent?.kind || 'question';
    if (intentLabelControl && restoredRequest.researchSubmission) intentLabelControl.value = restoredRequest.researchSubmission.requesterIntent?.label || '';
    if (intentTextControl && restoredRequest.researchSubmission) intentTextControl.value = restoredRequest.researchSubmission.requesterIntent?.text || '';
    if (intentConditionsControl && restoredRequest.researchSubmission) intentConditionsControl.value = restoredRequest.researchSubmission.requesterIntent?.conditions || '';
    if (intentObservationControl && restoredRequest.researchSubmission) intentObservationControl.value = restoredRequest.researchSubmission.requesterIntent?.desiredObservation || '';
    if (intentDecisionControl && restoredRequest.researchSubmission) intentDecisionControl.value = restoredRequest.researchSubmission.requesterIntent?.decisionContext || '';
    if (intentScopeControl && restoredRequest.researchSubmission) intentScopeControl.value = restoredRequest.researchSubmission.requesterIntent?.scope || '';
    if (intentExclusionsControl && restoredRequest.researchSubmission) intentExclusionsControl.value = restoredRequest.researchSubmission.requesterIntent?.exclusions || '';
    if (intentUnknownsControl && restoredRequest.researchSubmission) intentUnknownsControl.value = restoredRequest.researchSubmission.requesterIntent?.knownUnknowns || '';
    const interrupted = {
      status: 'error',
      statusLabel: 'Interrupted',
      error: 'Previous request needs a decision',
      reason: 'This tab reloaded before a verified result arrived.',
      code: 'peer_request_interrupted',
      retryable: true,
      action: 'Retry the request or discard the preserved input.',
      roomId: getPeerRoomId(),
      relay: getPeerRelayMode(),
      model: restoredRequest.selectedModel,
      recovery: buildInterruptedRequestRecovery(restoredRequest)
    };
    pendingErrorResult = interrupted;
    setResult(resultId, interrupted, { stream: true });
    updateRunState('error', 'recovery', 'Previous request needs a decision');
    return true;
  };

  const setRunButtonBusy = (busy, label = 'Running') => {
    if (busy) {
      if (!button.dataset.poolRunIdleLabel) button.dataset.poolRunIdleLabel = button.textContent;
      button.disabled = true;
      button.setAttribute('aria-busy', 'true');
      button.textContent = label;
      return;
    }
    button.disabled = false;
    button.removeAttribute('aria-busy');
    if (button.dataset.poolRunIdleLabel) {
      button.textContent = button.dataset.poolRunIdleLabel;
      delete button.dataset.poolRunIdleLabel;
    }
  };

  const prepareRunRequest = async () => {
    const lane = document.querySelector('.pool-home-stage')?.dataset.poolLane || 'sequence';
    let requestInput = prompt.value.trim();
    if (!requestInput && prompt.placeholder) {
      requestInput = prompt.placeholder.trim();
      prompt.value = requestInput;
    }
    if (!requestInput) {
      const inputLabel = lane === 'sequence' ? 'protein sequence' : 'prompt';
      updateRunState('error', 'prompt', `Enter a ${inputLabel} to run`);
      setResult(resultId, {
        status: 'error',
        error: lane === 'sequence' ? 'Protein sequence is required' : 'Prompt is required',
        reason: 'The request body is empty.',
        action: `Enter a ${inputLabel}, then run again.`
      }, { stream: true });
      return null;
    }
    if (lane === 'sequence' && sequencePublicControl?.checked !== true) {
      const error = new Error('Confirm that this protein sequence is public before sending it to selected contributors');
      error.code = 'sequence_public_consent_required';
      error.action = 'Check the public-sequence confirmation, then run again.';
      throw error;
    }
    if (lane === 'sequence') {
      writeSequencePublicConsent();
      syncSequencePublicConsent(sequencePublicControl);
    }
    const targetModelId = modelSelect?.value;
    const selectedModel = getEnabledPoolModelContract(targetModelId || LAUNCH_MODEL.modelId) || LAUNCH_MODEL;
    const sequenceWorkload = isSequenceWorkload(getPoolModelWorkload(selectedModel));
    if (lane === 'sequence' && !sequenceWorkload) {
      throw new Error('The selected request model does not support biological sequence work');
    }
    const sequence = lane === 'sequence'
      ? requestInput.replace(/^Sequence:\s*/i, '')
      : null;
    const sequenceRequest = lane === 'sequence'
      ? {
        workload: getPoolModelWorkload(selectedModel),
        alphabet: selectedModel.sequence?.alphabet || SEQUENCE_ALPHABETS.aminoAcid,
        sensitivity: SEQUENCE_PUBLIC_SENSITIVITY,
        includeTokenEmbeddings: false,
        includeLogits: false
      }
      : null;
    const publishesResearch = lane === 'sequence' && researchPublicControl?.checked === true;
    if (publishesResearch && !intentTextControl?.value?.trim()) {
      const error = new Error('State the question, hypothesis, or context before publishing research evidence');
      error.code = 'research_question_required';
      error.action = 'Add the exact question reviewers should answer, then run again.';
      throw error;
    }
    const adapter = await resolveSelectedAdapter(adapterSelect, selectedModel, {
      required: Boolean(adapterRequired())
    });
    let selectedPolicyId = policySelect?.value || FASTEST_RECEIPT_POLICY_ID;
    const selectedPolicy = listPolicies().find((policy) => policy.policyId === selectedPolicyId);
    if (publishesResearch && !policyGuaranteesIndependentExecution(selectedPolicy)) {
      const redundantPolicy = listPolicies().find((policy) => policy.policyId === 'redundant_agreement');
      if (!policyGuaranteesIndependentExecution(redundantPolicy)) {
        const error = new Error('Public Research Room evidence requires an independent-execution policy');
        error.code = 'research_independence_policy_required';
        error.action = 'Restore the redundant-agreement policy contract, then run again.';
        throw error;
      }
      selectedPolicyId = redundantPolicy.policyId;
      if (policySelect?.querySelector(`option[value="${selectedPolicyId}"]`)) {
        policySelect.value = selectedPolicyId;
      }
    }
    const request = {
      lane,
      promptText: lane === 'sequence' ? null : requestInput,
      sequence,
      sequenceRequest,
      selectedModel,
      modelRequirements: adapter ? { ...selectedModel, adapter } : selectedModel,
      adapterPackHash: adapter?.packHash || null,
      policyId: selectedPolicyId
    };
    if (publishesResearch) {
      const researchSubmission = await createSignedResearchSubmission({
        identity: researchIdentity,
        roomId: getPeerRoomId(),
        sequence,
        intent: {
          kind: intentKindControl?.value || 'question',
          text: intentTextControl?.value || '',
          label: intentLabelControl?.value || '',
          context: '',
          conditions: intentConditionsControl?.value || '',
          desiredObservation: intentObservationControl?.value || '',
          decisionContext: intentDecisionControl?.value || '',
          scope: intentScopeControl?.value || '',
          exclusions: intentExclusionsControl?.value || '',
          knownUnknowns: intentUnknownsControl?.value || ''
        },
        consent: {
          publicSequence: true,
          publicEvidenceNetwork: true,
          publishEmbedding: true
        },
        modelContract: selectedModel,
        policyId: request.policyId
      });
      const publication = await publishResearchRecord(researchSubmission, { roomId: getPeerRoomId() });
      clearPoolRoomDraft(getPeerRoomId());
      request.researchSubmission = researchSubmission;
      setResearchPublicationStatus(resultId, publication.remote
        ? `Submission ${researchSubmission.recordHash} published before compute.`
        : `Submission ${researchSubmission.recordHash} preserved locally; coordinator sync is pending.`);
    }
    return request;
  };

  const submitRunRequest = async (preparedRequest = null) => {
    if (requestInFlight || disposed) return;
    const activityGeneration = ++runActivityGeneration;
    let acceptRunActivity = true;
    requestInFlight = true;
    if (!preparedRequest) {
      pendingRequest = null;
      pendingErrorResult = null;
    }
    setRunButtonBusy(true);
    const usingKnownProvider = Boolean(preparedRequest?.knownProviderAdverts?.length);
    updateRunState('submitting', 'prompt', usingKnownProvider
      ? 'Starting the preserved request on this device'
      : preparedRequest
        ? 'Checking the network again'
        : 'Preparing signed request');
    try {
      const request = preparedRequest || await prepareRunRequest();
      if (!request || disposed) return;
      pendingRequest = request;
      pendingErrorResult = null;
      writePendingRequestRecovery(request);
      setResult(resultId, describeSelectedRun({
        status: usingKnownProvider ? 'starting_known_provider' : 'finding_peer_provider',
        policyId: request.policyId,
        modelId: request.selectedModel.modelId,
        adapterPackHash: request.adapterPackHash
      }), { stream: true });
      const result = request.localExecution === true ? await runOnThisDevice(request) : await runPeerJob({
        roomId: getPeerRoomId(),
        requesterClient,
        prompt: request.promptText,
        sequence: request.sequence,
        sequenceRequest: request.sequenceRequest,
        policyId: request.policyId,
        modelRequirements: request.modelRequirements,
        discoveryWindowMs: getPeerDiscoveryWindowMs(),
        sessionAcceptWindowMs: getPeerSessionAcceptWindowMs(),
        receiptWindowMs: getPeerReceiptWindowMs(),
        queueWindowMs: getPeerQueueWindowMs(),
        transportConnectWindowMs: getPeerTransportConnectWindowMs(),
        roomBusFactory: getPeerRoomBusFactory(),
        relayAckSigner: requesterClient.createRelayAcknowledgement.bind(requesterClient),
        generationConfig: getPeerGenerationConfig(),
        knownProviderAdverts: request.knownProviderAdverts || [],
        rtcConfigProvider: getPeerRelayMode() === 'server' && window.REPLOID_POOL_FORCE_RELAY === true
          // Public server-relay discovery may be anonymous.  Do not request
          // scoped TURN credentials unless the caller explicitly requires the
          // relay-only transport; direct ICE remains available by default.
          ? () => getPoolRtcConfig({ sdk: rtcSdk, forceRelay: true })
          : null,
        onActivity: (activity) => {
          if (!acceptRunActivity || activityGeneration !== runActivityGeneration) return;
          handleRunActivity(activity);
        }
      }).catch(async (error) => {
        if (disposed || !canOfferLocalFallback(error) || !supportsLocalRequest(request) || !navigator.gpu) throw error;
        acceptRunActivity = false;
        const result = await runOnThisDevice(request);
        result.networkFailure = { code: recoveryCodeOf(error), message: errorString(error) };
        return result;
      });
      acceptRunActivity = false;
      if (disposed) return;
      result.inviteUrl = getPeerInviteUrl();
      result.relay = result.transport === 'local_capsule' ? 'none' : getPeerRelayMode();
      if (request.researchSubmission && request.lane === 'sequence') {
        const researchResult = await createSignedResearchResult({
          identity: researchIdentity,
          roomId: getPeerRoomId(),
          submission: request.researchSubmission,
          receiptRecord: result.receiptRecord || result,
          receiptEvidence: result.receiptEvidence || null,
          agreement: result.agreement || null,
          routeDecision: result.plan?.routeDecision || result.routeDecision || null,
          embedding: result.sequenceOutput?.pooledEmbedding || result.receiptRecord?.sequenceOutput?.pooledEmbedding || null,
          sequenceResult: result.sequenceResult || result.receiptRecord?.sequenceResult || null,
          sequenceOutput: result.sequenceOutput || result.receiptRecord?.sequenceOutput || null
        });
        const publication = await publishResearchRecord(researchResult, { roomId: getPeerRoomId() });
        result.researchSubmissionHash = request.researchSubmission.recordHash;
        result.researchResultHash = researchResult.recordHash;
        result.researchPublication = publication.remote ? 'coordinator_synced' : 'local_sync_pending';
        result.embeddingPublicationConsent = request.researchSubmission.consent?.publishEmbedding === true;
      }
      addReceiptLedgerRow({
        ...(result.receiptRecord || result),
        requesterAcceptance: result.requesterAcceptance || null,
        agreement: result.agreement || null,
        routeDecision: result.plan?.routeDecision || result.routeDecision || null,
        transport: result.transport || null,
        relay: result.relay || getPeerRelayMode(),
        policyId: result.policyId || request.policyId,
        outputKind: result.outputKind || null,
        sequenceResultHash: result.sequenceResultHash || null,
        embeddingDimensions: result.embeddingDimensions || null
      }, result.receiptHash);
      void refreshServerRoomActivity();
      setResult(resultId, result, { stream: true });
      if (result.researchResultHash) {
        setResearchPublicationStatus(resultId, `Evidence result ${result.researchResultHash} preserved. Open Records to review, connect, and discover.`);
      }
      updateRunState(
        'complete',
        'answer',
        result.transport === 'local_capsule' ? 'Completed on this device' : request.lane === 'sequence' ? 'Protein embedding verified' : 'Answer verified'
      );
      pendingRequest = null;
      clearPendingRequestRecovery();
    } catch (error) {
      acceptRunActivity = false;
      if (disposed) return;
      const selectedModel = pendingRequest?.selectedModel
        || getEnabledPoolModelContract(modelSelect?.value || LAUNCH_MODEL.modelId)
        || LAUNCH_MODEL;
      const networkUnavailable = pendingRequest && canOfferLocalFallback(error);
      const displayError = displayPoolError(error, {
        title: networkUnavailable ? 'No matching provider is currently available' : 'Request could not complete',
        action: networkUnavailable
          ? 'Reploid searched the peer network. Choose a recovery option below.'
          : error?.payload?.action || error?.action || 'Check the technical details, then try again.',
        context: {
          roomId: getPeerRoomId(),
          relay: getPeerRelayMode(),
          model: selectedModel,
          adapterPackHash: pendingRequest?.adapterPackHash || adapterSelect?.value || null
        }
      });
      if (networkUnavailable) {
        displayError.statusLabel = 'No provider';
        displayError.action = 'The request is preserved. Choose a recovery option below.';
        displayError.recovery = buildMissingProviderRecovery(pendingRequest);
        pendingErrorResult = displayError;
        recordPeerLedgerEvents([{
          type: 'request_event',
          fromPeerId: requesterIdentity.identityRootId || requesterIdentity.userId || 'local-requester',
          createdAt: new Date().toISOString(),
          body: {
            status: 'waiting_for_provider',
            reason: 'No matching provider',
            roomId: getPeerRoomId(),
            modelId: selectedModel.modelId || selectedModel.id || null,
            policyId: pendingRequest.policyId || null,
            retryable: true
          }
        }]);
        refreshRecordTimelineState();
      }
      setResult(resultId, displayError, { stream: true });
      clearPendingRequestRecovery();
      updateRunState('error', 'match', networkUnavailable
        ? 'No matching provider is currently available'
        : 'Run needs attention');
    } finally {
      acceptRunActivity = false;
      requestInFlight = false;
      if (!disposed) setRunButtonBusy(false);
    }
  };

  const runPreservedRequestLocally = async () => {
    if (!pendingRequest || requestInFlight) return;
    await submitRunRequest({ ...pendingRequest, localExecution: true });
  };

  recoveryElement?.addEventListener('click', (event) => {
    const action = event.target.closest?.('[data-pool-run-recovery-action]');
    if (!action || action.tagName === 'A') return;
    const actionId = action.dataset.poolRunRecoveryAction;
    if (actionId === 'retry_network') {
      void submitRunRequest(pendingRequest);
      return;
    }
    if (actionId === 'retry_interrupted_request' && pendingRequest) {
      void submitRunRequest(pendingRequest);
      return;
    }
    if (actionId === 'discard_interrupted_request') {
      clearPendingRequestRecovery();
      pendingRequest = null;
      pendingErrorResult = null;
      setResult(resultId, '', { stream: true });
      updateRunState('idle', '', 'Ready for a new request');
      return;
    }
    if (actionId === 'offer_local_provider' && pendingRequest && pendingErrorResult) {
      setResult(resultId, {
        ...pendingErrorResult,
        recovery: buildLocalConsentRecovery(pendingRequest)
      }, { stream: true });
      return;
    }
    if (actionId === 'back_to_network' && pendingErrorResult) {
      setResult(resultId, pendingErrorResult, { stream: true });
      return;
    }
    if (actionId === 'confirm_local_provider') {
      void runPreservedRequestLocally();
    }
  });
  const submit = (event) => {
    event?.preventDefault?.();
    void submitRunRequest();
  };
  if (form) form.addEventListener('submit', submit);
  else button.addEventListener('click', submit);
  if (!restoreInterruptedRequest()) updateRunState('idle');
  return () => {
    disposed = true;
    ++runActivityGeneration;
    localExecutor?.cancel();
  };
};

const runWorkloadOf = (modelSelect) => (
  modelSelect?.selectedOptions?.[0]?.dataset?.workload || POOLDAY_MODEL_WORKLOADS.sequenceEmbedding
);

const syncRunWorkloadAffordance = (modelSelect) => {
  const badge = document.querySelector('[data-pool-run-workload]');
  const promptLabel = document.querySelector('[data-pool-run-prompt-label]');
  const workload = runWorkloadOf(modelSelect);
  const isSequence = true;
  if (badge) badge.textContent = workload.replace(/[-_]/g, ' ');
  if (promptLabel) promptLabel.textContent = isSequence ? 'Sequence' : 'Prompt';
};

export const bindRunControls = () => {
  const modelSelect = document.getElementById('pool-run-model');
  const sequencePublicControl = document.getElementById('pool-run-sequence-public');
  const stopRun = bindPeerRunSurface({
    button: document.getElementById('pool-run-submit'),
    prompt: document.getElementById('pool-run-prompt'),
    policySelect: document.getElementById('pool-run-policy'),
    modelSelect,
    sequencePublicControl,
    researchPublicControl: document.getElementById('pool-run-research-public'),
    intentKindControl: document.getElementById('pool-run-intent-kind'),
    intentLabelControl: document.getElementById('pool-run-intent-label'),
    intentTextControl: document.getElementById('pool-run-intent-text'),
    intentConditionsControl: document.getElementById('pool-run-intent-conditions'),
    intentObservationControl: document.getElementById('pool-run-intent-observation'),
    intentDecisionControl: document.getElementById('pool-run-intent-decision'),
    intentScopeControl: document.getElementById('pool-run-intent-scope'),
    intentExclusionsControl: document.getElementById('pool-run-intent-exclusions'),
    intentUnknownsControl: document.getElementById('pool-run-intent-unknowns'),
    resultId: 'pool-run-result'
  });
  if (modelSelect && modelSelect.dataset.poolWorkloadBound !== 'true') {
    modelSelect.dataset.poolWorkloadBound = 'true';
    modelSelect.addEventListener('change', () => {
      syncRunWorkloadAffordance(modelSelect);
    });
    syncRunWorkloadAffordance(modelSelect);
  }
  return stopRun;
};

export const bindEmbeddingResultControls = () => {
  document.querySelectorAll('[data-pool-copy-embedding]').forEach((button) => {
    if (button.dataset.poolEmbeddingCopyBound === 'true') return;
    button.dataset.poolEmbeddingCopyBound = 'true';
    button.addEventListener('click', async () => {
      const resultId = String(button.dataset.poolEmbeddingResultId || '').trim();
      const vector = resultId ? document.getElementById(`${resultId}-embedding`)?.textContent?.trim() : '';
      const status = button.closest('.pool-embedding-outcome')?.querySelector('[data-pool-embedding-copy-status]');
      if (button.dataset.poolEmbeddingPublicationPermitted !== 'true') {
        if (status) status.textContent = 'The raw embedding is withheld because publication consent was not granted.';
        return;
      }
      if (!vector) {
        if (status) status.textContent = 'The embedding is not available to copy.';
        return;
      }
      if (typeof navigator.clipboard?.writeText !== 'function') {
        if (status) status.textContent = 'Clipboard access is unavailable. Open View embedding vector and copy it manually.';
        return;
      }
      try {
        await navigator.clipboard.writeText(vector);
        if (status) status.textContent = 'Embedding vector copied.';
      } catch {
        if (status) status.textContent = 'Copy failed. Open View embedding vector and copy it manually.';
      }
    });
  });
};

const setDrawerSummary = (sectionId, value) => {
  const summary = document.querySelector(`[data-pool-drawer-summary="${sectionId}"]`);
  if (summary) summary.textContent = String(value || '');
};

const requestModelsForLane = (lane) => listPoolModels({
  enabledOnly: true,
  workload: POOLDAY_MODEL_WORKLOADS.sequenceEmbedding
});

const replaceRequestModelOptions = (modelSelect, lane, preferredModelId = null) => {
  if (!modelSelect) return null;
  const models = requestModelsForLane(lane);
  modelSelect.replaceChildren(...models.map((model) => {
    const option = createSelectOption(model.label || model.modelId, model.modelId);
    option.dataset.workload = getPoolModelWorkload(model);
    return option;
  }));
  const preferredExists = models.some((model) => model.modelId === preferredModelId);
  const selectedModel = preferredExists ? preferredModelId : models[0]?.modelId || '';
  modelSelect.value = selectedModel;
  modelSelect.disabled = models.length === 0;
  return getEnabledPoolModelContract(selectedModel);
};

const bindHomeLaneChips = (input, adapterSelect, modelSelect) => {
  const chips = [...document.querySelectorAll('.pool-lane-chip[data-pool-lane]')];
  const stage = document.querySelector('.pool-home-stage');
  const adapterPicker = adapterSelect?.closest('[data-pool-home-adapter-picker]');
  const sequenceOptions = document.querySelector('[data-pool-sequence-options]');
  const sequencePublicControl = document.getElementById('pool-home-sequence-public');
  const taskDescription = document.querySelector('[data-pool-task-description]:not(.pool-lane-chip)');
  const submitButton = document.getElementById('pool-home-run-submit');
  const resultLabel = document.querySelector('label[for="pool-home-run-result-stream"]');
  const laneValues = new Map([[stage?.dataset.poolLane || 'sequence', input?.value || '']]);
  const laneModels = new Map([[stage?.dataset.poolLane || 'sequence', modelSelect?.value || '']]);
  if (chips.length === 0 || !stage) return;
  chips.forEach((chip) => {
    if (chip.disabled || chip.dataset.poolLaneBound === 'true') return;
    chip.dataset.poolLaneBound = 'true';
    chip.addEventListener('click', () => {
      const lane = chip.dataset.poolLane || 'sequence';
      chips.forEach((other) => {
        const active = other.dataset.poolLane === lane;
        other.classList.toggle('is-active', active);
        other.setAttribute('aria-pressed', String(active));
      });
      const previousLane = stage.dataset.poolLane || 'sequence';
      const previousModelId = modelSelect?.value || '';
      laneValues.set(previousLane, input.value);
      if (previousModelId) laneModels.set(previousLane, previousModelId);
      stage.dataset.poolLane = lane;
      input.value = laneValues.get(lane) || '';
      setDrawerSummary('request-task', chip.textContent.trim());
      if (taskDescription) taskDescription.textContent = chip.dataset.poolTaskDescription || '';
      const nextPrompt = choosePooldayAskPlaceholderForLane(lane);
      input.placeholder = nextPrompt;
      input.dataset.poolSuggestedPrompt = nextPrompt;
      input.dataset.poolSuggestedPromptCleared = 'false';
      input.name = lane === 'sequence' ? 'sequence' : 'prompt';
      input.setAttribute('aria-label', lane === 'sequence' ? 'Public protein sequence' : 'Ask prompt');
      if (submitButton) submitButton.setAttribute('aria-label', 'Run model');
      if (resultLabel) resultLabel.textContent = lane === 'sequence' ? 'Embedding' : 'Answer';
      if (adapterPicker) adapterPicker.hidden = lane !== 'adapters';
      if (sequenceOptions) sequenceOptions.hidden = lane !== 'sequence';
      if (sequencePublicControl) sequencePublicControl.required = lane === 'sequence';
      const sameModelFamily = true;
      const selectedModel = replaceRequestModelOptions(
        modelSelect,
        lane,
        laneModels.get(lane) || (sameModelFamily ? previousModelId : null)
      );
      if (modelSelect) {
        modelSelect.dispatchEvent(new Event('change', { bubbles: true }));
      }
      if (adapterSelect) {
        adapterSelect.value = '';
      }
    });
  });
};

export const bindHomeAskControls = () => {
  const form = document.getElementById('pool-home-ask-form');
  const input = document.getElementById('pool-home-ask-prompt');
  const button = document.getElementById('pool-home-run-submit');
  const adapterSelect = document.getElementById('pool-home-adapter');
  const modelSelect = document.getElementById('pool-home-request-model');
  const policySelect = document.getElementById('pool-home-request-policy');
  const sequencePublicControl = document.getElementById('pool-home-sequence-public');
  if (!form || !input || !button) return;
  let dockObserver;
  const stage = form.closest('.pool-home-stage');
  if (stage && form.dataset.poolDockMeasurementBound !== 'true') {
    form.dataset.poolDockMeasurementBound = 'true';
    const syncDockHeight = () => {
      const height = Math.ceil(form.getBoundingClientRect().height);
      if (height > 0) stage.style.setProperty('--pool-param-ask-dock-height', `${height}px`);
    };
    syncDockHeight();
    if (typeof ResizeObserver === 'function') {
      dockObserver = new ResizeObserver(syncDockHeight);
      dockObserver.observe(form);
    }
  }
  if (sequencePublicControl && sequencePublicControl.dataset.poolConsentBound !== 'true') {
    sequencePublicControl.dataset.poolConsentBound = 'true';
    syncSequencePublicConsent(sequencePublicControl);
    sequencePublicControl.addEventListener('change', () => {
      if (sequencePublicControl.checked) writeSequencePublicConsent();
      syncSequencePublicConsent(sequencePublicControl);
    });
  }
  bindSuggestedPromptEditing(input);
  const example = form.querySelector('[data-pool-use-example]');
  if (example && example.dataset.poolExampleBound !== 'true') {
    example.dataset.poolExampleBound = 'true';
    example.addEventListener('click', () => {
      if (input.disabled || example.disabled || !input.dataset.poolSuggestedPrompt) return;
      input.value = input.dataset.poolSuggestedPrompt;
      input.dispatchEvent(new Event('input', { bubbles: true }));
      input.focus();
    });
  }
  if (input.dataset.poolSequenceFeedbackBound !== 'true') {
    input.dataset.poolSequenceFeedbackBound = 'true';
    const updateFeedback = () => {
      const model = getEnabledPoolModelContract(modelSelect?.value) || LAUNCH_MODEL;
      const alphabet = model.sequence?.alphabet || SEQUENCE_ALPHABETS.aminoAcid;
      const policyLimit = getMaxPublicSequenceLength(alphabet);
      const limit = Math.min(policyLimit, Number(model.sequence?.maxLength) || policyLimit);
      const length = input.value.replace(/\s+/g, '').length;
      let message = '';
      if (length) {
        try {
          normalizeSequenceInput(input.value, alphabet);
          if (length > limit) message = `This model accepts up to ${limit} residues.`;
        } catch (error) {
          message = error.message;
        }
      }
      const counter = form.querySelector('#pool-sequence-count');
      const feedback = form.querySelector('#pool-sequence-feedback');
      if (counter) counter.textContent = `${length} / ${limit}`;
      if (feedback) feedback.textContent = message || 'Whitespace is ignored.';
      input.setAttribute('aria-invalid', String(Boolean(message)));
      input.setCustomValidity(message);
    };
    input.addEventListener('input', updateFeedback);
    input.addEventListener('change', updateFeedback);
    modelSelect?.addEventListener('change', updateFeedback);
    // Keep programmatically restored/suggested inputs in sync as well.
    form.addEventListener('submit', () => queueMicrotask(updateFeedback));
    updateFeedback();
  }
  bindHomeLaneChips(input, adapterSelect, modelSelect);
  if (modelSelect && modelSelect.dataset.poolRequestModelBound !== 'true') {
    modelSelect.dataset.poolRequestModelBound = 'true';
    const syncModel = () => {
      setDrawerSummary('request-model', modelSelect.selectedOptions[0]?.textContent || modelSelect.value);
      const lane = document.querySelector('.pool-home-stage')?.dataset.poolLane || 'sequence';
    };
    modelSelect.addEventListener('change', syncModel);
    syncModel();
  }
  if (policySelect && policySelect.dataset.poolRequestPolicyBound !== 'true') {
    policySelect.dataset.poolRequestPolicyBound = 'true';
    const syncPolicy = () => {
      const label = policySelect.selectedOptions[0]?.textContent || policySelect.value;
      setDrawerSummary('request-checks', label.split(' - ')[0]);
    };
    policySelect.addEventListener('change', syncPolicy);
    syncPolicy();
  }
  const stopRun = bindPeerRunSurface({
    button,
    prompt: input,
    form,
    policySelect,
    modelSelect,
    adapterSelect,
    adapterRequired: () => document.querySelector('.pool-home-stage')?.dataset.poolLane === 'adapters',
    sequencePublicControl,
    researchPublicControl: document.getElementById('pool-home-research-public'),
    intentKindControl: document.getElementById('pool-home-intent-kind'),
    intentLabelControl: document.getElementById('pool-home-intent-label'),
    intentTextControl: document.getElementById('pool-home-intent-text'),
    intentConditionsControl: document.getElementById('pool-home-intent-conditions'),
    intentObservationControl: document.getElementById('pool-home-intent-observation'),
    intentDecisionControl: document.getElementById('pool-home-intent-decision'),
    intentScopeControl: document.getElementById('pool-home-intent-scope'),
    intentExclusionsControl: document.getElementById('pool-home-intent-exclusions'),
    intentUnknownsControl: document.getElementById('pool-home-intent-unknowns'),
    resultId: 'pool-home-run-result'
  });
  return () => { stopRun?.(); dockObserver?.disconnect(); };
};

const createProviderContributionController = () => {
  let peerProviderIdentity = null;
  let peerProviderClient = null;
  let peerProviderNode = null;
  let workerRunning = false;
  let workerStarting = false;
  let lifecycleGeneration = 0;
  let currentModel = null;
  let requestedModelId = null;
  let workerStartPromise = null;
  let providerReadyState = null;
  let latestProviderActivity = null;
  let latestRelayActivity = null;
  let providerActivityHistory = [];
  let restoreAttempted = false;
  let visibilityHandler = null;
  let controls = {
    workerToggleButton: null,
    modelInput: null,
    mount: null
  };
  const adapterSdk = createPoolSdk();
  const fetchAdapterFromOrigin = createPublishedAdapterOriginFetcher({ sdk: adapterSdk });

  const getRuntime = () => {
    const runtime = window.REPLOID_DOPPLER_RUNTIME || createDopplerRuntime();
    window.REPLOID_DOPPLER_RUNTIME = runtime;
    return runtime;
  };

  const getMount = () => controls.mount || document.getElementById('app');

  const getProviderIdentity = () => {
    if (!peerProviderIdentity) {
      peerProviderIdentity = createPoolIdentity('provider', {
        localOnly: true,
        namespace: getProviderIdentityNamespace()
      });
    }
    return peerProviderIdentity;
  };

  const getProviderClient = () => {
    if (!peerProviderClient) {
      peerProviderClient = createProviderClient({
        sdk: null,
        runtime: getRuntime(),
        identity: getProviderIdentity(),
        fetchAdapterFromOrigin
      });
    }
    return peerProviderClient;
  };

  const getSelectedModelId = () => (
    requestedModelId
    || controls.modelInput?.value
    || currentModel?.modelId
    || LAUNCH_MODEL.modelId
  );

  const getProviderModel = () => ({
    ...buildLaunchProviderModel({ modelId: getSelectedModelId() })
  });

  const setContributionState = (patch = {}) => {
    updateContributionState({
      roomId: getPeerRoomId(),
      relay: getPeerRelayMode(),
      modelId: currentModel?.modelId || getSelectedModelId(),
      ...patch
    });
    refreshContributionStatusBar();
  };

  const syncWorkerControls = () => {
    if (controls.modelInput && currentModel?.modelId && (workerRunning || workerStarting)) {
      controls.modelInput.value = currentModel.modelId;
    }
    if (controls.workerToggleButton) {
      const active = workerRunning || workerStarting;
      if (workerStarting) {
        controls.workerToggleButton.disabled = true;
        controls.workerToggleButton.textContent = 'Starting...';
        controls.workerToggleButton.dataset.op = '○';
        controls.workerToggleButton.dataset.contributionAction = 'stop';
        controls.workerToggleButton.setAttribute('aria-pressed', 'true');
        controls.workerToggleButton.classList.remove('btn-primary');
        controls.workerToggleButton.classList.add('btn-ghost');
      } else {
        controls.workerToggleButton.disabled = false;
        controls.workerToggleButton.textContent = active
          ? 'Stop sharing'
          : 'Start sharing';
        controls.workerToggleButton.dataset.op = active ? '■' : '▶';
        controls.workerToggleButton.dataset.contributionAction = active ? 'stop' : 'start';
        controls.workerToggleButton.setAttribute('aria-pressed', String(active));
        controls.workerToggleButton.classList.toggle('btn-primary', !active);
        controls.workerToggleButton.classList.toggle('btn-ghost', active);
      }
    }
    if (controls.modelInput) controls.modelInput.disabled = workerRunning || workerStarting;
    refreshContributionStatusBar();
  };

  const setProviderStatus = (status) => updateProviderStatus(getMount(), status);
  const setProviderNotice = (notice = null) => updateProviderNotice(getMount(), notice);

  const syncProviderPanel = () => {
    if (!controls.modelInput && !controls.workerToggleButton) {
      syncWorkerControls();
      return;
    }
    setProviderStatus(workerStarting ? 'Starting' : workerRunning ? 'Available' : 'Idle');
    if (workerStarting || workerRunning) setProviderNotice(null);
    updateProviderHealth({
      webgpu: navigator.gpu ? 'available' : 'unavailable',
      storage: navigator.storage ? 'available' : 'unknown',
      hardware: 'unknown',
      queue: workerRunning ? 'listening' : 'stopped'
    });
    void refreshProviderStorageHealth();
    syncWorkerControls();
  };

  const modelMatchesLoadedRuntime = (model = {}) => {
    const runtime = getRuntime();
    const loaded = typeof runtime?.getModelInfo === 'function' ? runtime.getModelInfo() : null;
    return !!loaded
      && loaded.modelId === model.modelId
      && loaded.modelHash === model.modelHash
      && loaded.manifestHash === model.manifestHash
      && loaded.runtime === model.runtime
      && loaded.backend === model.backend
      && (loaded.workload || model.workload || POOLDAY_MODEL_WORKLOADS.sequenceEmbedding) === (model.workload || POOLDAY_MODEL_WORKLOADS.sequenceEmbedding);
  };

  const loadSelectedProviderModel = async (generation) => {
    const runtime = getRuntime();
    setProviderStatus('Starting');
    await refreshProviderStorageHealth();
    if (generation !== undefined && generation !== lifecycleGeneration) throw new Error('Aborted');
    updateProviderHealth({
      webgpu: navigator.gpu ? 'available' : 'unavailable',
      model: 'loading',
      artifact: window.REPLOID_POOL_STRICT_ARTIFACT_PREFLIGHT === true ? 'checking' : 'strict_preflight_off',
      queue: 'starting'
    });
    const model = getEnabledPoolModelContract(getSelectedModelId());
    if (!model) throw new Error('Selected model is not enabled for peer contribution');
    currentModel = model;
    const deviceInfo = typeof runtime?.getDeviceInfo === 'function'
      ? await runtime.getDeviceInfo()
      : { hasWebGPU: !!navigator.gpu, features: [] };
    if (generation !== undefined && generation !== lifecycleGeneration) throw new Error('Aborted');
    updateProviderHealth({
      webgpu: deviceInfo.hasWebGPU ? 'available' : 'unavailable',
      hardware: formatDeviceLabel(deviceInfo),
      maxBufferSize: deviceInfo.maxBufferSize || null
    });
    const capabilityCheck = validateModelRuntimeCapabilities(model, deviceInfo);
    if (!capabilityCheck.ok) {
      updateProviderHealth({
        webgpu: 'unsupported_model_capability',
        model: 'capability_blocked',
        queue: 'stopped'
      });
      const error = new Error(capabilityCheck.reasons.join('; '));
      error.code = 'model_runtime_capability_unsupported';
      error.payload = {
        model,
        deviceInfo,
        capabilityCheck,
        action: capabilityCheck.action
      };
      throw error;
    }
    if (modelMatchesLoadedRuntime(model) && runtime.isReady?.()) {
      updateProviderHealth({
        model: model.modelId,
        artifact: 'ready',
        trust: 'signed_record'
      });
      return {
        ok: true,
        status: 'model_loaded',
        model: runtime.getModelInfo()
      };
    }
    const artifactPreflight = await probeModelArtifacts(model);
    if (generation !== undefined && generation !== lifecycleGeneration) throw new Error('Aborted');
    updateProviderHealth({
      artifact: artifactPreflight.ok ? artifactPreflight.status : 'manifest_unavailable'
    });
    if (window.REPLOID_POOL_STRICT_ARTIFACT_PREFLIGHT === true && !artifactPreflight.ok) {
      const error = new Error(artifactPreflight.error || 'model artifact preflight failed');
      error.code = 'model_artifact_unavailable';
      error.payload = {
        model,
        artifactPreflight,
        action: artifactPreflight.action
      };
      throw error;
    }
    const manifestByteHash = artifactPreflight.ok
      ? artifactPreflight.observedHashes?.textHash
      : null;
    const loadResult = await runtime.loadModel({
      ...model,
      ...(manifestByteHash ? { manifestByteHash } : {})
    });
    if (generation !== undefined && generation !== lifecycleGeneration) throw new Error('Aborted');
    if (!loadResult?.ok || !runtime.isReady?.() || !modelMatchesLoadedRuntime(model)) {
      const reason = loadResult?.reason || 'Doppler runtime did not expose the selected model after load';
      const error = new Error(`Doppler model load failed: ${reason}`);
      error.code = 'doppler_model_load_failed';
      error.payload = {
        model,
        artifactPreflight,
        loadResult,
        loadState: runtime.getLoadState?.() || null,
        webgpu: navigator.gpu ? 'available' : 'unavailable',
        action: artifactPreflight.ok
          ? 'Check the Doppler module URL and browser WebGPU support, then try Load again.'
          : artifactPreflight.action
      };
      throw error;
    }
    updateProviderHealth({
      model: model.modelId,
      artifact: artifactPreflight.ok ? artifactPreflight.status : 'manifest_unavailable',
      trust: 'signed_record'
    });
    return {
      ...loadResult,
      artifactPreflight,
      status: 'model_loaded'
    };
  };

  const stopPeerProvider = async () => {
    if (!peerProviderNode) return null;
    const node = peerProviderNode;
    peerProviderNode = null;
    return node.stop();
  };

  const handlePeerActivity = (event) => {
    providerActivityHistory.push(event);
    if (providerActivityHistory.length > POOL_PROVIDER_ACTIVITY_HISTORY_LIMIT) {
      providerActivityHistory = providerActivityHistory.slice(-POOL_PROVIDER_ACTIVITY_HISTORY_LIMIT);
    }
    const isRelayActivity = String(event?.status || '').startsWith('relay-');
    if (isRelayActivity) latestRelayActivity = event;
    else if (event?.status !== 'provider_advertised') latestProviderActivity = event;
    if (event?.status === 'relay-publish-retrying'
      || event?.status === 'relay-poll-failed'
      || event?.status === 'relay-dispatch-retrying') {
      setProviderStatus('Relay retrying');
      updateProviderHealth({ queue: 'relay_retrying' });
    }
    if (event?.status === 'relay-circuit-open') {
      setProviderStatus('Relay unavailable');
      updateProviderHealth({ queue: 'relay_unavailable' });
    }
    if (event?.status === 'relay-circuit-half-open') {
      setProviderStatus('Checking relay');
      updateProviderHealth({ queue: 'relay_recovery_check' });
    }
    if (event?.status === 'relay-circuit-closed') {
      setProviderStatus(workerRunning ? 'Available' : 'Starting');
      updateProviderHealth({ queue: workerRunning ? 'listening' : 'starting' });
    }
    if (event?.status === 'provider_advertised') {
      // Periodic discovery publication does not settle an executing job or an error.
      if (!latestProviderActivity) {
        setProviderStatus('Available');
        updateProviderHealth({ queue: 'listening' });
        setContributionState({ state: 'idle', optedIn: true, lastError: null });
      }
      return;
    }
    if (event?.status === 'peer_session_opening') {
      setProviderStatus('Connecting');
      updateProviderHealth({ queue: 'opening_session' });
      setContributionState({ state: 'working', optedIn: true, lastError: null });
    }
    if (event?.status === 'peer_session_open') {
      setProviderStatus('Answering');
      updateProviderHealth({ queue: 'running_peer_job' });
      setContributionState({ state: 'working', optedIn: true, lastError: null });
    }
    if (event?.status === 'peer_execution_started') {
      setProviderStatus('Computing');
      updateProviderHealth({ queue: 'executing_peer_job' });
      setContributionState({ state: 'working', optedIn: true, lastError: null });
    }
    if (event?.status === 'peer_execution_abandoned') {
      const stillComputing = Number(event.activeExecutionCount || 0) > 0;
      const queued = Number(event.queueDepth || 0) > 0;
      setProviderStatus(stillComputing ? 'Computing' : queued ? 'Queued' : workerRunning ? 'Available' : 'Idle');
      updateProviderHealth({
        queue: stillComputing
          ? 'executing_peer_job'
          : queued
            ? 'queued_peer_job'
            : workerRunning
              ? 'listening'
              : 'inactive'
      });
      setContributionState({
        state: stillComputing || queued ? 'working' : workerRunning ? 'idle' : 'inactive',
        optedIn: workerRunning,
        lastError: event.outcome === 'failed' ? errorString(event.error) : null
      });
    }
    if (event?.status === 'peer_receipt_sent') {
      setProviderStatus('Available');
      updateProviderHealth({
        queue: 'receipt_sent',
        lastReceipt: event.receiptRecord?.receiptHash || 'signed'
      });
      if (event.receiptRecord) {
        recordContributionReceipt(event.receiptRecord, {
          roomId: getPeerRoomId(),
          modelId: currentModel?.modelId || getSelectedModelId()
        });
        addReceiptLedgerRow(event.receiptRecord, event.receiptRecord.receiptHash);
      }
      setContributionState({
        state: 'idle',
        optedIn: true,
        lastReceiptHash: event.receiptRecord?.receiptHash || null,
        lastError: null
      });
    }
    if (event?.status === 'peer_acceptance_received') {
      updateProviderHealth({
        queue: 'accepted',
        reputation: 'local_event_received'
      });
      setContributionState({ state: 'idle', optedIn: true, lastError: null });
    }
    if (event?.status === 'peer_session_failed') {
      setProviderStatus(workerRunning ? 'Available' : 'Idle');
      updateProviderHealth({ queue: 'session_failed' });
      setContributionState({
        state: workerRunning ? 'idle' : 'inactive',
        optedIn: workerRunning,
        lastError: errorString(event.error || event.reason || 'Peer session failed')
      });
    }
    setResult('pool-provider-result', {
      ...(providerReadyState || {}),
      runner: providerReadyState ? 'peer_room_listening' : 'peer_room',
      roomId: getPeerRoomId(),
      relay: getPeerRelayMode(),
      inviteUrl: getPeerInviteUrl(),
      ...(latestProviderActivity || {}),
      latestRelayActivity,
      activityHistory: providerActivityHistory
    });
    void refreshServerRoomActivity();
  };

  const ensurePeerProviderReady = async (generation) => {
    const runtime = getRuntime();
    const capabilityProfile = await assessPoolDeviceCapability({ runtime });
    if (generation !== undefined && generation !== lifecycleGeneration) throw new Error('Aborted');
    const selectedEligibility = capabilityProfile.modelEligibility.find((entry) => (
      entry.modelId === getSelectedModelId()
    ));
    if (!selectedEligibility?.eligible) {
      const error = new Error(selectedEligibility?.reasons?.join('; ') || 'This device did not qualify for the selected model');
      error.code = 'device_capability_model_ineligible';
      error.payload = {
        capabilityProfile,
        selectedModelId: getSelectedModelId(),
        action: 'Choose an eligible model or request work from another contributor.'
      };
      throw error;
    }
    updateProviderHealth({
      capability: `${capabilityProfile.tier.id}_${capabilityProfile.score}`,
      hardware: formatDeviceLabel(capabilityProfile.deviceInfo)
    });
    const loaded = await loadSelectedProviderModel(generation);
    if (generation !== undefined && generation !== lifecycleGeneration) throw new Error('Aborted');
    const model = loaded.model || runtime.getModelInfo();
    currentModel = model;
    const participation = readParticipationPreferences();
    let adapterPacks = [];
    if (participation.permissions.relayArtifacts && supportsAdapterPublications(model)) {
      try {
        const publications = await withTimeout(
          listFetchableAdapterPublications({ sdk: adapterSdk, model }),
          Number(window.REPLOID_POOL_ADAPTER_DISCOVERY_TIMEOUT_MS || POOL_ADAPTER_DISCOVERY_TIMEOUT_MS),
          'Adapter publication discovery timed out'
        );
        if (generation !== undefined && generation !== lifecycleGeneration) throw new Error('Aborted');
        const maxArtifactBytes = participation.limits.storageBudgetMiB * 1024 * 1024;
        adapterPacks = publications.filter((publication) => (
          Number(publication.pack?.adapter?.bytes || 0) <= maxArtifactBytes
        )).map((publication) => (
          adapterRequirementFromPublication(publication, { state: 'fetchable' })
        ));
        updateProviderHealth({ adapters: adapterPacks.length ? `${adapterPacks.length}_fetchable` : 'none' });
      } catch (error) {
        if (generation !== undefined && generation !== lifecycleGeneration) throw new Error('Aborted');
        updateProviderHealth({ adapters: 'registry_unavailable', adapterRegistryError: errorString(error) });
      }
    } else if (!participation.permissions.relayArtifacts) {
      updateProviderHealth({ adapters: 'relay_disabled' });
    } else {
      updateProviderHealth({ adapters: 'not_applicable' });
    }
    const providerIdentityState = await getProviderIdentity().resolve();
    if (generation !== undefined && generation !== lifecycleGeneration) throw new Error('Aborted');
    const capabilityLimits = resolveCapabilityAvailabilityLimits(participation, capabilityProfile);
    await stopPeerProvider();
    if (generation !== undefined && generation !== lifecycleGeneration) throw new Error('Aborted');
    const node = createPeerProviderNode({
      roomId: getPeerRoomId(),
      providerClient: getProviderClient(),
      roomBusFactory: getPeerRoomBusFactory(),
      relayAckSigner: getProviderClient().createRelayAcknowledgement.bind(getProviderClient()),
      rtcConfigProvider: getPeerRelayMode() === 'server' && window.REPLOID_POOL_FORCE_RELAY === true
        ? () => getPoolRtcConfig({ sdk: adapterSdk, forceRelay: true })
        : null,
      onActivity: (event) => {
        if (generation !== undefined && generation !== lifecycleGeneration) return;
        handlePeerActivity(event);
      }
    });
    peerProviderNode = node;
    const result = await node.start({
      models: [{ ...model, adapterPacks }],
      availability: {
        ...capabilityLimits,
        acceptedPolicies: listPolicies().map((policy) => policy.policyId),
        artifactRelay: participation.permissions.relayArtifacts,
        resultVerification: participation.permissions.verifyResults,
        storageBudgetMiB: participation.limits.storageBudgetMiB,
        bandwidthBudgetMbps: participation.limits.bandwidthBudgetMbps,
        activeJobs: 0
      }
    });
    return {
      identity: providerIdentityState,
      capabilityProfile,
      runtime: runtime.getRuntimeInfo?.() || loaded.runtime || null,
      transport: 'webrtc_peer_room',
      ...result
    };
  };

  const startWorker = async () => {
    if (workerRunning) {
      return {
        ok: true,
        status: 'peer_room_listening',
        model: currentModel
      };
    }
    if (workerStartPromise) return workerStartPromise;
    workerStartPromise = (async () => {
      const participation = readParticipationPreferences();
      if (!canContributeWith(participation)) {
        writeParticipationPreferences({ ...participation, mode: PARTICIPATION_MODES.both });
        await refreshParticipationControls(readParticipationPreferences());
      }
      const generation = ++lifecycleGeneration;
      providerReadyState = null;
      latestProviderActivity = null;
      latestRelayActivity = null;
      providerActivityHistory = [];
      workerStarting = true;
      setContributionState({ state: 'starting', optedIn: true, lastError: null });
      syncWorkerControls();
      setResult('pool-provider-result', {
        runner: 'peer_room_starting',
        roomId: getPeerRoomId(),
        model: getProviderModel()
      });
      setProviderStatus('Starting');
      setProviderNotice(null);
      try {
        const ready = await ensurePeerProviderReady(generation);
        if (generation !== lifecycleGeneration) {
          await stopPeerProvider().catch(() => null);
          return {
            ok: false,
            status: 'aborted'
          };
        }
        workerStarting = false;
        workerRunning = true;
        providerReadyState = ready;
        writeContributionResumeIntent({ modelId: currentModel?.modelId || getSelectedModelId() });
        setProviderStatus('Available');
        setProviderNotice(null);
        updateProviderHealth({ queue: 'listening' });
        setContributionState({ state: 'idle', optedIn: true, lastError: null });
        setResult('pool-provider-result', {
          runner: 'peer_room_listening',
          relay: getPeerRelayMode(),
          inviteUrl: getPeerInviteUrl(),
          ...ready
        });
        return {
          ok: true,
          status: 'peer_room_listening',
          ...ready
        };
      } catch (error) {
        if (generation !== lifecycleGeneration) {
          return {
            ok: false,
            status: 'aborted',
            error
          };
        }
        await stopPeerProvider().catch(() => null);
        workerStarting = false;
        workerRunning = false;
        providerReadyState = null;
        clearContributionResumeIntent();
        setProviderStatus('Could not start');
        setProviderNotice({
          state: 'error',
          title: error?.code === 'doppler_model_load_failed' ? 'Model failed to load' : 'Sharing could not start',
          message: 'Nothing was shared. Check the model and browser GPU support, then choose Start sharing to retry.'
        });
        updateProviderHealth({ queue: 'stopped', model: 'load_failed' });
        setContributionState({
          state: 'error',
          optedIn: false,
          lastError: errorString(error)
        });
        setResult('pool-provider-result', displayPoolError(error, {
          title: 'This tab could not start',
          action: 'Load a compatible model first. If the manifest URL is missing, deploy the model artifacts or attach a Doppler runtime handle.',
          context: {
            runner: 'stopped',
            roomId: getPeerRoomId(),
            relay: getPeerRelayMode(),
            model: getProviderModel()
          }
        }));
        return {
          ok: false,
          status: 'error',
          error
        };
      } finally {
        if (generation === lifecycleGeneration) syncWorkerControls();
      }
    })();
    try {
      return await workerStartPromise;
    } finally {
      workerStartPromise = null;
    }
  };

  const stopWorker = async () => {
    lifecycleGeneration += 1;
    controls.workerToggleButton?.setAttribute('disabled', 'true');
    const runtime = getRuntime();
    const cancellation = await runtime.cancelActiveWork?.({ reason: 'provider_stopped' }).catch((error) => ({
      ok: false,
      status: 'cancellation_failed',
      reason: error.message
    })) || null;
    workerStarting = false;
    workerRunning = false;
    providerReadyState = null;
    latestProviderActivity = null;
    latestRelayActivity = null;
    providerActivityHistory = [];
    clearContributionResumeIntent();
    setProviderStatus('Stopping');
    setProviderNotice(null);
    updateProviderHealth({ queue: 'cancelling_active_work' });
    setContributionState({ state: 'inactive', optedIn: false, lastError: null });
    setResult('pool-provider-result', {
      runner: 'stopping',
      peer: { status: 'peer_provider_stopping' },
      cancellation
    });
    const stopped = await stopPeerProvider().catch((error) => ({
      error: error.message,
      payload: error.payload || null
    }));
    const runtimeClosed = await runtime.close?.({ cancellation }).catch((error) => ({
      error: error.message
    }));
    setProviderStatus('Idle');
    setProviderNotice(null);
    updateProviderHealth({ queue: 'stopped' });
    setResult('pool-provider-result', {
      runner: 'stopped',
      peer: stopped,
      cancellation,
      runtime: runtimeClosed || null
    });
    syncWorkerControls();
  };

  let preferenceApplyPromise = Promise.resolve();

  const restorePersistedContribution = async () => {
    if (restoreAttempted || workerRunning || workerStarting) return null;
    restoreAttempted = true;
    const intent = readContributionResumeIntent();
    const participation = readParticipationPreferences();
    if (!intent || !canContributeWith(participation)) return null;
    if (intent.roomId !== getPeerRoomId() || intent.relay !== getPeerRelayMode()) return null;
    const model = getEnabledPoolModelContract(intent.modelId);
    if (!model) {
      clearContributionResumeIntent();
      return null;
    }
    requestedModelId = model.modelId;
    if (controls.modelInput) controls.modelInput.value = model.modelId;
    return startWorker();
  };

  return {
    attachControls(nextControls = {}) {
      controls = {
        workerToggleButton: nextControls.workerToggleButton || null,
        modelInput: nextControls.modelInput || null,
        mount: nextControls.mount || controls.mount || document.getElementById('app')
      };
      if (controls.modelInput && currentModel?.modelId) controls.modelInput.value = currentModel.modelId;
      if (controls.workerToggleButton && controls.workerToggleButton.dataset.poolContributionBound !== 'true') {
        controls.workerToggleButton.dataset.poolContributionBound = 'true';
        controls.workerToggleButton.addEventListener('click', () => {
          if (workerRunning || workerStarting) void stopWorker();
          else void startWorker();
        });
      }
      syncProviderPanel();
      if (!visibilityHandler && typeof document?.addEventListener === 'function') {
        visibilityHandler = () => {
          if (document.visibilityState !== 'visible') return;
          restoreAttempted = false;
          void restorePersistedContribution();
        };
        document.addEventListener('visibilitychange', visibilityHandler);
      }
      void restorePersistedContribution();
    },
    async startForModel(modelId) {
      const model = getEnabledPoolModelContract(modelId);
      if (!model) {
        const error = new Error('Selected model is not enabled for peer contribution');
        error.code = 'peer_provider_model_disabled';
        throw error;
      }
      if (workerRunning && currentModel?.modelId !== model.modelId) {
        await stopWorker();
      }
      requestedModelId = model.modelId;
      if (controls.modelInput) {
        controls.modelInput.value = model.modelId;
        syncProviderWorkloadCapability(controls.modelInput);
      }
      const result = await startWorker();
      if (!result?.ok) {
        throw result?.error || new Error('This browser did not become available to the room');
      }
      return result;
    },
    async applyParticipationPreferences(previous, next) {
      preferenceApplyPromise = preferenceApplyPromise.then(async () => {
        if (!workerRunning && !workerStarting) {
          syncProviderPanel();
          return;
        }
        if (!canContributeWith(next)) {
          await stopWorker();
          return;
        }
        if (JSON.stringify(previous) !== JSON.stringify(next)) {
          await stopWorker();
          await startWorker();
        }
      }).catch(() => {});
      await preferenceApplyPromise;
    },
    async handleModelChange() {
      const nextModelId = controls.modelInput?.value || null;
      const activeModelId = requestedModelId || currentModel?.modelId || null;
      requestedModelId = nextModelId;
      if ((workerRunning || workerStarting) && nextModelId !== activeModelId) {
        await stopWorker();
        await startWorker();
      }
    },
    async dispose({ preserveResumeIntent = true } = {}) {
      lifecycleGeneration += 1;
      if (visibilityHandler) {
        document.removeEventListener('visibilitychange', visibilityHandler);
        visibilityHandler = null;
      }
      await stopPeerProvider().catch(() => null);
      workerStarting = false;
      workerRunning = false;
      workerStartPromise = null;
      providerReadyState = null;
      latestProviderActivity = null;
      latestRelayActivity = null;
      providerActivityHistory = [];
      if (!preserveResumeIntent) clearContributionResumeIntent();
    }
  };
};

let providerContributionController = null;

const getProviderContributionController = () => {
  if (!providerContributionController) {
    providerContributionController = createProviderContributionController();
  }
  return providerContributionController;
};

export const resetProviderContributionControllerForTests = async ({
  preserveResumeIntent = false
} = {}) => {
  const current = providerContributionController;
  providerContributionController = null;
  if (current?.dispose) await current.dispose({ preserveResumeIntent });
};

const syncProviderWorkloadCapability = (modelSelect) => {
  const badge = document.querySelector('[data-pool-provider-workload]');
  if (!badge) return;
  const workload = modelSelect?.selectedOptions?.[0]?.dataset?.workload || POOLDAY_MODEL_WORKLOADS.sequenceEmbedding;
  badge.textContent = workload.replace(/[-_]/g, ' ');
};

export const bindProviderControls = () => {
  const modelInput = document.getElementById('pool-provider-model');
  getProviderContributionController().attachControls({
    workerToggleButton: document.getElementById('pool-provider-worker-toggle')
      || document.getElementById('pool-home-provider-toggle'),
    modelInput,
    mount: document.getElementById('app')
  });
  if (modelInput && modelInput.dataset.poolWorkloadBound !== 'true') {
    modelInput.dataset.poolWorkloadBound = 'true';
    modelInput.addEventListener('change', () => {
      syncProviderWorkloadCapability(modelInput);
      void getProviderContributionController().handleModelChange();
    });
    syncProviderWorkloadCapability(modelInput);
  }
};

export const bindRecordFacetControls = () => {
  const ledger = document.getElementById('pool-record-ledger');
  if (!ledger || ledger.dataset.poolFacetBound === 'true') return;
  ledger.dataset.poolFacetBound = 'true';
  ledger.addEventListener('click', (event) => {
    const chip = event.target.closest?.('[data-pool-record-facet]');
    if (!chip) return;
    ledger.dataset.recordFacet = setPoolRecordFacet(chip.dataset.poolRecordFacet || 'all');
    refreshRecordTimelineState();
  });
};

const bindRecordDisclosureControls = () => {
  const layout = document.querySelector('.pool-record-layout');
  if (!layout || layout.dataset.poolRecordDisclosureBound === 'true') return;
  layout.dataset.poolRecordDisclosureBound = 'true';
  restorePoolRecordDisclosures(layout);
  layout.addEventListener('toggle', (event) => {
    const details = event.target;
    const disclosureId = details?.dataset?.poolRecordDisclosure;
    if (!disclosureId) return;
    setPoolRecordDisclosureOpen(disclosureId, details.open);
  }, true);
};

export const bindReceiptControls = () => {
  bindRecordFacetControls();
  bindRecordDisclosureControls();
  const button = document.getElementById('pool-receipt-lookup');
  const input = document.getElementById('pool-receipt-hash');
  if (!button || !input) return;
  const ledgerContainer = document.getElementById('pool-receipt-ledger');
  if (ledgerContainer) {
    ledgerContainer.innerHTML = renderReceiptLedger();
  }
  void refreshServerRoomActivity();
  button.addEventListener('click', async () => {
    const receiptHash = input.value.trim();
    if (!receiptHash) {
      setResult('pool-receipt-result', { error: 'Hash is required' });
      return;
    }
    button.disabled = true;
    try {
      const record = findReceiptLedgerRecord(receiptHash);
      if (!record) {
        setResult('pool-receipt-result', {
          status: 'not_found',
          receiptHash,
          action: 'Submit a local peer-room job first, then inspect Records from this browser.'
        });
        return;
      }
      setResult('pool-receipt-result', {
        ...record,
        localVerification: record.receipt ? await verifyReceiptRecord(record) : null
      });
    } catch (error) {
      setResult('pool-receipt-result', { error: error.message, payload: error.payload || null });
    } finally {
      button.disabled = false;
    }
  });
};
