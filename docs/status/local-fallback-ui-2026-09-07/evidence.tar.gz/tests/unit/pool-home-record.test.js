import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';

import { PEER_MESSAGE_TYPES } from '../../self/pool/peer-control-plane.js';
import {
  addReceiptLedgerRow,
  findReceiptLedgerRecord,
  getPoolRoomPanel,
  getPooldayRecordStorageKeys,
  loadPoolRoomDraft,
  persistPoolRoomDraft,
  clearPoolRoomDraft,
  renderPeerLedgerState,
  renderRecordLedger,
  renderReceiptLedger,
  renderRoomActivity,
  renderRouteDetail,
  restoreLatestCompletedRun,
  setPoolRecordDisclosureOpen,
  setPoolRecordFacet,
  setResult,
  isEmbeddingPublicationPermitted,
  updateProviderNotice,
  updateProviderStatus
} from '../../self/ui/pool-home/view.js';

const createMemoryStorage = () => {
  const store = new Map();
  return {
    getItem: (key) => store.has(key) ? store.get(key) : null,
    setItem: (key, value) => store.set(key, String(value)),
    removeItem: (key) => store.delete(key),
    clear: () => store.clear(),
    keys: () => [...store.keys()]
  };
};

const setRoom = (roomId, panel = '', pathname = '/records') => {
  const params = new URLSearchParams({ room: roomId });
  if (panel) params.set('panel', panel);
  vi.stubGlobal('window', {
    location: { origin: 'http://localhost:3000', pathname, search: `?${params.toString()}` },
    addEventListener: vi.fn(),
    removeEventListener: vi.fn(),
    dispatchEvent: vi.fn()
  });
};

describe('Poolday record ledgers', () => {
  let storage;

  beforeEach(() => {
    storage = createMemoryStorage();
    vi.stubGlobal('localStorage', storage);
  });

  afterEach(() => {
    vi.unstubAllGlobals();
  });

  it('persists receipt rows by room and extracts nested provider ids', () => {
    const roomA = `record-room-a-${crypto.randomUUID()}`;
    const roomB = `record-room-b-${crypto.randomUUID()}`;
    setRoom(roomA);
    const keysA = getPooldayRecordStorageKeys();

    addReceiptLedgerRow({
      jobId: 'peer_job_a',
      receiptHash: 'sha256:receipt-a',
      receipt: {
        jobId: 'peer_job_a',
        providerId: 'provider_page_nested'
      },
      agreement: { accepted: true }
    }, 'sha256:receipt-a');

    expect(storage.getItem(keysA.receipts)).toContain('provider_page_nested');
    expect(findReceiptLedgerRecord('sha256:receipt-a')?.jobId).toBe('peer_job_a');
    expect(renderReceiptLedger()).toContain('provider_page_nested');
    expect(renderRecordLedger()).toContain('Answer completed');

    setRoom(roomB);
    expect(renderReceiptLedger()).toContain('No answers saved yet.');
    expect(findReceiptLedgerRecord('sha256:receipt-a')).toBeNull();

    setRoom(roomA);
    expect(findReceiptLedgerRecord('sha256:receipt-a')?.receipt?.providerId).toBe('provider_page_nested');
  });

  it('persists unsent room drafts by room without treating them as evidence', () => {
    const roomA = `draft-room-a-${crypto.randomUUID()}`;
    const roomB = `draft-room-b-${crypto.randomUUID()}`;
    setRoom(roomA);
    persistPoolRoomDraft({ sequence: 'MAPLALLLLGLVAGA', intentText: 'Review this sequence' });
    expect(storage.getItem(getPooldayRecordStorageKeys().draft)).toContain('MAPLALLLLGLVAGA');
    expect(loadPoolRoomDraft()).toMatchObject({
      sequence: 'MAPLALLLLGLVAGA',
      intentText: 'Review this sequence'
    });

    setRoom(roomB);
    expect(loadPoolRoomDraft()).toBeNull();
    setRoom(roomA);
    clearPoolRoomDraft();
    expect(loadPoolRoomDraft()).toBeNull();
    expect(loadPoolRoomDraft()).not.toEqual(expect.objectContaining({ kind: 'research_submission' }));
  });

  it('keeps an intentionally empty sequence in room recovery state', () => {
    const room = `empty-draft-room-${crypto.randomUUID()}`;
    setRoom(room);
    persistPoolRoomDraft({ sequence: '', intentText: 'Add the sequence later' });

    expect(loadPoolRoomDraft()).toMatchObject({
      sequence: '',
      intentText: 'Add the sequence later'
    });
  });

  it('projects contextual review and discovery panels from the room query', () => {
    const room = `contextual-room-${crypto.randomUUID()}`;

    setRoom(room, 'review', '/room-1');
    const reviewHtml = renderRouteDetail('room-1');
    expect(getPoolRoomPanel()).toBe('review');
    expect(reviewHtml).toContain('data-pool-room-contextual-panel="review"');
    expect(reviewHtml).toContain('id="pool-room-review"');
    expect(reviewHtml).toContain('data-room-panel="review"');
    expect(reviewHtml).toMatch(/pool-room-secondary-workspace"[^>]* data-pool-room-panel-open="true">/);

    setRoom(room, 'discovery', '/room-1');
    const discoveryHtml = renderRouteDetail('room-1');
    expect(getPoolRoomPanel()).toBe('discovery');
    expect(discoveryHtml).toContain('data-pool-room-contextual-panel="discovery"');
    expect(discoveryHtml).toContain('id="pool-room-discovery"');
    expect(discoveryHtml).toContain('data-room-panel="discovery"');
    expect(discoveryHtml).toMatch(/pool-room-secondary-workspace"[^>]* data-pool-room-panel-open="true">/);

    setRoom(room);
    const overviewHtml = renderRouteDetail('room-1');
    expect(overviewHtml).toContain('data-pool-room-panel="research"');
    expect(overviewHtml).not.toContain('data-pool-room-panel-open="true"');
  });

  it('keeps compatibility routes on execution records and Room-1 separate', () => {
    const room = `compatibility-room-${crypto.randomUUID()}`;

    setRoom(room, '', '/network');
    const networkHtml = renderRouteDetail('network');
    expect(getPoolRoomPanel()).toBe('discovery');
    expect(networkHtml).not.toContain('data-pool-room-contextual-panel="discovery"');
    expect(networkHtml).not.toContain('data-pool-research-room');

    setRoom(room, '', '/history');
    const historyHtml = renderRouteDetail('history');
    expect(historyHtml).toContain('data-record-facet="all"');
    expect(historyHtml).not.toContain('data-pool-research-room');
    expect(historyHtml).not.toContain('Open Research Room-1');
  });

  it('renders peer ledger zero counts instead of blank cells', () => {
    const room = `record-ledger-${crypto.randomUUID()}`;
    setRoom(room);

    setResult('missing-result-element', {
      ledgerEvents: [
        {
          messageHash: 'points-provider-a',
          type: PEER_MESSAGE_TYPES.POINTS_EVENT,
          body: {
            userId: 'provider_page_a',
            providerId: 'provider_page_a',
            points: 1
          }
        },
        {
          messageHash: 'reputation-provider-a',
          type: PEER_MESSAGE_TYPES.REPUTATION_EVENT,
          body: {
            providerId: 'provider_page_a',
            acceptedReceipts: 1,
            rejectedReceipts: 0,
            points: 1
          }
        }
      ]
    });

    const html = renderPeerLedgerState();
    expect(html).toContain('provider_page_a');
    expect(html).toContain('<td>1</td>');
    expect(html).toContain('<td>0</td>');
  });

  it('shortens contributor identities in compatibility ledgers', () => {
    const room = `identity-ledger-${crypto.randomUUID()}`;
    setRoom(room);
    const providerId = 'provider-identity-root-with-publicly-long-stable-id';
    addReceiptLedgerRow({
      jobId: 'peer_job_identity',
      receiptHash: 'sha256:receipt-identity',
      receipt: { jobId: 'peer_job_identity', providerId }
    }, 'sha256:receipt-identity');

    const html = renderReceiptLedger();
    expect(html).not.toContain(providerId);
    expect(html).toContain('provider-identit...table-id');
  });

  it('refreshes the active Research Room timeline after a receipt ledger update', () => {
    const room = `receipt-room-refresh-${crypto.randomUUID()}`;
    setRoom(room);
    document.body.innerHTML = '<section data-pool-research-room></section>';

    addReceiptLedgerRow({
      jobId: 'peer_job_room_refresh',
      receiptHash: 'sha256:receipt-room-refresh',
      receipt: { jobId: 'peer_job_room_refresh', providerId: 'provider-room-refresh' },
      agreement: { status: 'accepted' }
    }, 'sha256:receipt-room-refresh');

    expect(document.querySelector('[data-pool-research-room]')).toBeTruthy();
    const timeline = document.querySelector('.pool-room-timeline')?.textContent || '';
    expect(timeline).toContain('Signed receipt received');
    expect(timeline).toContain('provider-room-refresh');
  });

  it('keeps a contributor visibly active while its relay is recovering', () => {
    const mount = document.createElement('section');
    mount.innerHTML = `
      <span data-pool-provider-status></span>
      <span data-pool-drawer-summary="network-device"></span>
    `;

    updateProviderStatus(mount, 'Relay retrying');
    expect(mount.querySelector('[data-pool-provider-status]')).toMatchObject({
      textContent: 'Relay retrying',
      dataset: { providerState: 'degraded' }
    });
    expect(mount.querySelector('[data-pool-drawer-summary="network-device"]')).toMatchObject({
      textContent: 'Relay retrying',
      dataset: { providerState: 'degraded' }
    });

    updateProviderStatus(mount, 'Relay unavailable');
    expect(mount.querySelector('[data-pool-provider-status]')).toHaveProperty('dataset.providerState', 'degraded');

    updateProviderStatus(mount, 'Available');
    expect(mount.querySelector('[data-pool-provider-status]')).toHaveProperty('dataset.providerState', 'online');

    updateProviderStatus(mount, 'Could not start');
    expect(mount.querySelector('[data-pool-provider-status]')).toHaveProperty('dataset.providerState', 'error');
  });

  it('projects provider startup failure into the primary sharing surface', () => {
    const mount = document.createElement('section');
    mount.innerHTML = '<div data-pool-provider-notice hidden></div>';

    updateProviderNotice(mount, {
      state: 'error',
      title: 'Pack failed to load',
      message: 'Nothing was shared. Check this Pack and browser WebGPU, then retry.'
    });

    const notice = mount.querySelector('[data-pool-provider-notice]');
    expect(notice.hidden).toBe(false);
    expect(notice.dataset.noticeState).toBe('error');
    expect(notice.textContent).toContain('Pack failed to load');
    expect(notice.textContent).toContain('Nothing was shared');

    updateProviderNotice(mount, null);
    expect(notice.hidden).toBe(true);
  });

  it('labels points, reputation, and requester spend as distinct room records', () => {
    const room = `record-event-labels-${crypto.randomUUID()}`;
    setRoom(room);

    setResult('missing-result-element', {
      ledgerEvents: [
        {
          messageHash: 'points-provider-label',
          type: PEER_MESSAGE_TYPES.POINTS_EVENT,
          body: { userId: 'provider_page_a', points: 4, reason: 'accepted_receipt' }
        },
        {
          messageHash: 'reputation-provider-label',
          type: PEER_MESSAGE_TYPES.REPUTATION_EVENT,
          body: { providerId: 'provider_page_a', points: 4, reason: 'accepted_receipt' }
        },
        {
          messageHash: 'points-requester-label',
          type: PEER_MESSAGE_TYPES.POINTS_EVENT,
          body: { userId: 'requester_page_a', points: -4, reason: 'accepted_receipt_spend' }
        }
      ]
    });

    const html = renderRecordLedger('room');
    expect(html).toContain('Contributor points credited');
    expect(html).toContain('Contributor reputation updated');
    expect(html).toContain('Requester points spent');
  });

  it('serializes repeated result objects without losing arrays as circular values', () => {
    document.body.innerHTML = `
      <div id="pool-run-result-summary"></div>
      <pre id="pool-run-result-raw"></pre>
      <pre id="pool-run-result-stream"></pre>
      <span id="pool-run-result-stream-cursor"></span>
    `;
    const assignments = [{ providerId: 'provider_a' }, { providerId: 'provider_b' }];
    const repeated = assignments[0];
    repeated.self = repeated;

    setResult('pool-run-result', {
      assignments,
      firstAssignment: repeated
    }, { stream: true });

    const parsed = JSON.parse(document.getElementById('pool-run-result-raw').textContent);
    expect(parsed.assignments).toHaveLength(2);
    expect(parsed.assignments[0].providerId).toBe('provider_a');
    expect(parsed.assignments[0].self).toBe('[Circular]');
    expect(parsed.firstAssignment.providerId).toBe('provider_a');
  });

  it('moves pooled embeddings out of raw results into the Protein embedding disclosure', () => {
    document.body.innerHTML = `
      <div id="pool-run-result-summary"></div>
      <pre id="pool-run-result-raw"></pre>
      <pre id="pool-run-result-stream"></pre>
      <span id="pool-run-result-stream-cursor"></span>
      <section id="pool-run-result-embedding-outcome" hidden>
        <p id="pool-run-result-embedding-outcome-meta"></p>
        <button data-pool-copy-embedding disabled></button>
        <p data-pool-embedding-copy-status></p>
      </section>
      <details id="pool-run-result-embedding-details" hidden><p id="pool-run-result-embedding-meta"></p><pre id="pool-run-result-embedding"></pre></details>
    `;

    setResult('pool-run-result', {
      sequenceResultHash: 'sha256:embedding-result',
      sequenceOutput: {
        pooledEmbedding: [0.25, -0.5, 0.75],
        tokenEmbeddings: null,
        maskedLogits: []
      }
    }, { stream: true, animate: false });

    expect(document.getElementById('pool-run-result-raw').textContent).not.toContain('0.25');
    expect(document.getElementById('pool-run-result-raw').textContent).toContain('Rendered in Protein embedding');
    expect(document.getElementById('pool-run-result-embedding-outcome').hidden).toBe(false);
    expect(document.getElementById('pool-run-result-embedding-outcome-meta').textContent).toContain('3 dimensions');
    expect(document.getElementById('pool-run-result-embedding-outcome-meta').textContent).toContain('Raw vector withheld');
    expect(document.querySelector('[data-pool-copy-embedding]').disabled).toBe(true);
    expect(document.getElementById('pool-run-result-embedding-details').hidden).toBe(true);
    expect(document.getElementById('pool-run-result-embedding-meta').textContent).toContain('3 dimensions');
    expect(document.getElementById('pool-run-result-embedding').textContent).toBe('');
    expect(isEmbeddingPublicationPermitted({ sequenceOutput: { pooledEmbedding: [1] } })).toBe(false);
  });

  it('renders a pooled embedding only with explicit publication consent', () => {
    document.body.innerHTML = `
      <div id="pool-run-result-summary"></div>
      <pre id="pool-run-result-raw"></pre>
      <pre id="pool-run-result-stream"></pre>
      <span id="pool-run-result-stream-cursor"></span>
      <section id="pool-run-result-embedding-outcome" hidden>
        <p id="pool-run-result-embedding-outcome-meta"></p>
        <button data-pool-copy-embedding disabled></button>
        <p data-pool-embedding-copy-status></p>
      </section>
      <details id="pool-run-result-embedding-details" hidden><p id="pool-run-result-embedding-meta"></p><pre id="pool-run-result-embedding"></pre></details>
    `;

    setResult('pool-run-result', {
      sequenceResultHash: 'sha256:embedding-result',
      embeddingPublicationConsent: true,
      sequenceOutput: { pooledEmbedding: [0.25, -0.5, 0.75] }
    }, { stream: true, animate: false });

    expect(isEmbeddingPublicationPermitted({ embeddingPublicationConsent: true })).toBe(true);
    expect(document.querySelector('[data-pool-copy-embedding]').disabled).toBe(false);
    expect(document.querySelector('[data-pool-copy-embedding]').dataset.poolEmbeddingPublicationPermitted).toBe('true');
    expect(document.getElementById('pool-run-result-embedding-details').hidden).toBe(false);
    expect(document.getElementById('pool-run-result-embedding').textContent).toContain('0.25');
  });

  it('retains contributor timeout diagnostics in the raw error details', () => {
    document.body.innerHTML = `
      <div id="pool-run-result-summary"></div>
      <pre id="pool-run-result-raw"></pre>
      <pre id="pool-run-result-stream"></pre>
      <span id="pool-run-result-stream-cursor"></span>
    `;

    setResult('pool-run-result', {
      status: 'error',
      error: 'No matching provider is currently available',
      reason: 'Peer receipt agreement failed: 0/1 matching receipts',
      code: 'peer_provider_unresponsive',
      payload: {
        failedProviderIds: ['provider_reloaded_with_long_stable_identity'],
        providerFailures: [{
          providerId: 'provider_reloaded_with_long_stable_identity',
          code: 'peer_receipt_timeout',
          message: 'No peer receipt returned before the delivery deadline',
          diagnostics: {
            state: 'failed',
            iceConnectionState: 'failed',
            expiredRemoteIceCandidateCount: 2,
            overflowRemoteIceCandidateCount: 1,
            turnConfigured: false
          }
        }]
      }
    }, { stream: true, animate: false });

    const raw = document.getElementById('pool-run-result-raw').textContent;
    const summary = document.getElementById('pool-run-result-summary').textContent;
    expect(summary).toContain('No matching provider is currently available');
    expect(summary).not.toContain('peer_provider_unresponsive');
    expect(summary).not.toContain('provider_reloaded_with_long_stable_identity');
    expect(raw).toContain('Code: peer_provider_unresponsive');
    expect(raw).toContain('Contributors: provider_reloade...identity');
    expect(raw).toContain('Contributor failures: provider_reloade...identity (peer_receipt_timeout)');
    expect(raw).not.toContain('provider_reloaded_with_long_stable_identity');
    expect(raw).toContain('expired-ice=2');
    expect(raw).toContain('dropped-ice=1');
    expect(raw).toContain('turn=not-configured');
  });

  it('retains compact assignment rejection evidence in the raw error details', () => {
    document.body.innerHTML = `
      <div id="pool-run-result-summary"></div>
      <pre id="pool-run-result-raw"></pre>
      <pre id="pool-run-result-stream"></pre>
      <span id="pool-run-result-stream-cursor"></span>
    `;

    setResult('pool-run-result', {
      status: 'error',
      error: 'Request could not complete',
      reason: 'not_enough_peer_providers',
      code: 'not_enough_peer_providers',
      payload: {
        requiredProviders: 1,
        eligibleProviders: 0,
        routeCandidates: [{
          providerId: 'provider_with_long_stable_identity',
          rejectionReasons: ['participation_identity_invalid', 'provider_capacity_exhausted']
        }]
      }
    }, { stream: true, animate: false });

    const raw = document.getElementById('pool-run-result-raw').textContent;
    expect(raw).toContain('Required contributors: 1');
    expect(raw).toContain('Eligible contributors: 0');
    expect(raw).toContain('Eligibility: provider_with_lo...identity: participation_identity_invalid, provider_capacity_exhausted');
    expect(raw).not.toContain('provider_with_long_stable_identity');
  });

  it('renders clean answer contributors while preserving the full result', () => {
    document.body.innerHTML = `
      <div id="pool-run-result-summary"></div>
      <div id="pool-run-result-evidence"></div>
      <pre id="pool-run-result-raw"></pre>
      <pre id="pool-run-result-stream"></pre>
      <span id="pool-run-result-stream-cursor"></span>
    `;

    setResult('pool-run-result', {
      outputText: 'distributed answer',
      policyId: 'ring_quorum_receipt',
      agreement: {
        accepted: true,
        requiredAgreement: 2,
        acceptedProviderCount: 2,
        receiptHashes: ['sha256:a', 'sha256:b']
      },
      receiptPayloads: [
        {
          fromPeerId: 'provider_a',
          body: {
            receiptHash: 'sha256:a',
            providerId: 'provider_a',
            tokenIds: [1, 2],
            receipt: {
              providerId: 'provider_a',
              outputHash: 'sha256:output-a',
              tokenCounts: { input: 3, output: 2 }
            }
          }
        },
        {
          fromPeerId: 'provider_b',
          body: {
            receiptHash: 'sha256:b',
            providerId: 'provider_b',
            tokenIds: [1, 2],
            receipt: {
              providerId: 'provider_b',
              outputHash: 'sha256:output-b',
              tokenCounts: { input: 3, output: 2 }
            }
          }
        }
      ]
    }, { stream: true });

    expect(document.getElementById('pool-run-result-stream').textContent).toBe('distributed answer');
    expect(document.getElementById('pool-run-result-evidence').textContent).toContain('provider_a');
    expect(document.getElementById('pool-run-result-evidence').textContent).toContain('matched');
    expect(JSON.parse(document.getElementById('pool-run-result-raw').textContent).receiptPayloads).toHaveLength(2);
  });

  it('uses one records surface for execution evidence without research administration', () => {
    setRoom(`record-copy-${crypto.randomUUID()}`);

    const recordsHtml = renderRouteDetail('records');
    const historyAliasHtml = renderRouteDetail('history');
    const networkAliasHtml = renderRouteDetail('network');

    expect(recordsHtml).toContain('No lookup yet.');
    expect(recordsHtml).toContain('No answers saved yet.');
    expect(recordsHtml).toContain('No records yet. Requests, completed runs, and contributions will appear here.');
    expect(recordsHtml).toContain('Advanced details');
    expect(recordsHtml).toContain('Peer activity and retries');
    expect(recordsHtml).toContain('Checking room activity...');
    expect(recordsHtml).toContain('Peer identities');
    expect(recordsHtml).toContain('No local scores yet.');
    expect(recordsHtml).toContain('Find by receipt hash');
    expect(historyAliasHtml).toContain('Peer identities');
    expect(networkAliasHtml).toContain('Saved answer receipts');
    expect(networkAliasHtml).toContain('Peer activity and retries');
    expect(recordsHtml).not.toContain('data-pool-research-room');
  });

  it('restores record facets and open disclosures after a route refresh', () => {
    const roomId = `record-view-${crypto.randomUUID()}`;
    setRoom(roomId);
    addReceiptLedgerRow({
      jobId: 'peer_job_open',
      receiptHash: 'sha256:receipt-open',
      receipt: {
        jobId: 'peer_job_open',
        providerId: 'provider_page_open'
      },
      agreement: { accepted: true }
    }, 'sha256:receipt-open');

    setPoolRecordFacet('answer');
    setPoolRecordDisclosureOpen('record:receipt:sha256:receipt-open', true);
    setPoolRecordDisclosureOpen('technical-tools', true);
    setPoolRecordDisclosureOpen('receipt-lookup', true);

    const html = renderRouteDetail('records');
    expect(html).toContain('data-record-facet="answer"');
    expect(html).toMatch(/data-pool-record-disclosure="record:receipt:sha256:receipt-open" open/);
    expect(html).toMatch(/data-pool-record-disclosure="technical-tools" open/);
    expect(html).toMatch(/data-pool-record-disclosure="receipt-lookup" open/);
  });

  it.each(['peer', 'local'])('restores a saved %s result without implying a live run or extra acceptance', (kind) => {
    const roomId = `record-result-${crypto.randomUUID()}`;
    setRoom(roomId);
    document.body.innerHTML = `
      <section data-pool-run-surface data-run-state="idle">
        <p data-pool-run-status>Ready</p>
        <section data-pool-run-output hidden>
          <div id="pool-run-result-summary"></div>
          <pre id="pool-run-result-stream"></pre>
          <span id="pool-run-result-stream-cursor"></span>
          <div id="pool-run-result-evidence"></div>
          <div id="pool-run-result-recovery"></div>
          <pre id="pool-run-result-raw"></pre>
        </section>
      </section>
    `;
    addReceiptLedgerRow({
      outputText: 'persisted accepted answer',
      receiptHash: 'sha256:persisted',
      receipt: {
        jobId: 'peer_job_persisted',
        providerId: 'provider_page_persisted'
      },
      ...(kind === 'local' ? {
        status: 'completed', transport: 'local_capsule',
        localExecution: { receipt: { receiptDigest: 'sha256:persisted' } }
      } : { requesterAcceptance: { accepted: true }, agreement: { accepted: true } })
    }, 'sha256:persisted');

    const restored = restoreLatestCompletedRun('ask');

    expect(restored?.savedRecord).toMatchObject({ restored: true, roomId });
    expect(document.getElementById('pool-run-result-stream').textContent).toBe('persisted accepted answer');
    expect(document.querySelector('[data-pool-run-output]').hidden).toBe(false);
    expect(document.querySelector('[data-pool-run-status]').textContent).toBe(kind === 'local' ? 'Showing last saved local result' : 'Showing last saved answer');
    if (kind === 'local') {
      expect(restored.requesterAcceptance).toBeUndefined();
      expect(renderRecordLedger()).toContain('Completed on this device');
    }
    expect(document.querySelector('[data-pool-run-surface]').dataset.runState).toBe('inspecting');
  });

  it('renders compact server relay room activity summaries', () => {
    setRoom(`record-activity-${crypto.randomUUID()}`);

    const html = renderRoomActivity({
      relay: 'server',
      messageCount: 3,
      peerCount: 2,
      providerCount: 1,
      recent: [
        { type: 'provider-advert', fromPeerId: 'provider_a' },
        { type: 'peer-run-request', fromPeerId: 'requester_a' }
      ]
    });

    expect(html).toContain('Shared room activity');
    expect(html).toContain('<td>3</td>');
    expect(html).toContain('<td>2</td>');
    expect(html).toContain('<td>1</td>');
    expect(html).toContain('provider-advert:provider_a');
  });
});
